import { useState, useMemo, useEffect, useRef } from "react";
import { db } from "./firebase";
import {
  collection, onSnapshot, addDoc, updateDoc,
  deleteDoc, doc, setDoc, getDoc, getDocs
} from "firebase/firestore";
import {
  getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged
} from "firebase/auth";

const auth = getAuth();

// ── Categorías (editables desde Configuración, guardadas en config/categorias) ──
const PALETA_CATEGORIAS = [
  { bg:"#fff3e0", text:"#bf360c", accent:"#ff9800" }, // naranja
  { bg:"#e8eaf6", text:"#283593", accent:"#3949ab" }, // índigo
  { bg:"#fce4ec", text:"#880e4f", accent:"#e91e63" }, // rosa
  { bg:"#e0f2f1", text:"#004d40", accent:"#009688" }, // verde agua
  { bg:"#f3e5f5", text:"#4a148c", accent:"#9c27b0" }, // violeta
  { bg:"#fff8e1", text:"#f57f17", accent:"#ffc107" }, // amarillo
  { bg:"#e8f5e9", text:"#1b5e20", accent:"#4caf50" }, // verde
  { bg:"#efebe9", text:"#3e2723", accent:"#795548" }, // marrón
  { bg:"#e3f2fd", text:"#0d47a1", accent:"#1976d2" }, // azul
  { bg:"#ffebee", text:"#b71c1c", accent:"#e53935" }, // rojo
  { bg:"#eceff1", text:"#263238", accent:"#607d8b" }, // gris azulado
  { bg:"#f5f5f5", text:"#424242", accent:"#9e9e9e" }, // gris
];

const CATEGORIAS_DEFAULT = [
  { nombre:"Vinilo Impreso", icono:"🖨️", bg:"#fff3e0", text:"#bf360c", accent:"#1976d2" },
  { nombre:"Vinilo Calado",  icono:"✂️", bg:"#e8eaf6", text:"#283593", accent:"#3949ab" },
  { nombre:"Diseño",         icono:"🎨", bg:"#fce4ec", text:"#880e4f", accent:"#e91e63" },
  { nombre:"Impresiones",    icono:"📄", bg:"#e0f2f1", text:"#004d40", accent:"#009688" },
  { nombre:"DTF",            icono:"👕", bg:"#fff3e0", text:"#e65100", accent:"#ff9800" },
  { nombre:"Sublimado",      icono:"🌈", bg:"#f3e5f5", text:"#4a148c", accent:"#9c27b0" },
  { nombre:"Estampado",      icono:"🔖", bg:"#fff8e1", text:"#f57f17", accent:"#ffc107" },
  { nombre:"Talonarios",     icono:"📒", bg:"#e8f5e9", text:"#1b5e20", accent:"#4caf50" },
  { nombre:"Lona",           icono:"🪧", bg:"#efebe9", text:"#3e2723", accent:"#795548" },
  { nombre:"3D",             icono:"🖨️", bg:"#e8f5e9", text:"#1b5e20", accent:"#388e3c" },
  { nombre:"Otros",          icono:"📦", bg:"#f5f5f5", text:"#424242", accent:"#9e9e9e" },
];

const COLOR_CAT_DEFAULT = { bg:"#f5f5f5", text:"#424242", accent:"#9e9e9e" };

// Estos tres objetos se actualizan "en el lugar" cuando cambia la configuración,
// así todo el código que ya los usa sigue funcionando sin cambios.
const CATEGORIAS = [];
const _catIcon  = {};
const _catColor = {};
// Si un pedido tiene una categoría que ya no existe, se muestra igual con ícono y color neutros
const CATEGORIA_ICON  = new Proxy(_catIcon,  { get:(t,k) => (typeof k==="string" && !(k in t)) ? "📦" : t[k] });
const CATEGORIA_COLOR = new Proxy(_catColor, { get:(t,k) => (typeof k==="string" && !(k in t)) ? COLOR_CAT_DEFAULT : t[k] });

function aplicarCategorias(lista) {
  const validas = (lista && lista.length ? lista : CATEGORIAS_DEFAULT).filter(x => x && x.nombre);
  CATEGORIAS.splice(0, CATEGORIAS.length, ...validas.map(x => x.nombre));
  validas.forEach(x => {
    _catIcon[x.nombre]  = x.icono || "📦";
    _catColor[x.nombre] = { bg:x.bg||COLOR_CAT_DEFAULT.bg, text:x.text||COLOR_CAT_DEFAULT.text, accent:x.accent||COLOR_CAT_DEFAULT.accent };
  });
}
aplicarCategorias(CATEGORIAS_DEFAULT);

// ── Configuración general de la app (config/app en Firebase) ─────────────
const APP_CFG_DEFAULT = {
  msgListoSaldo: "¡Hola {nombre}! 👋\nTu pedido *{ot}{pedido}* ya está listo para retirar 🎉\nEl monto total es ${total} y resta abonar *${saldo}*.\n¡Muchas gracias por elegirnos! 🙌",
  msgListoPago:  "¡Hola {nombre}! 👋\nTu pedido *{ot}{pedido}* ya está listo para retirar 🎉\nEl total abonado es ${total}. ¡Todo pago!\n¡Muchas gracias por elegirnos! 🙌",
  prefijoWhatsapp: "549",
  validezPresupuesto: 7,
  condicionesPresupuesto: "Sujeto a cambios de precio",
  piePresupuesto: "",
  firmaOrden: "Firma operario",
  pieOrden: "",
  accesos: [
    { nombre:"Cotizador",  icono:"💲", url:"https://mafalda-cotizador.vercel.app" },
    { nombre:"PhotoPrint", icono:"📷", url:"https://mafalda-photoprint.vercel.app" },
  ],
  metodosPago: [
    { nombre:"Transferencia",      icono:"📲", corto:"Transferencia" },
    { nombre:"Tarjeta de Crédito", icono:"💳", corto:"Tarjeta" },
  ],
};
// Se actualiza "en el lugar" al cargar Firebase, así funciones como buildOrdenHTML lo leen directo
const APP_CFG = JSON.parse(JSON.stringify(APP_CFG_DEFAULT));
function aplicarAppCfg(datos) {
  const d = datos || {};
  Object.keys(APP_CFG_DEFAULT).forEach(k => {
    APP_CFG[k] = d[k] !== undefined ? d[k] : JSON.parse(JSON.stringify(APP_CFG_DEFAULT[k]));
  });
}

// Efectivo y Cuenta Corriente son fijos: el sistema los usa para la caja y para el saldo de clientes
const METODO_EFECTIVO = { nombre:"Efectivo",         icono:"💵", corto:"Efectivo",       fijo:true };
const METODO_CTACTE   = { nombre:"Cuenta Corriente", icono:"📒", corto:"Cta. Corriente", fijo:true };
function getMetodosPago() {
  return [METODO_EFECTIVO, ...(APP_CFG.metodosPago||[]).filter(m => m && m.nombre), METODO_CTACTE];
}
function labelMetodo(nombre) {
  const m = getMetodosPago().find(x => x.nombre === nombre);
  return m ? `${m.icono||""} ${m.corto||m.nombre}`.trim() : nombre;
}
const COLORES_METODO = [
  { color:"#2e7d32", bg:"#e8f5e9" }, { color:"#1565c0", bg:"#e3f2fd" }, { color:"#6a1b9a", bg:"#f3e5f5" },
  { color:"#00695c", bg:"#e0f2f1" }, { color:"#ad1457", bg:"#fce4ec" }, { color:"#f57f17", bg:"#fff8e1" },
  { color:"#37474f", bg:"#eceff1" },
];
// Métodos configurados + los que aparezcan en ventas viejas (para no perder historial)
function metodosConHistorial(ventas) {
  const base = getMetodosPago().map(m => m.nombre);
  const extra = [...new Set((ventas||[]).map(v => v.metodoPago).filter(Boolean))].filter(n => !base.includes(n));
  return [...base, ...extra].map((nombre, i) => ({
    nombre, label: labelMetodo(nombre),
    ...(nombre==="Cuenta Corriente" ? { color:"#e65100", bg:"#fff3e0" } : COLORES_METODO[i % COLORES_METODO.length]),
  }));
}

// Arma el mensaje de WhatsApp de "pedido listo" a partir de la plantilla
function armarMensajeListo(p) {
  const total    = parseFloat(p.precio||0);
  const saldoNum = total - parseFloat(p.seña||0);
  const plantilla = saldoNum > 0 ? APP_CFG.msgListoSaldo : APP_CFG.msgListoPago;
  const valores = {
    nombre: p.cliente?.split(" ")[0] || p.cliente || "cliente",
    cliente: p.cliente || "",
    ot:     p.nroOT ? `N° ${String(p.nroOT).padStart(4,"0")} - ` : "",
    pedido: p.nombre || "",
    total:  total.toLocaleString("es-AR"),
    saldo:  saldoNum.toLocaleString("es-AR"),
    seña:   parseFloat(p.seña||0).toLocaleString("es-AR"),
  };
  return (plantilla||"").split("\n")
    // si el pedido no tiene precio, se omiten los renglones que hablan de plata
    .filter(l => p.precio || !/\{(total|saldo|seña)\}/.test(l))
    .map(l => l.replace(/\{(\w+)\}/g, (m, k) => valores[k] !== undefined ? valores[k] : m))
    .join("\n");
}

// Arma el número para wa.me: si ya trae código de país lo respeta, si no le agrega el prefijo configurado
function telWhatsapp(tel) {
  let d = (tel||"").replace(/\D/g,"");
  if (!d) return "";
  const pref = (APP_CFG.prefijoWhatsapp||"").replace(/\D/g,"");
  if (pref && d.startsWith(pref.slice(0,2))) return d;   // ya tiene código de país (ej: 54...)
  d = d.replace(/^0/, "");
  return pref + d;
}

const ESTADOS = ["Todos", "Pendiente", "En Producción", "Listo", "Entregado"];
const ESTADO_COLOR = {
  Pendiente:        { bg: "#f5f5f5", text: "#616161" },
  "En Producción":  { bg: "#fff3e0", text: "#bf360c" },
  Listo:            { bg: "#fff8e1", text: "#f57f17" },
  Entregado:        { bg: "#e8f5e9", text: "#1b5e20" },
};

const EMPTY_FORM = {
  nombre: "", cliente: "", telefono: "", categoria: "",
  estado: "Pendiente", fechaPedido: "", fechaEntrega: "", precio: "",
  seña: "", notas: "", notasItems: [""], tomadoPor: ""
};



const EMPTY_CLIENTE = {
  nombre: "", apellido: "", empresa: "", cuit: "",
  direccion: "", telefono: "", mail: "", saldoCuenta: 0
};

const EMPTY_EMPRESA = {
  nombre: "Mafalda Gráfica", titular: "", cuit: "",
  direccion: "", telefono: "", logo: ""
};

// Formatear fecha YYYY-MM-DD → DD/MM/YYYY
const fmtFecha = (f) => {
  if (!f) return "—";
  const [y,m,d] = f.split("-");
  return `${d}/${m}/${y}`;
};

// ── HTML de la orden de trabajo para imprimir ──────────────────────────────
function buildOrdenHTML(p, empresa = EMPTY_EMPRESA) {
  const saldo = parseFloat(p.precio || 0) - parseFloat(p.seña || 0);
  const now   = new Date();
  const fecha = now.toLocaleDateString("es-AR", { day: "2-digit", month: "2-digit", year: "numeric" });
  const hora  = now.toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" });
  const num   = p.nroOT ? `OT-${String(p.nroOT).padStart(4, "0")}` : p.id ? `OT-${String(p.id).padStart(4, "0")}` : `OT-????`;
  const nombre = empresa.nombre || "Mafalda Gráfica";

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"/>
<title>Orden ${num} — ${nombre}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}#root{width:100%;min-height:100vh;display:flex;flex-direction:column}
  body{font-family:'DM Sans',sans-serif;background:#fff;color:#1a2340}
  .page{width:210mm;min-height:148mm;margin:0 auto;padding:20mm 20mm 16mm}
  .hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:13px;border-bottom:3px solid #e65100;margin-bottom:16px}
  .hdr-left{display:flex;align-items:center;gap:14px}
  .logo-img{width:60px;height:60px;object-fit:contain;border-radius:8px}
  .brand{font-family:'DM Sans',sans-serif;font-size:24px;font-weight:800;color:#e65100}
  .brand-data{font-size:11px;color:#8a7060;margin-top:3px;line-height:1.6}
  .onum{font-family:'DM Sans',sans-serif;font-size:20px;font-weight:800;color:#e65100;text-align:right}
  .ofecha{font-size:11px;color:#a09080;text-align:right;margin-top:3px}
  .banner{background:#fff3e0;color:#bf360c;text-align:center;padding:7px 0;border-radius:6px;font-weight:700;font-size:13px;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:16px}
  .ped{background:#fff8f5;border-radius:8px;padding:12px 15px;margin-bottom:14px}
  .ped-lbl{font-size:10px;font-weight:600;color:#a09080;text-transform:uppercase;letter-spacing:.7px;margin-bottom:4px}
  .ped-nom{font-family:'DM Sans',sans-serif;font-size:18px;font-weight:700;color:#1a2340}
  .ped-cat{display:inline-block;margin-top:5px;font-size:12px;font-weight:600;color:#e65100;background:#dde6ff;padding:3px 10px;border-radius:20px}
  .igrid{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-bottom:13px}
  .ibox{background:#fffaf7;border-radius:7px;padding:9px 12px;border-left:3px solid #e65100}
  .ilbl{font-size:10px;font-weight:600;color:#a09080;text-transform:uppercase;letter-spacing:.7px;margin-bottom:3px}
  .ival{font-size:14px;font-weight:600;color:#1a2340}
  .notas{border:1.5px dashed #c5cce0;border-radius:7px;padding:10px 13px;margin-bottom:13px;min-height:44px}
  .ntit{font-size:10px;font-weight:600;color:#a09080;text-transform:uppercase;letter-spacing:.7px;margin-bottom:4px}
  .ntxt{font-size:13px;color:#4a5568;line-height:1.5}
  .fgrid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:9px;margin-bottom:16px}
  .fbox{text-align:center;background:#fffaf7;border-radius:7px;padding:9px 7px}
  .flbl{font-size:10px;font-weight:600;color:#a09080;text-transform:uppercase;letter-spacing:.6px;margin-bottom:4px}
  .fval{font-family:'DM Sans',sans-serif;font-size:17px;font-weight:700}
  .foot{border-top:1.5px solid #edf0f7;padding-top:11px;display:flex;justify-content:space-between;align-items:flex-end}
  .firma{text-align:center}
  .flin{width:160px;border-bottom:1.5px solid #8a93a8;margin-bottom:4px;height:26px}
  .flbl2{font-size:10px;color:#a09080;text-transform:uppercase;letter-spacing:.6px}
  .fnota{font-size:10px;color:#a09080;text-align:right;line-height:1.6}
  @media print{body{padding:0}.page{padding:12mm 14mm 10mm}}
</style>
</head>
<body>
<div class="page">
  <div class="hdr">
    <div class="hdr-left">
      ${empresa.logo ? `<img class="logo-img" src="${empresa.logo}" alt="Logo"/>` : ""}
      <div>
        <div class="brand">${nombre}</div>
        <div class="brand-data">
          ${empresa.titular ? `<span>Titular: ${empresa.titular}</span><br/>` : ""}
          ${empresa.cuit ? `<span>CUIT: ${empresa.cuit}</span><br/>` : ""}
          ${empresa.direccion ? `<span>📍 ${empresa.direccion}</span><br/>` : ""}
          ${empresa.telefono ? `<span>📞 ${empresa.telefono}</span>` : ""}
        </div>
      </div>
    </div>
    <div>
      <div class="onum">${num}</div>
      <div class="ofecha">Emitida: ${fecha} — ${hora}</div>
    </div>
  </div>
  <div class="banner">⚙️ &nbsp; En Producción</div>
  <div class="ped">
    <div class="ped-lbl">Descripción del pedido</div>
    <div class="ped-nom">${p.nombre}</div>
    <span class="ped-cat">${CATEGORIA_ICON[p.categoria]} ${p.categoria}</span>
  </div>
  <div class="igrid">
    <div class="ibox"><div class="ilbl">🏢 Cliente</div><div class="ival">${p.cliente}</div></div>
    <div class="ibox"><div class="ilbl">📞 Teléfono</div><div class="ival">${p.telefono || "—"}</div></div>
    <div class="ibox"><div class="ilbl">📅 Fecha de Pedido</div><div class="ival">${p.fechaPedido || "—"}</div></div>
    <div class="ibox"><div class="ilbl">🏁 Fecha de Entrega</div><div class="ival" style="color:${p.fechaEntrega < new Date().toISOString().split('T')[0] ? '#c62828':'#1a2340'}">${p.fechaEntrega ? p.fechaEntrega.split("-").reverse().join("/") : "—"}</div></div>
    ${p.tomadoPor ? `<div class="ibox" style="grid-column:1/-1"><div class="ilbl">👤 Tomado por</div><div class="ival">${p.tomadoPor}</div></div>` : ""}
  </div>
  <div class="notas">
    <div class="ntit">📝 Especificaciones / Notas</div>
    <div class="ntxt">${p.notas
      ? p.notas.split("\n").filter(x=>x.trim()).map((l,i)=>`<span style="display:flex;gap:6px;margin-bottom:3px;"><span style="color:#a09080;min-width:16px;">${i+1}.</span><span>${l}</span></span>`).join("")
      : "Sin notas adicionales."
    }</div>
  </div>
  <div class="fgrid">
    <div class="fbox"><div class="flbl">Precio Total</div><div class="fval" style="color:#1a2340">$${parseFloat(p.precio||0).toLocaleString("es-AR")}</div></div>
    <div class="fbox"><div class="flbl">Seña / Adelanto</div><div class="fval" style="color:#2e7d32">$${parseFloat(p.seña||0).toLocaleString("es-AR")}</div></div>
    <div class="fbox"><div class="flbl">Saldo a Cobrar</div><div class="fval" style="color:${saldo>0?'#c62828':'#2e7d32'}">$${saldo.toLocaleString("es-AR")}</div></div>
  </div>
  ${APP_CFG.pieOrden?`<div style="font-size:11px;color:#4a5568;margin:14px 0 4px;padding:8px 12px;border:1px dashed #d0d0d0;border-radius:6px;white-space:pre-wrap">${APP_CFG.pieOrden}</div>`:""}
  <div class="foot">
    <div class="firma"><div class="flin"></div><div class="flbl2">${APP_CFG.firmaOrden||"Firma operario"}</div></div>
    <div class="fnota">${nombre} · Sistema de Pedidos<br/>${num} · ${fecha}</div>
  </div>
</div>
<script>window.onload=()=>window.print();</script>
</body>
</html>`;
}

function imprimirOrden(p, empresa) {
  const html = buildOrdenHTML(p, empresa);
  const win  = window.open("", "_blank", "width:920,height:700");
  if (!win) { alert("Habilitá los popups del navegador para imprimir la orden."); return; }
  win.document.write(html);
  win.document.close();
}

// ── Componente: Kanban ────────────────────────────────────────────────────
function KanbanView({ pedidos, handleEstadoChange, handleEdit, handleDelete, setSelectedPedido, setView, CATEGORIA_COLOR, CATEGORIA_ICON, ESTADO_COLOR, isVencido, isHoy }) {
  const cols = ["Pendiente", "En Producción", "Listo"];
  const activePedidos = pedidos.filter(p => p.estado !== "Entregado");

  return (
    <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:16, alignItems:"start" }}>
      {cols.map(col => {
        const ec    = ESTADO_COLOR[col];
        const items = activePedidos.filter(p => p.estado === col)
          .sort((a,b) => (!a.fechaEntrega?1:!b.fechaEntrega?-1:a.fechaEntrega.localeCompare(b.fechaEntrega)));
        const colAccent = col==="Pendiente"?"#9e9e9e":col==="En Producción"?"#1976d2":"#f57f17";
        return (
          <div key={col}>
            {/* Col header */}
            <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12, padding:"10px 14px", background:"#fff", borderRadius:10, boxShadow:"0 2px 8px rgba(230,81,0,.07)", borderTop:`3px solid ${colAccent}` }}>
              <span style={{ background:ec.bg, color:ec.text, padding:"4px 10px", borderRadius:20, fontSize:12, fontWeight:700 }}>{col}</span>
              <span style={{ background:colAccent, color:"#fff", borderRadius:"50%", width:20, height:20, display:"inline-flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, marginLeft:"auto" }}>{items.length}</span>
            </div>
            {/* Cards */}
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {items.length === 0 ? (
                <div style={{ border:"2px dashed #e0e5f0", borderRadius:10, padding:"24px 16px", textAlign:"center", color:"#d4bfb0", fontSize:13 }}>Sin pedidos</div>
              ) : items.map(p => {
                const cc  = CATEGORIA_COLOR[p.categoria];
                const ven = isVencido(p);
                const hf  = isHoy(p);
                return (
                  <div key={p.fireId||p.id} onClick={() => { setSelectedPedido(p); setView("detalle"); }}
                    style={{ background:"#fff", borderRadius:10, padding:"14px 15px", boxShadow:"0 2px 10px rgba(230,81,0,.08)", cursor:"pointer", borderLeft:`3px solid ${cc.accent}`, transition:"transform .15s, box-shadow .15s", position:"relative" }}
                    onMouseOver={e => { e.currentTarget.style.transform="translateY(-2px)"; e.currentTarget.style.boxShadow="0 6px 18px rgba(230,81,0,.13)"; }}
                    onMouseOut={e  => { e.currentTarget.style.transform="translateY(0)";   e.currentTarget.style.boxShadow="0 2px 10px rgba(230,81,0,.08)"; }}>
                    {/* Categoria badge */}
                    <span style={{ background:cc.bg, color:cc.text, fontSize:11, fontWeight:600, padding:"2px 8px", borderRadius:20, display:"inline-block", marginBottom:8 }}>
                      {CATEGORIA_ICON[p.categoria]} {p.categoria}
                    </span>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
                      <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", lineHeight:1.3 }}>{p.nombre}</div>
                      {p.nroOT && <span style={{ fontSize:10, fontWeight:700, color:"#e65100", fontFamily:"monospace", background:"#fff8f5", padding:"2px 6px", borderRadius:4, border:"1px solid #f0d5c0" }}>OT-{String(p.nroOT).padStart(4,"0")}</span>}
                    </div>
                    <div style={{ fontSize:12, color:"#8a7060", marginBottom:8 }}>👤 {p.cliente}</div>
                    {/* Fecha entrega */}
                    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                      <span style={{ fontSize:11, fontWeight:600, color:ven?"#c62828":hf?"#f57f17":"#8a93a8", background:ven?"#ffebee":hf?"#fff8e1":"#f8faff", padding:"3px 8px", borderRadius:6 }}>
                        {ven?"⚠️ ":hf?"📍 ":"📅 "}{fmtFecha(p.fechaEntrega)||"S/F"}
                      </span>
                      {p.precio && (
                        <span style={{ fontSize:12, fontWeight:700, color:"#1a2340" }}>
                          ${parseFloat(p.precio).toLocaleString("es-AR")}
                        </span>
                      )}
                    </div>
                    {/* Actions */}
                    <div style={{ display:"flex", gap:5, marginTop:10, paddingTop:10, borderTop:"1px solid #f0f3f9" }} onClick={e => e.stopPropagation()}>
                      <select value={p.estado} onChange={e => handleEstadoChange(p.fireId || p.id, e.target.value)}
                        style={{ flex:1, padding:"4px 6px", borderRadius:6, fontSize:11, fontWeight:600, border:`1.5px solid ${cc.accent}22`, background:ec.bg, color:ec.text, cursor:"pointer", fontFamily:"'DM Sans',sans-serif" }}>
                        {["Pendiente","En Producción","Listo","Entregado"].map(s=><option key={s}>{s}</option>)}
                      </select>
                      <button style={{ background:"transparent", border:"1.5px solid #f0d5c0", color:"#4a5568", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }} onClick={() => handleEdit(p)}>✏️</button>
                      <button style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }} onClick={() => handleDelete(p.fireId || p.id)}>🗑</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Chip de pedido para calendario ───────────────────────────────────────
function PedidoChip({ p, ven, setSelectedPedido, setView, CATEGORIA_COLOR }) {
  const cc = CATEGORIA_COLOR[p.categoria];
  return (
    <div onClick={e => { e.stopPropagation(); setSelectedPedido(p); setView("detalle"); }}
      style={{ background:ven?"#ffebee":cc.bg, borderLeft:`2px solid ${ven?"#c62828":cc.accent}`, borderRadius:4, padding:"2px 5px", marginBottom:2, cursor:"pointer", fontSize:10, fontWeight:600, color:ven?"#c62828":cc.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}
      title={`${p.nombre} — ${p.cliente}`}>
      {p.nombre}
    </div>
  );
}

// ── Contador global de OT ────────────────────────────────────────────────
async function getNextNroOT() {
  try {
    const ref  = doc(db, "config", "contadores");
    const snap = await getDoc(ref);
    const actual   = snap.exists() ? (snap.data().nroOT || 0) : 0;
    const siguiente = actual + 1;
    await setDoc(ref, { nroOT: siguiente }, { merge: true });
    return siguiente;
  } catch(e) {
    console.error("Error generando nroOT:", e);
    return null; // si falla, guarda sin número
  }
}

// ── Componente: Calendario ────────────────────────────────────────────────
function CalendarioView({ pedidos, setSelectedPedido, setView, CATEGORIA_COLOR, CATEGORIA_ICON, ESTADO_COLOR, isVencido }) {
  const [modoCalendario, setModoCalendario] = useState("semana");
  const [fechaBase, setFechaBase]           = useState(new Date());

  const activePedidos = pedidos.filter(p => p.estado !== "Entregado" && p.fechaEntrega);

  const pedidosPorFecha = useMemo(() => {
    const map = {};
    activePedidos.forEach(p => {
      if (!map[p.fechaEntrega]) map[p.fechaEntrega] = [];
      map[p.fechaEntrega].push(p);
    });
    return map;
  }, [activePedidos]);

  const fmtFecha = (d) => d.toISOString().split("T")[0];
  const hoy      = fmtFecha(new Date());

  const moverFecha = (dir) => {
    const d = new Date(fechaBase);
    if (modoCalendario === "dia")    d.setDate(d.getDate() + dir);
    if (modoCalendario === "semana") d.setDate(d.getDate() + dir * 7);
    if (modoCalendario === "mes")    d.setMonth(d.getMonth() + dir);
    setFechaBase(d);
  };

  // Días a mostrar según modo
  const diasAMostrar = useMemo(() => {
    if (modoCalendario === "dia") {
      return [new Date(fechaBase)];
    }
    if (modoCalendario === "semana") {
      const lunes = new Date(fechaBase);
      lunes.setDate(lunes.getDate() - ((lunes.getDay()+6)%7));
      return Array.from({length:7}, (_,i) => { const d=new Date(lunes); d.setDate(d.getDate()+i); return d; });
    }
    // mes
    const año   = fechaBase.getFullYear();
    const mes   = fechaBase.getMonth();
    const first = new Date(año, mes, 1);
    const last  = new Date(año, mes+1, 0);
    const start = new Date(first); start.setDate(start.getDate() - ((start.getDay()+6)%7));
    const end   = new Date(last);  end.setDate(end.getDate() + (6-(end.getDay()+6)%7));
    const dias  = [];
    const cur   = new Date(start);
    while (cur <= end) { dias.push(new Date(cur)); cur.setDate(cur.getDate()+1); }
    return dias;
  }, [modoCalendario, fechaBase]);

  const tituloNavegacion = () => {
    if (modoCalendario === "dia") return fechaBase.toLocaleDateString("es-AR", { weekday:"long", day:"numeric", month:"long", year:"numeric" });
    if (modoCalendario === "semana") {
      const lunes  = diasAMostrar[0];
      const dom    = diasAMostrar[6];
      return `${lunes.getDate()} ${lunes.toLocaleDateString("es-AR",{month:"short"})} — ${dom.getDate()} ${dom.toLocaleDateString("es-AR",{month:"short", year:"numeric"})}`;
    }
    return fechaBase.toLocaleDateString("es-AR", { month:"long", year:"numeric" });
  };

  const DIAS_SEMANA = ["Lun","Mar","Mié","Jue","Vie","Sáb","Dom"];

  return (
    <div>
      {/* Controles */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16, flexWrap:"wrap", gap:10 }}>
        <div style={{ display:"flex", gap:6 }}>
          {["dia","semana","mes"].map(m => (
            <button key={m} onClick={() => setModoCalendario(m)}
              style={{ padding:"7px 16px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif", transition:"all .18s",
                background:modoCalendario===m?"#e65100":"#fff",
                color:modoCalendario===m?"#fff":"#4a5568",
                boxShadow:modoCalendario===m?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
              {m==="dia"?"Día":m==="semana"?"Semana":"Mes"}
            </button>
          ))}
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={() => moverFecha(-1)} style={{ background:"#fff", border:"1.5px solid #f0d5c0", color:"#1a2340", width:34, height:34, borderRadius:8, fontSize:16, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>‹</button>
          <span style={{ fontFamily:"'DM Sans',sans-serif", fontWeight:700, fontSize:16, color:"#1a2340", minWidth:220, textAlign:"center", textTransform:"capitalize" }}>{tituloNavegacion()}</span>
          <button onClick={() => moverFecha(1)}  style={{ background:"#fff", border:"1.5px solid #f0d5c0", color:"#1a2340", width:34, height:34, borderRadius:8, fontSize:16, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>›</button>
          <button onClick={() => setFechaBase(new Date())} style={{ padding:"7px 14px", borderRadius:8, fontSize:12, fontWeight:600, border:"1.5px solid #e65100", color:"#e65100", background:"#fff", cursor:"pointer", fontFamily:"'DM Sans',sans-serif" }}>Hoy</button>
        </div>
      </div>

      {/* Grilla */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
        {/* Cabecera días de semana (solo mes/semana) */}
        {modoCalendario !== "dia" && (
          <div style={{ display:"grid", gridTemplateColumns:`repeat(${modoCalendario==="semana"?7:7}, 1fr)`, borderBottom:"2px solid #edf0f7" }}>
            {DIAS_SEMANA.map(d => (
              <div key={d} style={{ padding:"10px 8px", textAlign:"center", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px" }}>{d}</div>
            ))}
          </div>
        )}

        {/* Modo día */}
        {modoCalendario === "dia" && (() => {
          const fecha = fmtFecha(diasAMostrar[0]);
          const ps    = pedidosPorFecha[fecha] || [];
          const esHoy = fecha === hoy;
          return (
            <div style={{ padding:"24px 28px" }}>
              <div style={{ marginBottom:16, display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:esHoy?"#e65100":"#1a2340" }}>
                  {diasAMostrar[0].toLocaleDateString("es-AR",{weekday:"long",day:"numeric",month:"long"})}
                </div>
                {esHoy && <span style={{ background:"#e65100", color:"#fff", padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:700 }}>Hoy</span>}
                <span style={{ background:"#fff8f5", color:"#4a5568", padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:600 }}>{ps.length} pedido{ps.length!==1?"s":""}</span>
              </div>
              {ps.length === 0 ? (
                <div style={{ textAlign:"center", padding:"40px 0", color:"#d4bfb0", fontSize:14 }}>Sin pedidos para este día</div>
              ) : (
                <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                  {ps.map(p => {
                    const cc = CATEGORIA_COLOR[p.categoria];
                    const ec = ESTADO_COLOR[p.estado];
                    return (
                      <div key={p.fireId||p.id} onClick={() => { setSelectedPedido(p); setView("detalle"); }}
                        style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 18px", borderRadius:10, border:`1.5px solid ${cc.accent}22`, background:cc.bg+"44", cursor:"pointer", transition:"box-shadow .15s" }}
                        onMouseOver={e=>e.currentTarget.style.boxShadow="0 4px 14px rgba(230,81,0,.12)"}
                        onMouseOut={e=>e.currentTarget.style.boxShadow="none"}>
                        <span style={{ fontSize:22 }}>{CATEGORIA_ICON[p.categoria]}</span>
                        <div style={{ flex:1 }}>
                          <div style={{ fontWeight:700, color:"#1a2340", fontSize:14 }}>{p.nombre}</div>
                          <div style={{ fontSize:12, color:"#8a7060" }}>👤 {p.cliente} {p.telefono && <span style={{ fontWeight:700, color:"#e65100" }}>· 📞 {p.telefono}</span>}</div>
                        </div>
                        <span style={{ background:ec.bg, color:ec.text, padding:"4px 10px", borderRadius:20, fontSize:12, fontWeight:600, whiteSpace:"nowrap" }}>{p.estado}</span>
                        {p.precio && <span style={{ fontWeight:700, fontSize:13, color:"#1a2340" }}>${parseFloat(p.precio).toLocaleString("es-AR")}</span>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })()}

        {/* Modo semana / mes */}
        {modoCalendario !== "dia" && (
          <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)" }}>
            {diasAMostrar.map((d, i) => {
              const fecha   = fmtFecha(d);
              const ps      = pedidosPorFecha[fecha] || [];
              const esHoy   = fecha === hoy;
              const esMes   = d.getMonth() === fechaBase.getMonth();
              const domingo = (d.getDay() === 0);
              return (
                <div key={i} style={{
                  minHeight: modoCalendario==="mes" ? 110 : 160,
                  padding:"8px 8px 6px",
                  borderRight: i%7!==6 ? "1px solid #f0f3f9" : "none",
                  borderBottom:"1px solid #f0f3f9",
                  background: esHoy ? "#eef2ff" : !esMes ? "#fafafa" : "#fff",
                  opacity: !esMes ? .6 : 1,
                }}>
                  <div style={{ marginBottom:5, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                    <span style={{ fontSize:12, fontWeight:700, width:24, height:24, display:"inline-flex", alignItems:"center", justifyContent:"center", borderRadius:"50%",
                      background:esHoy?"#e65100":"transparent", color:esHoy?"#fff":domingo?"#c62828":"#4a5568" }}>
                      {d.getDate()}
                    </span>
                    {ps.length > 0 && <span style={{ fontSize:10, fontWeight:700, color:"#e65100", background:"#ffe8d6", borderRadius:10, padding:"1px 5px" }}>{ps.length}</span>}
                  </div>
                  <div>
                    {(modoCalendario==="mes" ? ps.slice(0,2) : ps).map(p => <PedidoChip key={p.id} p={p} cc={CATEGORIA_COLOR[p.categoria]} ven={isVencido(p)} setSelectedPedido={setSelectedPedido} setView={setView} CATEGORIA_COLOR={CATEGORIA_COLOR} />)}
                    {modoCalendario==="mes" && ps.length > 2 && (
                      <div style={{ fontSize:10, color:"#a09080", fontWeight:600, paddingLeft:4 }}>+{ps.length-2} más</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Leyenda */}
      <div style={{ marginTop:14, display:"flex", gap:16, flexWrap:"wrap", fontSize:12, color:"#a09080", alignItems:"center" }}>
        <span>Leyenda:</span>
        <span style={{ display:"flex", alignItems:"center", gap:4 }}><span style={{ width:10, height:10, borderRadius:2, background:"#fff3e0", border:"1.5px solid #e65100", display:"inline-block" }}></span> Hoy</span>
        <span style={{ display:"flex", alignItems:"center", gap:4 }}><span style={{ width:10, height:10, borderRadius:2, background:"#ffebee", border:"1.5px solid #c62828", display:"inline-block" }}></span> Vencido</span>
        <span style={{ display:"flex", alignItems:"center", gap:4 }}><span style={{ width:10, height:10, borderRadius:2, background:"#fafafa", border:"1.5px solid #f0d5c0", display:"inline-block" }}></span> Fuera del mes</span>
      </div>
    </div>
  );
}


function PedidosListos({ pedidos, saldo, isHoy, handleEstadoChange, handleDelete, setMsgModal, CATEGORIA_COLOR, CATEGORIA_ICON, inp, empresa, setView, clientes, setClienteDestacado, showToast, onEntregarVarios }) {
  const [seleccion, setSeleccion] = useState([]); // fireIds seleccionados
  const [busqL, setBusqL]         = useState("");
  const [busqH, setBusqH]         = useState("");
  const [tabActiva, setTabActiva] = useState("listos");
  const [pedidoDetalle, setPedidoDetalle] = useState(null); // para ver orden vieja

  const listos = pedidos
    .filter(p => p.estado === "Listo")
    .sort((a,b) => (!a.fechaEntrega?1:!b.fechaEntrega?-1:a.fechaEntrega.localeCompare(b.fechaEntrega)));

  const filtrados = listos.filter(p => {
    const q = busqL.toLowerCase();
    return !busqL || p.nombre.toLowerCase().includes(q) || p.cliente.toLowerCase().includes(q);
  });

  const totalCobrar = listos.reduce((s,p) => s + saldo(p), 0);

  // Selección: solo cuenta los que siguen listos (se limpia sola al entregar)
  const seleccionados   = listos.filter(p => seleccion.includes(p.fireId));
  const totalSelec      = seleccionados.reduce((s,p) => s + saldo(p), 0);
  const todosVisiblesSel = filtrados.length > 0 && filtrados.every(p => seleccion.includes(p.fireId));
  const toggleSel = (id) => setSeleccion(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id]);
  const toggleTodos = () => setSeleccion(prev => todosVisiblesSel
    ? prev.filter(id => !filtrados.some(p => p.fireId===id))
    : [...new Set([...prev, ...filtrados.map(p=>p.fireId)])]);
  const chk = { width:18, height:18, accentColor:"#e65100", cursor:"pointer" };

  const entregados = pedidos
    .filter(p => p.estado === "Entregado")
    .sort((a,b) => b.fechaEntrega?.localeCompare(a.fechaEntrega||"")||0);

  const entregadosFiltrados = entregados.filter(p => {
    const q = busqH.toLowerCase();
    return !busqH || p.nombre.toLowerCase().includes(q) || p.cliente.toLowerCase().includes(q) || p.telefono?.includes(busqH);
  });

  // Navegar a ficha de cliente
  const irACliente = (p) => {
    if (!p.clienteId) return;
    const cl = clientes.find(c => c.fireId === p.clienteId);
    if (cl && setClienteDestacado) setClienteDestacado(cl);
    if (setView) setView("clientes");
  };

  // Botón de cliente clickeable
  const ClienteLink = ({ p }) => (
    <div
      onClick={() => irACliente(p)}
      style={{ cursor: p.clienteId?"pointer":"default", display:"inline-block" }}
      title={p.clienteId?"Ver ficha del cliente":""}>
      <div style={{ fontWeight:600, color: p.clienteId?"#e65100":"#1a2340",
        textDecoration: p.clienteId?"underline":"none" }}>
        {p.cliente}
        {p.clienteId && <span style={{ fontSize:10, marginLeft:4 }}>→</span>}
      </div>
      {p.telefono && <div style={{ fontSize:12, fontWeight:700, color:"#e65100", marginTop:2 }}>📞 {p.telefono}</div>}
    </div>
  );

  return (
    <div>
      {/* Tabs */}
      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        <button onClick={()=>setTabActiva("listos")}
          style={{ padding:"9px 20px", borderRadius:20, fontSize:14, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
            background:tabActiva==="listos"?"#e65100":"#fff", color:tabActiva==="listos"?"#fff":"#4a5568",
            boxShadow:tabActiva==="listos"?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
          ✅ Listos para entregar
          {listos.length > 0 && <span style={{ marginLeft:7, background:tabActiva==="listos"?"rgba(255,255,255,.3)":"#fff3e0", color:tabActiva==="listos"?"#fff":"#e65100", borderRadius:20, padding:"0 7px", fontSize:12, fontWeight:700 }}>{listos.length}</span>}
        </button>
        <button onClick={()=>setTabActiva("historial")}
          style={{ padding:"9px 20px", borderRadius:20, fontSize:14, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
            background:tabActiva==="historial"?"#1a2340":"#fff", color:tabActiva==="historial"?"#fff":"#4a5568",
            boxShadow:tabActiva==="historial"?"0 3px 10px rgba(26,35,64,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
          📦 Historial de Entregados
          {entregados.length > 0 && <span style={{ marginLeft:7, background:tabActiva==="historial"?"rgba(255,255,255,.2)":"#f0f3f9", color:tabActiva==="historial"?"#fff":"#4a5568", borderRadius:20, padding:"0 7px", fontSize:12, fontWeight:700 }}>{entregados.length}</span>}
        </button>
      </div>

      {/* ── TAB: LISTOS ── */}
      {tabActiva === "listos" && (
        <div>
          <div style={{ display:"flex", gap:12, marginBottom:18, flexWrap:"wrap" }}>
            <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"12px 20px", textAlign:"center" }}>
              <div style={{ fontSize:10, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:4 }}>Pedidos listos</div>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:26, fontWeight:700, color:"#f57f17" }}>{listos.length}</div>
            </div>
            <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"12px 20px", textAlign:"center" }}>
              <div style={{ fontSize:10, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:4 }}>Por cobrar</div>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:"#c62828" }}>${totalCobrar.toLocaleString("es-AR")}</div>
            </div>
          </div>

          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18 }}>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", fontSize:15 }}>🔍</span>
              <input placeholder="Buscar por pedido o cliente..." value={busqL} onChange={e=>setBusqL(e.target.value)}
                style={{ ...inp(), paddingLeft:34, width:"100%" }}/>
            </div>
          </div>

          {seleccionados.length > 0 && (
            <div style={{ position:"sticky", top:8, zIndex:20, background:"#1a2340", borderRadius:12, padding:"12px 18px", marginBottom:14,
              display:"flex", alignItems:"center", gap:14, flexWrap:"wrap", boxShadow:"0 6px 20px rgba(26,35,64,.25)" }}>
              <span style={{ color:"#fff", fontWeight:700, fontSize:14 }}>
                {seleccionados.length} seleccionado{seleccionados.length!==1?"s":""}
              </span>
              <span style={{ color:"#ffcc80", fontSize:13 }}>Saldo a cobrar: <b>${totalSelec.toLocaleString("es-AR")}</b></span>
              <div style={{ marginLeft:"auto", display:"flex", gap:8 }}>
                <button onClick={()=>setSeleccion([])}
                  style={{ background:"transparent", border:"1.5px solid rgba(255,255,255,.35)", color:"#fff", padding:"8px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>
                  Limpiar
                </button>
                <button onClick={()=>onEntregarVarios && onEntregarVarios(seleccionados)}
                  style={{ background:"#e65100", border:"none", color:"#fff", padding:"8px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
                  📦 Entregar seleccionados
                </button>
              </div>
            </div>
          )}

          {filtrados.length === 0 ? (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px 24px", textAlign:"center" }}>
              <div style={{ fontSize:40, marginBottom:14 }}>🎉</div>
              <div style={{ fontWeight:700, fontSize:18, fontFamily:"'DM Sans',sans-serif", marginBottom:6 }}>
                {listos.length === 0 ? "No hay pedidos listos aún" : "Sin resultados"}
              </div>
              <div style={{ color:"#a09080", fontSize:14 }}>
                {listos.length === 0 ? "Cuando un pedido pase a 'Listo' aparecerá aquí" : "Probá con otro término"}
              </div>
            </div>
          ) : (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
                <thead>
                  <tr style={{ background:"#fffaf7" }}>
                    <th style={{ padding:"11px 6px 11px 16px", width:30, borderBottom:"1px solid #f5e8e0" }}>
                      <input type="checkbox" checked={todosVisiblesSel} onChange={toggleTodos} title="Seleccionar todos" style={chk}/>
                    </th>
                    {["Pedido","Categoría","Cliente","Fecha Entrega","Total","Saldo","Acciones"].map(h=>(
                      <th key={h} style={{ padding:"11px 16px", textAlign:"left", fontWeight:600, fontSize:11, color:"#8a7060", textTransform:"uppercase", letterSpacing:".6px", whiteSpace:"nowrap", borderBottom:"1px solid #f5e8e0" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtrados.map(p => {
                    const cc = CATEGORIA_COLOR[p.categoria];
                    const hf = isHoy(p);
                    return (
                      <tr key={p.fireId||p.id} style={{ borderBottom:"1px solid #fef0e8",
                        background: seleccion.includes(p.fireId) ? "#fff3e0" : hf?"#fffdf0":"#fff" }}>
                        <td style={{ padding:"13px 6px 13px 16px" }}>
                          <input type="checkbox" checked={seleccion.includes(p.fireId)} onChange={()=>toggleSel(p.fireId)} style={chk}/>
                        </td>
                        <td style={{ padding:"13px 16px" }}>
                          <div style={{ fontWeight:600, color:"#1a2340" }}>{p.nombre}</div>
                          {p.notas && <div style={{ fontSize:11, color:"#a09080", marginTop:2, maxWidth:200, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{p.notas}</div>}
                        </td>
                        <td style={{ padding:"13px 16px" }}>
                          <span style={{ background:cc.bg, color:cc.text, padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:600, whiteSpace:"nowrap" }}>{CATEGORIA_ICON[p.categoria]} {p.categoria}</span>
                        </td>
                        <td style={{ padding:"13px 16px", whiteSpace:"nowrap" }}>
                          <ClienteLink p={p}/>
                        </td>
                        <td style={{ padding:"13px 16px", whiteSpace:"nowrap" }}>
                          <span style={{ fontWeight:600, color:hf?"#f57f17":"#1a2340" }}>{hf&&"📍 "}{fmtFecha(p.fechaEntrega)||"—"}</span>
                          {hf && <div style={{ fontSize:11, color:"#f57f17" }}>Hoy</div>}
                        </td>
                        <td style={{ padding:"8px 16px", whiteSpace:"nowrap" }}>
                          <InlineEditPrecio
                            value={p.precio||""}
                            color="#1a2340"
                            size={15}
                            onSave={async (val) => {
                              await updateDoc(doc(db,"pedidos",p.fireId), { precio: val });
                              showToast("Precio actualizado ✅");
                            }}
                          />
                        </td>
                        <td style={{ padding:"13px 16px", whiteSpace:"nowrap" }}>
                          <span style={{ fontWeight:700, color:saldo(p)>0?"#c62828":"#2e7d32", fontSize:14 }}>{p.precio?`$${saldo(p).toLocaleString("es-AR")}`:"—"}</span>
                        </td>
                        <td style={{ padding:"13px 16px" }}>
                          <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
                            <button title="Reimprimir orden de trabajo"
                              onClick={() => imprimirOrden(p, empresa)}
                              style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"6px 9px", borderRadius:7, fontSize:12, fontWeight:700, cursor:"pointer" }}>
                              🖨️
                            </button>
                            <button style={{ background:"#25d366", color:"#fff", border:"none", padding:"6px 10px", borderRadius:7, fontSize:13, fontWeight:700, cursor:"pointer" }}
                              onClick={() => setMsgModal({ pedido: p })}>💬</button>
                            <button style={{ background:"#e65100", color:"#fff", border:"none", padding:"6px 10px", borderRadius:7, fontSize:12, fontWeight:600, cursor:"pointer", fontFamily:"'DM Sans',sans-serif" }}
                              onClick={() => handleEstadoChange(p.fireId || p.id, "Entregado")}>📦 Entregar</button>
                            <button style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"7px 10px", borderRadius:7, fontSize:13, fontWeight:600, cursor:"pointer" }}
                              onClick={() => handleDelete(p.fireId || p.id)}>🗑</button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── TAB: HISTORIAL ── */}
      {tabActiva === "historial" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16, flexWrap:"wrap", gap:10 }}>
            <p style={{ fontSize:14, color:"#a09080" }}>{entregados.length} pedido{entregados.length!==1?"s":""} entregado{entregados.length!==1?"s":""}</p>
          </div>

          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18 }}>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", fontSize:15 }}>🔍</span>
              <input placeholder="Buscar en historial..." value={busqH} onChange={e=>setBusqH(e.target.value)}
                style={{ ...inp(), paddingLeft:34, width:"100%" }}/>
            </div>
          </div>

          {entregadosFiltrados.length === 0 ? (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px 24px", textAlign:"center" }}>
              <div style={{ fontSize:40, marginBottom:14 }}>📦</div>
              <div style={{ fontWeight:700, fontSize:18, fontFamily:"'DM Sans',sans-serif", marginBottom:6 }}>
                {entregados.length === 0 ? "Sin pedidos entregados aún" : "Sin resultados"}
              </div>
            </div>
          ) : (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
                <thead>
                  <tr style={{ background:"#fffaf7" }}>
                    {["Pedido","Categoría","Cliente","Fecha Entrega","Total",""].map(h=>(
                      <th key={h} style={{ padding:"10px 16px", textAlign:"left", fontWeight:600, fontSize:11, color:"#8a7060", textTransform:"uppercase", letterSpacing:".6px", whiteSpace:"nowrap", borderBottom:"1px solid #f5e8e0" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {entregadosFiltrados.map(p => {
                    const cc = CATEGORIA_COLOR[p.categoria] || {bg:"#f5f5f5",text:"#424242"};
                    return (
                      <tr key={p.fireId||p.id} style={{ borderBottom:"1px solid #fef0e8" }}>
                        <td style={{ padding:"11px 16px" }}>
                          <div style={{ fontWeight:600, color:"#4a5568" }}>{p.nombre}</div>
                          {p.notas && <div style={{ fontSize:11, color:"#a09080", marginTop:2, maxWidth:180, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{p.notas}</div>}
                        </td>
                        <td style={{ padding:"11px 16px" }}>
                          <span style={{ background:cc.bg, color:cc.text, padding:"3px 9px", borderRadius:20, fontSize:11, fontWeight:600 }}>{CATEGORIA_ICON[p.categoria]} {p.categoria}</span>
                        </td>
                        <td style={{ padding:"11px 16px", whiteSpace:"nowrap" }}>
                          <ClienteLink p={p}/>
                        </td>
                        <td style={{ padding:"11px 16px", color:"#4a5568" }}>{fmtFecha(p.fechaEntrega)||"—"}</td>
                        <td style={{ padding:"11px 16px", fontWeight:700, color:"#1a2340" }}>{p.precio?`$${parseFloat(p.precio).toLocaleString("es-AR")}`:"—"}</td>
                        <td style={{ padding:"11px 16px" }}>
                          <div style={{ display:"flex", gap:6, alignItems:"center" }}>
                            <button title="Reimprimir orden de trabajo"
                              onClick={() => imprimirOrden(p, empresa)}
                              style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"5px 9px", borderRadius:7, fontSize:12, fontWeight:700, cursor:"pointer" }}>
                              🖨️ Orden
                            </button>
                            <button title="Ver detalle del pedido"
                              onClick={() => setPedidoDetalle(p)}
                              style={{ background:"#f0f3f9", border:"1.5px solid #c5cce0", color:"#3949ab", padding:"5px 9px", borderRadius:7, fontSize:12, fontWeight:700, cursor:"pointer" }}>
                              🔍 Ver
                            </button>
                            <span style={{ background:"#e8f5e9", color:"#1b5e20", padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:600 }}>✅ Entregado</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── Modal: Ver orden vieja ── */}
      {pedidoDetalle && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.55)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300, padding:16 }}
          onClick={()=>setPedidoDetalle(null)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 30px", width:"100%", maxWidth:560, boxShadow:"0 20px 60px rgba(0,0,0,.25)", maxHeight:"88vh", overflowY:"auto" }}
            onClick={e=>e.stopPropagation()}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20 }}>
              <div>
                <div style={{ fontWeight:800, fontSize:20, color:"#1a2340" }}>{pedidoDetalle.nombre}</div>
                <div style={{ fontSize:13, color:"#a09080", marginTop:3 }}>
                  {CATEGORIA_ICON[pedidoDetalle.categoria]} {pedidoDetalle.categoria}
                  <span style={{ marginLeft:10, background:"#e8f5e9", color:"#1b5e20", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:700 }}>✅ Entregado</span>
                </div>
              </div>
              <button onClick={()=>setPedidoDetalle(null)} style={{ background:"transparent", border:"none", fontSize:22, color:"#a09080", cursor:"pointer" }}>✕</button>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:18 }}>
              {[
                { label:"👤 Cliente",       val: pedidoDetalle.cliente||"—" },
                { label:"📞 Teléfono",      val: pedidoDetalle.telefono||"—" },
                { label:"📅 Fecha pedido",  val: pedidoDetalle.fechaPedido||"—" },
                { label:"🏁 Fecha entrega", val: pedidoDetalle.fechaEntrega||"—" },
                { label:"💰 Precio total",  val: pedidoDetalle.precio?`$${parseFloat(pedidoDetalle.precio).toLocaleString("es-AR")}`:"—" },
                { label:"💵 Seña",          val: pedidoDetalle.seña?`$${parseFloat(pedidoDetalle.seña).toLocaleString("es-AR")}`:"—" },
              ].map(item=>(
                <div key={item.label} style={{ background:"#fffaf7", borderRadius:8, padding:"10px 14px" }}>
                  <div style={{ fontSize:10, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:3 }}>{item.label}</div>
                  <div style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{item.val}</div>
                </div>
              ))}
            </div>
            {pedidoDetalle.notas && (
              <div style={{ background:"#fffaf7", borderRadius:8, padding:"12px 16px", marginBottom:18 }}>
                <div style={{ fontSize:10, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:6 }}>📝 Notas</div>
                <div style={{ fontSize:13, color:"#4a5568", lineHeight:1.6, whiteSpace:"pre-line" }}>{pedidoDetalle.notas}</div>
              </div>
            )}
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>imprimirOrden(pedidoDetalle, empresa)}
                style={{ flex:1, padding:"11px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
                🖨️ Reimprimir orden de trabajo
              </button>
              {pedidoDetalle.clienteId && (
                <button onClick={()=>{ irACliente(pedidoDetalle); setPedidoDetalle(null); }}
                  style={{ padding:"11px 16px", background:"#f0f3f9", color:"#3949ab", border:"1.5px solid #c5cce0", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
                  👤 Ver cliente
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


// ── Calculadora de Costos ────────────────────────────────────────────────

// Categorías fijas que la app reconoce en Materias Primas
const CAT_KEYS = {
  VINILO_IMP:   "vinilo_imprimible",
  TINTA:        "tinta_plotter",
  LONA_FRONT:   "lona_frontlight",
  LONA_BACK:    "lona_backlight",
  VINILO_TRANS: "vinilo_transparente",
  VINILO_CORTE: "vinilo_corte",
  CINTA:        "cinta_posicionadora",
  CORRUGADO:    "plastico_corrugado",
  BICAPA:       "plastico_bicapa",
  POLIFAN:      "polifan",
  PLA:          "filamento_pla",
};

// Costos fijos por defecto
const FIJOS_DEFAULT = {
  impresion:  500,   // $/m² máquina + energía
  colocacion: 8387,  // $/m²
  masillado:  3000,  // $/m²
  pintado:    2500,  // $/m²
  disenio:    5000,  // $ fijo
  operario:   381,   // $/min
};

// ── Hook: Materias primas con cálculo automático ─────────────────────────
function useMateriasPrimas() {
  const [materias, setMaterias] = useState([]);
  useEffect(() => {
    const unsub = onSnapshot(collection(db,"materiasPrimas"), snap =>
      setMaterias(snap.docs.map(d=>({...d.data(),fireId:d.id})))
    );
    return () => unsub();
  }, []);

  // Calcular $/m² o $/g según categoría
  const getPrecioM2 = (catKey) => {
    const m = materias.find(x => x.categoriaKey === catKey);
    if (!m) return null;
    const precio = parseFloat(m.precioCosto||0);
    const rinde  = parseFloat(m.rendimiento||0);
    if (rinde > 0) return { precio: precio / rinde, materia: m };
    return { precio, materia: m };
  };

  return { materias, getPrecioM2 };
}

// ── Hook: Costos fijos (Firebase) ────────────────────────────────────────
function useCostosFijos() {
  const [fijos, setFijos] = useState(FIJOS_DEFAULT);
  useEffect(() => {
    getDoc(doc(db,"config","costosFijos")).then(snap => {
      if (snap.exists()) setFijos({...FIJOS_DEFAULT,...snap.data()});
    }).catch(()=>{});
  }, []);
  const guardar = async (nuevos) => {
    await setDoc(doc(db,"config","costosFijos"), nuevos);
    setFijos(nuevos);
  };
  return { fijos, guardar };
}

// ── Componente: Precio desde materia prima ───────────────────────────────
function PrecioMP({ catKey, label, valor, setValor, getPrecioM2 }) {
  const mp = getPrecioM2(catKey);
  return (
    <div style={{ background:"#fff", borderRadius:10, padding:"12px 14px", border:"1.5px solid #f0d5c0" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8 }}>
        <span style={{ fontSize:13, fontWeight:600, color:"#1a2340" }}>{label}</span>
        {mp && (
          <button onClick={()=>setValor(Math.round(mp.precio))}
            style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100",
              padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:700, cursor:"pointer" }}>
            📌 ${Math.round(mp.precio).toLocaleString("es-AR")}/m² ({mp.materia.nombre})
          </button>
        )}
        {!mp && (
          <span style={{ fontSize:10, color:"#ffb74d", fontWeight:600 }}>
            ⚠️ Sin materia prima vinculada
          </span>
        )}
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:8 }}>
        <span style={{ fontSize:12, color:"#a09080" }}>$</span>
        <input type="number" value={valor||""} onChange={e=>setValor(parseFloat(e.target.value)||0)}
          placeholder="0"
          style={{ flex:1, padding:"9px 12px", borderRadius:8, border:"1.5px solid #f0d5c0",
            fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none" }}/>
        <span style={{ fontSize:11, color:"#a09080" }}>/m²</span>
      </div>
    </div>
  );
}

// ── Componente: Panel resultado ──────────────────────────────────────────
function ResultPanel({ items, ganancia, setGanancia, listo, onGuardar, titulo }) {
  const total  = items.reduce((s,i)=>s+(i.activo!==false?i.valor:0),0);
  const precio = Math.round(total * ganancia);
  const fmt    = n => Math.round(n).toLocaleString("es-AR");

  return (
    <div style={{ position:"sticky", top:20, display:"flex", flexDirection:"column", gap:12 }}>
      {/* Ganancia */}
      <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 16px" }}>
        <div style={{ fontSize:12, fontWeight:700, color:"#4a5568", marginBottom:10 }}>GANANCIA</div>
        <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
          {[1.5,2,2.5,3,3.5,4].map(g=>(
            <button key={g} onClick={()=>setGanancia(g)}
              style={{ padding:"6px 12px", borderRadius:20, fontSize:13, fontWeight:700,
                cursor:"pointer", border:"none",
                background:ganancia===g?"#e65100":"#fff8f5",
                color:ganancia===g?"#fff":"#e65100" }}>
              ×{g}
            </button>
          ))}
          <input type="number" step="0.1" min="1" value={ganancia}
            onChange={e=>setGanancia(parseFloat(e.target.value)||1)}
            style={{ width:52, padding:"5px 6px", borderRadius:8, border:"1.5px solid #f0d5c0",
              fontSize:12, outline:"none", textAlign:"center" }}/>
        </div>
      </div>

      {/* Resultado */}
      <div style={{ background:listo?"linear-gradient(135deg,#bf360c,#e65100)":"#f5f7fd",
        borderRadius:14, padding:"20px 18px", boxShadow:"0 4px 20px rgba(230,81,0,.15)" }}>
        {!listo ? (
          <div style={{ textAlign:"center", color:"#a09080", padding:"16px 0" }}>
            <div style={{ fontSize:30, marginBottom:6 }}>🧮</div>
            <div style={{ fontSize:13 }}>Completá las medidas</div>
          </div>
        ) : (
          <>
            <div style={{ fontSize:10, fontWeight:700, color:"rgba(255,255,255,.6)",
              textTransform:"uppercase", letterSpacing:".8px", marginBottom:12 }}>
              DESGLOSE DE COSTOS
            </div>
            {items.filter(i=>i.activo!==false&&i.valor>0).map((it,i)=>(
              <div key={i} style={{ display:"flex", justifyContent:"space-between",
                fontSize:12, marginBottom:6 }}>
                <span style={{ color:"rgba(255,255,255,.8)" }}>{it.label}</span>
                <span style={{ fontWeight:600, color:"#fff" }}>${fmt(it.valor)}</span>
              </div>
            ))}
            <div style={{ borderTop:"1px solid rgba(255,255,255,.25)", marginTop:10, paddingTop:10 }}>
              <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:4 }}>
                <span style={{ color:"rgba(255,255,255,.7)" }}>Costo total</span>
                <span style={{ fontWeight:600, color:"#fff" }}>${fmt(total)}</span>
              </div>
              <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:10 }}>
                <span style={{ color:"rgba(255,255,255,.7)" }}>Ganancia ×{ganancia}</span>
                <span style={{ fontWeight:600, color:"#fff" }}>${fmt(precio-total)}</span>
              </div>
              <div style={{ background:"rgba(255,255,255,.15)", borderRadius:10,
                padding:"12px", textAlign:"center" }}>
                <div style={{ fontSize:10, color:"rgba(255,255,255,.6)", fontWeight:700,
                  textTransform:"uppercase", letterSpacing:".7px", marginBottom:4 }}>
                  PRECIO DE VENTA
                </div>
                <div style={{ fontSize:32, fontWeight:800, color:"#fff" }}>
                  ${fmt(precio)}
                </div>
              </div>
              <button onClick={()=>onGuardar(titulo, total, precio)}
                style={{ width:"100%", marginTop:10, padding:"9px",
                  background:"rgba(255,255,255,.2)", color:"#fff",
                  border:"1.5px solid rgba(255,255,255,.3)", borderRadius:8,
                  fontSize:12, fontWeight:700, cursor:"pointer" }}>
                💾 Guardar en historial
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── Medidas con m² ───────────────────────────────────────────────────────
function Medidas({ alto, setAlto, ancho, setAncho }) {
  const m2 = (parseFloat(alto)||0) * (parseFloat(ancho)||0);
  return (
    <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
      <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:14 }}>📐 Medidas del trabajo</div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        {[["Alto (m)", alto, setAlto],["Ancho (m)", ancho, setAncho]].map(([lbl,val,setVal])=>(
          <div key={lbl}>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>{lbl}</label>
            <input type="number" step="0.01" value={val} onChange={e=>setVal(e.target.value)}
              placeholder="0.00"
              style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0",
                fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
          </div>
        ))}
      </div>
      {m2>0 && (
        <div style={{ marginTop:10, background:"#fff8f5", borderRadius:8, padding:"8px 14px",
          display:"flex", justifyContent:"space-between" }}>
          <span style={{ fontSize:13, color:"#a09080" }}>Superficie:</span>
          <span style={{ fontWeight:800, color:"#e65100", fontSize:15 }}>{m2.toFixed(3)} m²</span>
        </div>
      )}
    </div>
  );
}

// ── Check opción ─────────────────────────────────────────────────────────
function Opcion({ activo, toggle, label, detalle, costo }) {
  return (
    <div onClick={toggle}
      style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer",
        padding:"11px 14px", borderRadius:10,
        border:`2px solid ${activo?"#e65100":"#f0d5c0"}`,
        background:activo?"#fff8f5":"#fff", transition:"all .15s" }}>
      <div style={{ width:20, height:20, borderRadius:5, flexShrink:0, transition:"all .15s",
        border:`2px solid ${activo?"#e65100":"#f0d5c0"}`,
        background:activo?"#e65100":"#fff",
        display:"flex", alignItems:"center", justifyContent:"center" }}>
        {activo && <span style={{ color:"#fff", fontSize:11, fontWeight:800 }}>✓</span>}
      </div>
      <div style={{ flex:1 }}>
        <div style={{ fontSize:13, fontWeight:600, color:"#1a2340" }}>{label}</div>
        {detalle && <div style={{ fontSize:11, color:"#a09080", marginTop:1 }}>{detalle}</div>}
      </div>
      {activo && costo>0 && (
        <span style={{ fontSize:12, fontWeight:700, color:"#e65100" }}>
          ${Math.round(costo).toLocaleString("es-AR")}
        </span>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CALCULADORA PRINCIPAL
// ═══════════════════════════════════════════════════════════════════════════
function CalculadoraCostos() {
  const [tab, setTab]           = useState("bases");
  const [historial, setHistorial] = useState([]);
  const { materias, getPrecioM2 } = useMateriasPrimas();
  const { fijos, guardar }      = useCostosFijos();

  const addHistorial = (tipo, costo, precio) => {
    setHistorial(prev=>[{
      id:Date.now(), tipo,
      costo:Math.round(costo), precio:Math.round(precio),
      fecha:new Date().toLocaleDateString("es-AR")
    },...prev].slice(0,15));
  };

  const TABS = [
    {id:"bases",    label:"🪟 Bases"},
    {id:"rotulado", label:"🏷️ Rotulados"},
    {id:"lona",     label:"🚩 Lona"},
    {id:"polyfan",  label:"🟡 Polyfan"},
    {id:"3d",       label:"📦 3D"},
    {id:"config",   label:"⚙️ Costos fijos"},
  ];

  const props = { getPrecioM2, fijos, onGuardar:addHistorial };

  return (
    <div>
      {/* Tabs */}
      <div style={{ display:"flex", gap:6, marginBottom:20, flexWrap:"wrap" }}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)}
            style={{ padding:"9px 18px", borderRadius:20, fontSize:13, fontWeight:600,
              cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
              background:tab===t.id?(t.id==="config"?"#1a2340":"#e65100"):"#fff",
              color:tab===t.id?"#fff":"#4a5568",
              boxShadow:tab===t.id?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(0,0,0,.06)" }}>
            {t.label}
          </button>
        ))}
      </div>

      {tab==="bases"    && <CalcBases    {...props}/>}
      {tab==="rotulado" && <CalcRotulado {...props}/>}
      {tab==="lona"     && <CalcLona     {...props}/>}
      {tab==="polyfan"  && <CalcPolyfan  {...props}/>}
      {tab==="3d"       && <Calc3D       {...props}/>}
      {tab==="config"   && <CalcConfigFijos fijos={fijos} onGuardar={guardar} materias={materias} getPrecioM2={getPrecioM2}/>}

      {/* Historial */}
      {historial.length>0 && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)",
          padding:"16px 20px", marginTop:20 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
            <div style={{ fontWeight:700, fontSize:14, color:"#1a2340" }}>📋 Historial</div>
            <button onClick={()=>setHistorial([])}
              style={{ background:"transparent", border:"none", color:"#a09080", fontSize:12, cursor:"pointer" }}>
              Limpiar
            </button>
          </div>
          {historial.map(h=>(
            <div key={h.id} style={{ display:"flex", justifyContent:"space-between",
              alignItems:"center", padding:"8px 0", borderBottom:"1px solid #fef0e8" }}>
              <div>
                <span style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{h.tipo}</span>
                <span style={{ fontSize:11, color:"#a09080", marginLeft:8 }}>
                  costo ${h.costo.toLocaleString("es-AR")}
                </span>
              </div>
              <div style={{ display:"flex", gap:8, alignItems:"center" }}>
                <span style={{ fontWeight:800, fontSize:15, color:"#e65100" }}>
                  ${h.precio.toLocaleString("es-AR")}
                </span>
                <span style={{ fontSize:11, color:"#a09080" }}>{h.fecha}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CALC: BASES (placa plástica)
// ═══════════════════════════════════════════════════════════════════════════
function CalcBases({ getPrecioM2, fijos, onGuardar }) {
  const [alto, setAlto]       = useState("");
  const [ancho, setAncho]     = useState("");
  const [tipoPlas, setTipoPlas] = useState("corrugado");
  const [ganancia, setGanancia] = useState(2.5);
  const [llevaVinilo, setLlevaVinilo] = useState(true);
  const [llevaTrans, setLlevaTrans]   = useState(false);
  const [dobleFaz, setDobleFaz]       = useState(false);
  const [llevaColoc, setLlevaColoc]   = useState(false);

  // Costos desde materias primas — editables
  const mpCorr = getPrecioM2(CAT_KEYS.CORRUGADO);
  const mpBicapa = getPrecioM2(CAT_KEYS.BICAPA);
  const mpVinilo = getPrecioM2(CAT_KEYS.VINILO_IMP);
  const mpTrans  = getPrecioM2(CAT_KEYS.VINILO_TRANS);

  const [cPlas,   setCPlas]   = useState(0);
  const [cVinilo, setCVinilo] = useState(0);
  const [cTrans,  setCTrans]  = useState(0);
  const [cImp,    setCImp]    = useState(fijos.impresion||500);
  const [cColoc,  setCColoc]  = useState(fijos.colocacion||8387);

  // Autocargar desde MP cuando cambia la selección
  useEffect(()=>{
    if (tipoPlas==="corrugado" && mpCorr) setCPlas(Math.round(mpCorr.precio));
    if (tipoPlas==="bicapa"    && mpBicapa) setCPlas(Math.round(mpBicapa.precio));
  },[tipoPlas, mpCorr?.precio, mpBicapa?.precio]);
  useEffect(()=>{ if(mpVinilo) setCVinilo(Math.round(mpVinilo.precio)); },[mpVinilo?.precio]);
  useEffect(()=>{ if(mpTrans)  setCTrans(Math.round(mpTrans.precio));  },[mpTrans?.precio]);
  useEffect(()=>{ setCImp(fijos.impresion||500); },[fijos.impresion]);
  useEffect(()=>{ setCColoc(fijos.colocacion||8387); },[fijos.colocacion]);

  const h  = parseFloat(alto)||0;
  const w  = parseFloat(ancho)||0;
  const m2 = h*w;
  const listo = m2>0;

  const vCPlas   = cPlas   * m2;
  const vVinilo  = llevaVinilo ? (cVinilo+cImp) * m2 * (dobleFaz?2:1) : 0;
  const vTrans   = llevaTrans  ? cTrans * m2 : 0;
  const vColoc   = llevaColoc  ? cColoc * m2 : 0;

  const inp = {padding:"9px 12px",borderRadius:8,border:"1.5px solid #f0d5c0",fontSize:13,fontFamily:"'DM Sans',sans-serif",outline:"none",width:"100%",boxSizing:"border-box"};

  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:20, alignItems:"start" }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>

        <Medidas alto={alto} setAlto={setAlto} ancho={ancho} setAncho={setAncho}/>

        {/* Material base */}
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>🪟 Material base</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:12 }}>
            {[["corrugado","Corrugado",mpCorr],["bicapa","Bicapa / PAI / PVC",mpBicapa]].map(([id,lbl,mp])=>(
              <div key={id} onClick={()=>setTipoPlas(id)}
                style={{ padding:"10px 14px", borderRadius:10, cursor:"pointer",
                  border:`2px solid ${tipoPlas===id?"#e65100":"#f0d5c0"}`,
                  background:tipoPlas===id?"#fff8f5":"#fff" }}>
                <div style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{lbl}</div>
                <div style={{ fontSize:11, color:mp?"#e65100":"#ffb74d", marginTop:2 }}>
                  {mp?`📌 $${Math.round(mp.precio).toLocaleString("es-AR")}/m²`:"⚠️ Sin MP cargada"}
                </div>
              </div>
            ))}
          </div>
          <label style={{ fontSize:12, fontWeight:600, color:"#4a5568", display:"block", marginBottom:5 }}>
            Costo material ($/m²)
          </label>
          <input type="number" value={cPlas} onChange={e=>setCPlas(parseFloat(e.target.value)||0)} style={inp}/>
        </div>

        {/* Opciones */}
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>⚙️ Opciones</div>
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <Opcion activo={llevaVinilo} toggle={()=>setLlevaVinilo(v=>!v)}
              label="Vinilo impreso"
              detalle={`Material $${cVinilo}/m² + impresión $${cImp}/m²${dobleFaz?" × 2 caras":""}`}
              costo={vVinilo}/>
            {llevaVinilo && (
              <div style={{ marginLeft:32, display:"flex", flexDirection:"column", gap:8 }}>
                <Opcion activo={dobleFaz} toggle={()=>setDobleFaz(v=>!v)}
                  label="Doble faz" detalle="Vinilo en ambas caras" costo={0}/>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                  <div>
                    <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>
                      Vinilo $/m² {mpVinilo&&<span style={{color:"#e65100"}}>📌</span>}
                    </label>
                    <input type="number" value={cVinilo} onChange={e=>setCVinilo(parseFloat(e.target.value)||0)} style={inp}/>
                  </div>
                  <div>
                    <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>
                      Impresión $/m²
                    </label>
                    <input type="number" value={cImp} onChange={e=>setCImp(parseFloat(e.target.value)||0)} style={inp}/>
                  </div>
                </div>
              </div>
            )}
            <Opcion activo={llevaTrans} toggle={()=>setLlevaTrans(v=>!v)}
              label="Vinilo transparente (protector)"
              detalle={`$${cTrans}/m² ${mpTrans?"📌":""}`}
              costo={vTrans}/>
            {llevaTrans && (
              <div style={{ marginLeft:32 }}>
                <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Transparente $/m²</label>
                <input type="number" value={cTrans} onChange={e=>setCTrans(parseFloat(e.target.value)||0)} style={inp}/>
              </div>
            )}
            <Opcion activo={llevaColoc} toggle={()=>setLlevaColoc(v=>!v)}
              label="Colocación"
              detalle={`$${cColoc}/m² (mano de obra)`}
              costo={vColoc}/>
            {llevaColoc && (
              <div style={{ marginLeft:32 }}>
                <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Colocación $/m²</label>
                <input type="number" value={cColoc} onChange={e=>setCColoc(parseFloat(e.target.value)||0)} style={inp}/>
              </div>
            )}
          </div>
        </div>
      </div>
      <ResultPanel
        items={[
          {label:"🪟 Material base", valor:vCPlas},
          {label:"🖨️ Vinilo impreso", valor:vVinilo, activo:llevaVinilo},
          {label:"🔲 Transparente",  valor:vTrans,  activo:llevaTrans},
          {label:"🔧 Colocación",    valor:vColoc,  activo:llevaColoc},
        ]}
        ganancia={ganancia} setGanancia={setGanancia} listo={listo}
        onGuardar={onGuardar} titulo={`Bases ${tipoPlas} ${alto||"?"}×${ancho||"?"}m`}/>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CALC: ROTULADOS
// ═══════════════════════════════════════════════════════════════════════════
function CalcRotulado({ getPrecioM2, fijos, onGuardar }) {
  const [alto, setAlto]   = useState("");
  const [ancho, setAncho] = useState("");
  const [tipo, setTipo]   = useState("calado"); // calado | impreso
  const [ganancia, setGanancia] = useState(2.5);
  const [llevaCinta, setLlevaCinta] = useState(true);

  const mpCorte  = getPrecioM2(CAT_KEYS.VINILO_CORTE);
  const mpImp    = getPrecioM2(CAT_KEYS.VINILO_IMP);
  const mpCinta  = getPrecioM2(CAT_KEYS.CINTA);

  const [cVinilo, setCVinilo] = useState(0);
  const [cImp,    setCImp]    = useState(fijos.impresion||500);
  const [cCinta,  setCCinta]  = useState(0);

  useEffect(()=>{
    if(tipo==="calado"  && mpCorte) setCVinilo(Math.round(mpCorte.precio));
    if(tipo==="impreso" && mpImp)   setCVinilo(Math.round(mpImp.precio));
  },[tipo, mpCorte?.precio, mpImp?.precio]);
  useEffect(()=>{ if(mpCinta) setCCinta(Math.round(mpCinta.precio)); },[mpCinta?.precio]);
  useEffect(()=>{ setCImp(fijos.impresion||500); },[fijos.impresion]);

  const h  = parseFloat(alto)||0;
  const w  = parseFloat(ancho)||0;
  const m2 = h*w;
  const listo = m2>0;

  const vVinilo = cVinilo * m2;
  const vImp    = tipo==="impreso" ? cImp * m2 : 0;
  const vCinta  = llevaCinta ? cCinta * m2 : 0;

  const inp = {padding:"9px 12px",borderRadius:8,border:"1.5px solid #f0d5c0",fontSize:13,fontFamily:"'DM Sans',sans-serif",outline:"none",width:"100%",boxSizing:"border-box"};

  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:20, alignItems:"start" }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <Medidas alto={alto} setAlto={setAlto} ancho={ancho} setAncho={setAncho}/>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>🏷️ Tipo de vinilo</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:12 }}>
            {[["calado","Vinilo calado",mpCorte],["impreso","Vinilo impreso",mpImp]].map(([id,lbl,mp])=>(
              <div key={id} onClick={()=>setTipo(id)}
                style={{ padding:"10px 14px", borderRadius:10, cursor:"pointer", textAlign:"center",
                  border:`2px solid ${tipo===id?"#e65100":"#f0d5c0"}`,
                  background:tipo===id?"#fff8f5":"#fff" }}>
                <div style={{ fontWeight:600, fontSize:13 }}>{lbl}</div>
                <div style={{ fontSize:11, color:mp?"#e65100":"#ffb74d", marginTop:2 }}>
                  {mp?`📌 $${Math.round(mp.precio).toLocaleString("es-AR")}/m²`:"⚠️ Sin MP"}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display:"grid", gridTemplateColumns:tipo==="impreso"?"1fr 1fr":"1fr", gap:8 }}>
            <div>
              <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>
                Vinilo $/m² {(tipo==="calado"?mpCorte:mpImp)&&<span style={{color:"#e65100"}}>📌</span>}
              </label>
              <input type="number" value={cVinilo} onChange={e=>setCVinilo(parseFloat(e.target.value)||0)} style={inp}/>
            </div>
            {tipo==="impreso" && (
              <div>
                <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Impresión $/m²</label>
                <input type="number" value={cImp} onChange={e=>setCImp(parseFloat(e.target.value)||0)} style={inp}/>
              </div>
            )}
          </div>
        </div>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <Opcion activo={llevaCinta} toggle={()=>setLlevaCinta(v=>!v)}
            label="Cinta posicionadora"
            detalle={`$${cCinta}/m² ${mpCinta?"📌":"⚠️ Sin MP"}`}
            costo={vCinta}/>
          {llevaCinta && (
            <div style={{ marginTop:8, marginLeft:32 }}>
              <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Cinta $/m²</label>
              <input type="number" value={cCinta} onChange={e=>setCCinta(parseFloat(e.target.value)||0)} style={inp}/>
            </div>
          )}
        </div>
      </div>
      <ResultPanel
        items={[
          {label:"🏷️ Vinilo", valor:vVinilo},
          {label:"🖨️ Impresión", valor:vImp, activo:tipo==="impreso"},
          {label:"📏 Cinta", valor:vCinta, activo:llevaCinta},
        ]}
        ganancia={ganancia} setGanancia={setGanancia} listo={listo}
        onGuardar={onGuardar} titulo={`Rotulado ${tipo} ${alto||"?"}×${ancho||"?"}m`}/>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CALC: LONA
// ═══════════════════════════════════════════════════════════════════════════
function CalcLona({ getPrecioM2, fijos, onGuardar }) {
  const [alto, setAlto]   = useState("");
  const [ancho, setAncho] = useState("");
  const [tipoLona, setTipoLona] = useState("frontlight");
  const [ganancia, setGanancia] = useState(2.5);
  const [llevaEst,   setLlevaEst]   = useState(false);
  const [llevaOjales, setLlevaOjales] = useState(true);
  const [llevaColoc, setLlevaColoc] = useState(false);
  const [doble, setDoble] = useState(false);

  const mpFront = getPrecioM2(CAT_KEYS.LONA_FRONT);
  const mpBack  = getPrecioM2(CAT_KEYS.LONA_BACK);

  const [cLona,    setCLona]    = useState(0);
  const [cImp,     setCImp]     = useState(fijos.impresion||500);
  const [cEst,     setCEst]     = useState(39000);
  const [cOjal,    setCOjal]    = useState(200);
  const [cColoc,   setCColoc]   = useState(fijos.colocacion||8387);

  useEffect(()=>{
    if(tipoLona==="frontlight" && mpFront) setCLona(Math.round(mpFront.precio));
    if(tipoLona==="backlight"  && mpBack)  setCLona(Math.round(mpBack.precio));
  },[tipoLona, mpFront?.precio, mpBack?.precio]);
  useEffect(()=>{ setCImp(fijos.impresion||500); },[fijos.impresion]);
  useEffect(()=>{ setCColoc(fijos.colocacion||8387); },[fijos.colocacion]);

  const h   = parseFloat(alto)||0;
  const w   = parseFloat(ancho)||0;
  const m2  = h * w * (doble?2:1);
  const ojales = h>0&&w>0 ? Math.ceil((h+w)*2/0.5) : 0;
  const listo = m2>0;

  const vLona   = (cLona+cImp) * m2;
  const vEst    = llevaEst    ? cEst : 0;
  const vOjales = llevaOjales ? ojales * cOjal : 0;
  const vColoc  = llevaColoc  ? cColoc * m2 : 0;

  const inp = {padding:"9px 12px",borderRadius:8,border:"1.5px solid #f0d5c0",fontSize:13,fontFamily:"'DM Sans',sans-serif",outline:"none",width:"100%",boxSizing:"border-box"};

  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:20, alignItems:"start" }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <Medidas alto={alto} setAlto={setAlto} ancho={ancho} setAncho={setAncho}/>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>🚩 Tipo de lona</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:12 }}>
            {[["frontlight","Frontlight",mpFront],["backlight","Backlight",mpBack]].map(([id,lbl,mp])=>(
              <div key={id} onClick={()=>setTipoLona(id)}
                style={{ padding:"10px 14px", borderRadius:10, cursor:"pointer", textAlign:"center",
                  border:`2px solid ${tipoLona===id?"#e65100":"#f0d5c0"}`,
                  background:tipoLona===id?"#fff8f5":"#fff" }}>
                <div style={{ fontWeight:600, fontSize:13 }}>{lbl}</div>
                <div style={{ fontSize:11, color:mp?"#e65100":"#ffb74d", marginTop:2 }}>
                  {mp?`📌 $${Math.round(mp.precio).toLocaleString("es-AR")}/m²`:"⚠️ Sin MP"}
                </div>
              </div>
            ))}
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
            <div>
              <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Lona $/m²</label>
              <input type="number" value={cLona} onChange={e=>setCLona(parseFloat(e.target.value)||0)} style={inp}/>
            </div>
            <div>
              <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Impresión $/m²</label>
              <input type="number" value={cImp} onChange={e=>setCImp(parseFloat(e.target.value)||0)} style={inp}/>
            </div>
          </div>
        </div>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>⚙️ Opciones</div>
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <Opcion activo={doble} toggle={()=>setDoble(v=>!v)} label="Doble (dos lonas)" detalle="Se duplica el m²" costo={0}/>
            <Opcion activo={llevaEst} toggle={()=>setLlevaEst(v=>!v)}
              label="Estructura / Portabanner" detalle={`$${cEst.toLocaleString("es-AR")} por unidad`} costo={vEst}/>
            {llevaEst && <div style={{marginLeft:32}}><label style={{fontSize:11,fontWeight:600,color:"#4a5568",display:"block",marginBottom:4}}>Costo estructura $</label><input type="number" value={cEst} onChange={e=>setCEst(parseFloat(e.target.value)||0)} style={inp}/></div>}
            <Opcion activo={llevaOjales} toggle={()=>setLlevaOjales(v=>!v)}
              label="Ojales"
              detalle={listo?`${ojales} ojales estimados × $${cOjal}`:"—"}
              costo={vOjales}/>
            {llevaOjales && <div style={{marginLeft:32}}><label style={{fontSize:11,fontWeight:600,color:"#4a5568",display:"block",marginBottom:4}}>$ por ojal</label><input type="number" value={cOjal} onChange={e=>setCOjal(parseFloat(e.target.value)||0)} style={inp}/></div>}
            <Opcion activo={llevaColoc} toggle={()=>setLlevaColoc(v=>!v)}
              label="Colocación" detalle={`$${cColoc}/m²`} costo={vColoc}/>
            {llevaColoc && <div style={{marginLeft:32}}><label style={{fontSize:11,fontWeight:600,color:"#4a5568",display:"block",marginBottom:4}}>Colocación $/m²</label><input type="number" value={cColoc} onChange={e=>setCColoc(parseFloat(e.target.value)||0)} style={inp}/></div>}
          </div>
        </div>
      </div>
      <ResultPanel
        items={[
          {label:"🚩 Lona + impresión", valor:vLona},
          {label:"🏗️ Estructura", valor:vEst, activo:llevaEst},
          {label:"⭕ Ojales", valor:vOjales, activo:llevaOjales},
          {label:"🔧 Colocación", valor:vColoc, activo:llevaColoc},
        ]}
        ganancia={ganancia} setGanancia={setGanancia} listo={listo}
        onGuardar={onGuardar} titulo={`Lona ${tipoLona} ${alto||"?"}×${ancho||"?"}m`}/>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CALC: POLYFAN
// ═══════════════════════════════════════════════════════════════════════════
function CalcPolyfan({ getPrecioM2, fijos, onGuardar }) {
  const [alto, setAlto]   = useState("");
  const [ancho, setAncho] = useState("");
  const [ganancia, setGanancia] = useState(2.5);
  const [llevaMas, setLlevaMas] = useState(false);
  const [llevaPint, setLlevaPint] = useState(false);

  const mpPoli = getPrecioM2(CAT_KEYS.POLIFAN);
  const [cPoli, setCPoli]   = useState(0);
  const [cMas,  setCMas]    = useState(fijos.masillado||3000);
  const [cPint, setCPint]   = useState(fijos.pintado||2500);

  useEffect(()=>{ if(mpPoli) setCPoli(Math.round(mpPoli.precio)); },[mpPoli?.precio]);
  useEffect(()=>{ setCMas(fijos.masillado||3000); },[fijos.masillado]);
  useEffect(()=>{ setCPint(fijos.pintado||2500);  },[fijos.pintado]);

  const h  = parseFloat(alto)||0;
  const w  = parseFloat(ancho)||0;
  const m2 = h*w;
  const listo = m2>0;

  const vPoli = cPoli * m2;
  const vMas  = llevaMas  ? cMas  * m2 : 0;
  const vPint = llevaPint ? cPint * m2 : 0;

  const inp = {padding:"9px 12px",borderRadius:8,border:"1.5px solid #f0d5c0",fontSize:13,fontFamily:"'DM Sans',sans-serif",outline:"none",width:"100%",boxSizing:"border-box"};

  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:20, alignItems:"start" }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <Medidas alto={alto} setAlto={setAlto} ancho={ancho} setAncho={setAncho}/>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>
            🟡 Placa Polyfan/Foam
            {mpPoli && <span style={{fontSize:11,color:"#e65100",fontWeight:700,marginLeft:8}}>📌 {mpPoli.materia.nombre}</span>}
            {!mpPoli && <span style={{fontSize:11,color:"#ffb74d",marginLeft:8}}>⚠️ Sin MP cargada</span>}
          </div>
          <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:5 }}>Costo Polyfan $/m²</label>
          <input type="number" value={cPoli} onChange={e=>setCPoli(parseFloat(e.target.value)||0)} style={inp}/>
        </div>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>🖌️ Terminaciones</div>
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <Opcion activo={llevaMas} toggle={()=>setLlevaMas(v=>!v)} label="Masillado" detalle={`$${cMas}/m²`} costo={vMas}/>
            {llevaMas && <div style={{marginLeft:32}}><label style={{fontSize:11,fontWeight:600,color:"#4a5568",display:"block",marginBottom:4}}>Masillado $/m²</label><input type="number" value={cMas} onChange={e=>setCMas(parseFloat(e.target.value)||0)} style={inp}/></div>}
            <Opcion activo={llevaPint} toggle={()=>setLlevaPint(v=>!v)} label="Pintado" detalle={`$${cPint}/m²`} costo={vPint}/>
            {llevaPint && <div style={{marginLeft:32}}><label style={{fontSize:11,fontWeight:600,color:"#4a5568",display:"block",marginBottom:4}}>Pintado $/m²</label><input type="number" value={cPint} onChange={e=>setCPint(parseFloat(e.target.value)||0)} style={inp}/></div>}
          </div>
        </div>
      </div>
      <ResultPanel
        items={[
          {label:"🟡 Polyfan", valor:vPoli},
          {label:"🖌️ Masillado", valor:vMas, activo:llevaMas},
          {label:"🎨 Pintado", valor:vPint, activo:llevaPint},
        ]}
        ganancia={ganancia} setGanancia={setGanancia} listo={listo}
        onGuardar={onGuardar} titulo={`Polyfan ${alto||"?"}×${ancho||"?"}m`}/>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CALC: 3D
// ═══════════════════════════════════════════════════════════════════════════
function Calc3D({ getPrecioM2, fijos, onGuardar }) {
  const [gramos, setGramos] = useState("");
  const [horas,  setHoras]  = useState("");
  const [ganancia, setGanancia] = useState(3);
  const [llevaDis, setLlevaDis] = useState(false);

  const mpPLA = getPrecioM2(CAT_KEYS.PLA);
  const [cPLAg,   setCPLAg]   = useState(18);
  const [cKWh,    setCKWh]    = useState(120);
  const [cW,      setCW]      = useState(200);
  const [cDis,    setCDis]    = useState(fijos.disenio||5000);

  useEffect(()=>{
    if(mpPLA) {
      // PLA viene en precio de rollo 1kg ÷ 1000 = $/g
      const unidad = (mpPLA.materia.unidad||"").toLowerCase();
      const precio = parseFloat(mpPLA.materia.precioCosto||0);
      const rinde  = parseFloat(mpPLA.materia.rendimiento||0);
      if (rinde>0) setCPLAg(precio/rinde);
      else if (unidad==="kg") setCPLAg(precio/1000);
      else setCPLAg(precio);
    }
  },[mpPLA?.precio]);
  useEffect(()=>{ setCDis(fijos.disenio||5000); },[fijos.disenio]);

  const g  = parseFloat(gramos)||0;
  const h  = parseFloat(horas)||0;
  const listo = g>0||h>0;

  const vPLA = cPLAg * g;
  const vEne = (cW/1000) * h * cKWh;
  const vDis = llevaDis ? cDis : 0;

  const inp = {padding:"9px 12px",borderRadius:8,border:"1.5px solid #f0d5c0",fontSize:13,fontFamily:"'DM Sans',sans-serif",outline:"none",width:"100%",boxSizing:"border-box"};

  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 300px", gap:20, alignItems:"start" }}>
      <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>
            🧵 Filamento PLA
            {mpPLA && <span style={{fontSize:11,color:"#e65100",fontWeight:700,marginLeft:8}}>📌 {mpPLA.materia.nombre}</span>}
            {!mpPLA && <span style={{fontSize:11,color:"#ffb74d",marginLeft:8}}>⚠️ Sin MP cargada</span>}
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
            <div>
              <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Peso estimado (gramos)</label>
              <input type="number" value={gramos} onChange={e=>setGramos(e.target.value)} placeholder="50" style={inp}/>
            </div>
            <div>
              <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>Costo PLA ($/gramo)</label>
              <input type="number" step="0.1" value={cPLAg} onChange={e=>setCPLAg(parseFloat(e.target.value)||0)} style={inp}/>
            </div>
          </div>
          {g>0 && <div style={{marginTop:10,background:"#fff8f5",borderRadius:8,padding:"7px 12px",display:"flex",justifyContent:"space-between",fontSize:12}}>
            <span style={{color:"#a09080"}}>{g}g × ${cPLAg}/g</span>
            <span style={{fontWeight:700,color:"#e65100"}}>${Math.round(vPLA).toLocaleString("es-AR")}</span>
          </div>}
        </div>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>⚡ Energía</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
            {[["Tiempo (hs)", horas, setHoras, "3"],["Tarifa ($/kWh)", cKWh, setCKWh, "120"],["Consumo (W)", cW, setCW, "200"]].map(([lbl,val,setVal,ph])=>(
              <div key={lbl}>
                <label style={{ fontSize:11, fontWeight:600, color:"#4a5568", display:"block", marginBottom:4 }}>{lbl}</label>
                <input type="number" value={val} onChange={e=>setVal(parseFloat(e.target.value)||0)} placeholder={ph} style={inp}/>
              </div>
            ))}
          </div>
          {h>0 && <div style={{marginTop:10,background:"#fff8f5",borderRadius:8,padding:"7px 12px",display:"flex",justifyContent:"space-between",fontSize:12}}>
            <span style={{color:"#a09080"}}>{h}h × {cW}W = {((cW/1000)*h).toFixed(2)} kWh</span>
            <span style={{fontWeight:700,color:"#e65100"}}>${Math.round(vEne).toLocaleString("es-AR")}</span>
          </div>}
        </div>
        <div style={{ background:"#fff", borderRadius:12, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
          <Opcion activo={llevaDis} toggle={()=>setLlevaDis(v=>!v)} label="Diseño / prep. archivo" detalle={`$${cDis} fijo`} costo={vDis}/>
          {llevaDis && <div style={{marginTop:8,marginLeft:32}}><label style={{fontSize:11,fontWeight:600,color:"#4a5568",display:"block",marginBottom:4}}>Costo diseño $</label><input type="number" value={cDis} onChange={e=>setCDis(parseFloat(e.target.value)||0)} style={inp}/></div>}
        </div>
      </div>
      <ResultPanel
        items={[
          {label:"🧵 Filamento", valor:vPLA},
          {label:"⚡ Energía",   valor:vEne},
          {label:"🎨 Diseño",    valor:vDis, activo:llevaDis},
        ]}
        ganancia={ganancia} setGanancia={setGanancia} listo={listo}
        onGuardar={onGuardar} titulo={`3D ${gramos||"?"}g ${horas||"?"}h`}/>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CALC: CONFIG COSTOS FIJOS
// ═══════════════════════════════════════════════════════════════════════════
function CalcConfigFijos({ fijos, onGuardar, materias, getPrecioM2 }) {
  const [form, setForm]   = useState({...fijos});
  const [saving, setSaving] = useState(false);
  const [saved,  setSaved]  = useState(false);

  const set = (k,v) => setForm(f=>({...f,[k]:parseFloat(v)||0}));

  const handleSave = async () => {
    setSaving(true);
    await onGuardar(form);
    setSaving(false); setSaved(true);
    setTimeout(()=>setSaved(false),2500);
  };

  const inp = {padding:"9px 12px",borderRadius:8,border:"1.5px solid #f0d5c0",fontSize:13,fontFamily:"'DM Sans',sans-serif",outline:"none",width:"100%",boxSizing:"border-box"};

  const CAMPOS = [
    {k:"impresion",  label:"🖨️ Costo impresión (máquina + energía)", desc:"$/m² — amortización del plotter, energía eléctrica, tiempo operario", sufijo:"$/m²"},
    {k:"colocacion", label:"🔧 Colocación de vinilo",                 desc:"$/m² — mano de obra para colocar vinilo o lona",                     sufijo:"$/m²"},
    {k:"masillado",  label:"🖌️ Masillado",                           desc:"$/m² — mano de obra de masillado en polyfan",                        sufijo:"$/m²"},
    {k:"pintado",    label:"🎨 Pintado",                              desc:"$/m² — mano de obra de pintado en polyfan",                          sufijo:"$/m²"},
    {k:"disenio",    label:"✏️ Diseño / archivo",                    desc:"$ fijo — preparación de archivo o diseño",                           sufijo:"$ fijo"},
    {k:"operario",   label:"👷 Tiempo operario",                     desc:"$/minuto — costo del tiempo de trabajo",                             sufijo:"$/min"},
  ];

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <div>
          <h3 style={{ fontWeight:700, fontSize:18, color:"#1a2340", marginBottom:4 }}>⚙️ Costos fijos de producción</h3>
          <p style={{ fontSize:13, color:"#a09080", maxWidth:480 }}>
            Estos son los costos que no vienen de materias primas — mano de obra, máquinas, energía.
            Se usan como valores por defecto en todas las calculadoras. Podés sobreescribirlos en cada cálculo.
          </p>
        </div>
        <button onClick={handleSave} disabled={saving}
          style={{ padding:"11px 24px", background:saved?"#2e7d32":"#1a2340", color:"#fff",
            border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
          {saving?"Guardando...":saved?"✅ Guardado":"💾 Guardar"}
        </button>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))", gap:14 }}>
        {CAMPOS.map(c=>(
          <div key={c.k} style={{ background:"#fff", borderRadius:12, padding:"16px 18px", boxShadow:"0 2px 14px rgba(230,81,0,.07)" }}>
            <div style={{ fontWeight:700, fontSize:13, color:"#1a2340", marginBottom:3 }}>{c.label}</div>
            <div style={{ fontSize:11, color:"#a09080", marginBottom:10 }}>{c.desc}</div>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ fontSize:12, color:"#a09080" }}>$</span>
              <input type="number" value={form[c.k]||0} onChange={e=>set(c.k,e.target.value)} style={inp}/>
              <span style={{ fontSize:11, color:"#a09080", whiteSpace:"nowrap" }}>{c.sufijo}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop:24, background:"#f0f3f9", borderRadius:12, padding:"16px 20px" }}>
        <div style={{ fontWeight:700, fontSize:13, color:"#1a2340", marginBottom:8 }}>
          📌 Materias primas vinculadas automáticamente
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(220px,1fr))", gap:8 }}>
          {Object.entries(CAT_KEYS).map(([key,catKey])=>{
            const mp = getPrecioM2(catKey);
            return (
              <div key={key} style={{ background:"#fff", borderRadius:8, padding:"10px 12px", border:`1.5px solid ${mp?"#e65100":"#f0d5c0"}` }}>
                <div style={{ fontSize:11, fontWeight:700, color:"#4a5568", textTransform:"uppercase", letterSpacing:".5px", marginBottom:3 }}>{catKey.replace(/_/g," ")}</div>
                {mp ? (
                  <div style={{ fontSize:12, color:"#e65100", fontWeight:600 }}>
                    ✅ {mp.materia.nombre} — ${Math.round(mp.precio).toLocaleString("es-AR")}/u
                  </div>
                ) : (
                  <div style={{ fontSize:12, color:"#a09080" }}>⚠️ Sin materia prima cargada</div>
                )}
              </div>
            );
          })}
        </div>
        <div style={{ marginTop:10, fontSize:12, color:"#a09080" }}>
          Para vincular: en Materias Primas, al cargar un item elegí la categoría correspondiente del desplegable.
        </div>
      </div>
    </div>
  );
}


// ── Componente: Calendario ───────────────────────────────────────────────
const LOCALES = {
  grafica: {
    label: "🖨️ Gráfica",
    coleccion: "pedidosOnlineGrafica",
    cats: [
      { id:"Vinilo Impreso",  label:"VINILO IMPRESO",  color:"#1565c0", bg:"#e3f2fd" },
      { id:"Vinilo Calado",   label:"VINILO CALADO",   color:"#1b5e20", bg:"#e8f5e9" },
      { id:"Lona",            label:"LONA",            color:"#4a148c", bg:"#f3e5f5" },
      { id:"Impresiones",     label:"IMPRESIONES",     color:"#0d47a1", bg:"#e8eaf6" },
      { id:"DTF",             label:"DTF",             color:"#bf360c", bg:"#fbe9e7" },
      { id:"Sublimado",       label:"SUBLIMADO",       color:"#e65100", bg:"#fff3e0" },
      { id:"Estampado",       label:"ESTAMPADO",       color:"#4e342e", bg:"#efebe9" },
      { id:"Talonarios",      label:"TALONARIOS",      color:"#558b2f", bg:"#f1f8e9" },
      { id:"3D",              label:"3D",              color:"#6a1b9a", bg:"#f3e5f5" },
      { id:"Diseño",          label:"DISEÑO",          color:"#00695c", bg:"#e0f2f1" },
      { id:"Otros",           label:"OTROS",           color:"#37474f", bg:"#eceff1" },
    ],
  },
};

// Mapa categoría presencial → id de cat en la grilla de gráfica
const CAT_PRESENCIAL_MAP = {
  "Vinilo Impreso": "Vinilo Impreso",
  "Vinilo Calado":  "Vinilo Calado",
  "Lona":           "Lona",
  "Impresiones":    "Impresiones",
  "DTF":            "DTF",
  "Sublimado":      "Sublimado",
  "Estampado":      "Estampado",
  "Talonarios":     "Talonarios",
  "3D":             "3D",
  "Diseño":         "Diseño",
  "Otros":          "Otros",
};

const DIAS_SEMANA = ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];

function getLunes(fecha) {
  const d = new Date(fecha);
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0,0,0,0);
  return d;
}
function semanaKey(lunes) { return lunes.toISOString().split("T")[0]; }

function PedidosOnlineView({ showToast, setView: setViewApp, setSelectedPedido, clientes }) {
  const local = "grafica"; // único calendario (Librería eliminado)
  const [semanaInicio, setSemanaInicio] = useState(()=>getLunes(new Date()));
  const [grilla, setGrilla]             = useState({});
  const [loading, setLoading]           = useState(true);
  const [docId, setDocId]               = useState(null);
  const [pedidosDB, setPedidosDB]       = useState([]);

  // Modal nuevo pedido
  const [modalNuevo, setModalNuevo]       = useState(null);
  const [mTel,       setMTel]             = useState("");
  const [mNombre,    setMNombre]          = useState("");
  const [mDetalleItems, setMDetalleItems] = useState([""]);
  const [mEntrega,   setMEntrega]         = useState("");
  const [mPrecio,    setMPrecio]          = useState("");
  const [mSeña,      setMSeña]            = useState("");
  const [mClienteId, setMClienteId]       = useState(null);
  const [mClienteNombre, setMClienteNombre] = useState("");
  const [mClienteBusq, setMClienteBusq]   = useState("");
  const [mShowSugg,  setMShowSugg]        = useState(false);
  const [savingM,    setSavingM]          = useState(false);

  const cfg = {
    ...LOCALES[local],
    cats: CATEGORIAS.map(n => ({ id:n, label:n.toUpperCase(), color:CATEGORIA_COLOR[n].text, bg:CATEGORIA_COLOR[n].bg })),
  };
  const key = semanaKey(semanaInicio);

  const dias = DIAS_SEMANA.map((nombre, i) => {
    const d = new Date(semanaInicio);
    d.setDate(d.getDate() + i);
    return { nombre, fecha: d.toISOString().split("T")[0], d };
  });

  // Cargar pedidos presenciales en tiempo real
  useEffect(() => {
    const unsub = onSnapshot(collection(db,"pedidos"), snap =>
      setPedidosDB(snap.docs.map(d=>({...d.data(),fireId:d.id})))
    );
    return ()=>unsub();
  }, []);

  useEffect(() => {
    setLoading(true);
    getDocs(collection(db, cfg.coleccion)).then(snap => {
      const found = snap.docs.find(d => d.data().semana === key);
      if (found) { setGrilla(found.data().grilla||{}); setDocId(found.id); }
      else { setGrilla({}); setDocId(null); }
      setLoading(false);
    });
  }, [key, local]);

  const guardar = async (g) => {
    if (docId) {
      await updateDoc(doc(db, cfg.coleccion, docId), { grilla:g });
    } else {
      const ref = await addDoc(collection(db, cfg.coleccion), { semana:key, grilla:g });
      setDocId(ref.id);
    }
  };

  // Pedidos presenciales del día para una categoría (solo Gráfica)
  const pedidosDelDia = (fecha, catId) => {
    if (local !== "grafica") return [];
    return pedidosDB.filter(p =>
      p.fechaEntrega === fecha &&
      p.estado !== "Entregado" &&
      p.categoria === catId
    );
  };

  const updateSlot = (fecha, catId, idx, campo, valor) => {
    const g = JSON.parse(JSON.stringify(grilla));
    if (!g[fecha]) g[fecha] = {};
    if (!g[fecha][catId]) g[fecha][catId] = [];
    if (!g[fecha][catId][idx]) g[fecha][catId][idx] = {tel:"",desc:""};
    g[fecha][catId][idx][campo] = valor;
    setGrilla(g);
    guardar(g);
  };

  const limpiarDia = async (fecha) => {
    if (!window.confirm("¿Limpiar los slots manuales de este día?")) return;
    const g = JSON.parse(JSON.stringify(grilla));
    delete g[fecha];
    setGrilla(g);
    await guardar(g);
    showToast("Día limpiado");
  };

  const irSemana = (delta) => {
    const n = new Date(semanaInicio);
    n.setDate(n.getDate() + delta*7);
    setSemanaInicio(getLunes(n));
  };

  // Determinar si una categoría tiene contenido en la semana visible
  const catTieneContenido = (catId) => {
    if (dias.some(d => pedidosDelDia(d.fecha, catId).length > 0)) return true;
    return dias.some(d => (grilla[d.fecha]?.[catId]||[]).some(s=>s?.tel||s?.desc));
  };

  // Estado de expansión manual por categoría (null = auto)
  const [catsExpandidas, setCatsExpandidas] = useState({});
  const toggleCat = (catId) => setCatsExpandidas(prev => ({
    ...prev,
    [catId]: !isCatExpandida(catId)
  }));
  const isCatExpandida = (catId) => {
    if (catsExpandidas[catId] !== undefined) return catsExpandidas[catId];
    return catTieneContenido(catId); // auto: expandida si tiene contenido
  };

  const esHoy = f => f === new Date().toISOString().split("T")[0];
  const esSemanaActual = semanaKey(getLunes(new Date())) === key;

  const countDia = f => {
    const manuales = Object.values(grilla[f]||{}).flat().filter(s=>s?.tel||s?.desc).length;
    const presenciales = local==="grafica"
      ? pedidosDB.filter(p=>p.fechaEntrega===f&&p.estado!=="Entregado").length
      : 0;
    return manuales + presenciales;
  };

  const abrirModalNuevo = (fecha, catId) => {
    setModalNuevo({ fecha, catId });
    setMTel(""); setMNombre(""); setMDetalleItems([""]);
    setMEntrega(fecha); setMPrecio(""); setMSeña("");
    setMClienteId(null); setMClienteNombre(""); setMClienteBusq(""); setMShowSugg(false);
  };

  const guardarPedidoDesdeCalendario = async () => {
    if (!mNombre.trim()) { showToast("Ingresá el nombre del pedido","error"); return; }
    setSavingM(true);
    const hoy = new Date().toISOString().split("T")[0];
    const nuevoPedido = {
      nombre:       mNombre.trim(),
      telefono:     mTel.trim(),
      notas:        mDetalleItems.filter(x=>x.trim()).join("\n"),
      categoria:    modalNuevo.catId,
      estado:       "Pendiente",
      fechaPedido:  hoy,
      fechaEntrega: mEntrega,
      cliente:      mClienteNombre.trim(),
      clienteId:    mClienteId || null,
      precio:       mPrecio,
      seña:         mSeña,
      tomadoPor:    "",
      origenCalendario: true,
    };
    const nroOT = await getNextNroOT();
    const docData = { ...nuevoPedido };
    if (nroOT) docData.nroOT = nroOT;
    await addDoc(collection(db,"pedidos"), docData);
    showToast("Pedido creado ✅");
    setSavingM(false);
    setModalNuevo(null);
  };

  const eliminarSlot = (fecha, catId, idx) => {
    const g = JSON.parse(JSON.stringify(grilla));
    if (!g[fecha]?.[catId]) return;
    g[fecha][catId].splice(idx, 1);
    setGrilla(g);
    guardar(g);
  };

  const inp = { width:"100%", padding:"4px 7px", borderRadius:5, border:"1px solid #ddd",
    fontSize:11, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box", background:"#fff" };

  return (
    <div>
      {/* Nav semanas */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18, flexWrap:"wrap", gap:10 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={()=>irSemana(-1)} style={{ background:"#fff", border:"1.5px solid #f0d5c0", color:"#e65100", padding:"8px 14px", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>← Ant.</button>
          <div style={{ textAlign:"center" }}>
            <div style={{ fontWeight:700, fontSize:14, color:"#1a2340" }}>
              {dias[0].d.toLocaleDateString("es-AR",{day:"numeric",month:"long"})} — {dias[5].d.toLocaleDateString("es-AR",{day:"numeric",month:"long",year:"numeric"})}
            </div>
            {esSemanaActual && <div style={{ fontSize:11, color:"#e65100", fontWeight:600 }}>📅 Semana actual</div>}
          </div>
          <button onClick={()=>irSemana(1)} style={{ background:"#fff", border:"1.5px solid #f0d5c0", color:"#e65100", padding:"8px 14px", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>Sig. →</button>
        </div>
        <div style={{ display:"flex", gap:8 }}>
          <button onClick={()=>setSemanaInicio(getLunes(new Date()))}
            style={{ background:"#fff", color:"#e65100", border:"1.5px solid #f0d5c0", padding:"9px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            Hoy
          </button>
          <button onClick={()=>abrirModalNuevo(new Date().toISOString().split("T")[0], cfg.cats[0]?.id||"")}
            style={{ background:"#e65100", color:"#fff", border:"none", padding:"9px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", gap:6 }}>
            ➕ Nuevo pedido
          </button>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign:"center", padding:40, color:"#a09080" }}>Cargando...</div>
      ) : (
        <div style={{ overflowX:"auto" }}>
          <table style={{ borderCollapse:"collapse", width:"100%", minWidth:900 }}>
            {/* Header días */}
            <thead>
              <tr>
                <th style={{ width:110, background:"#1a2340", padding:"10px 12px", borderRight:"1px solid rgba(255,255,255,.15)", borderBottom:"none" }}/>
                {dias.map(d=>(
                  <th key={d.fecha} style={{ background:esHoy(d.fecha)?"#e65100":"#1a2340", padding:"10px 10px", borderRight:"1px solid rgba(255,255,255,.1)", borderBottom:"none", textAlign:"left", minWidth:150 }}>
                    <div style={{ fontWeight:700, fontSize:12, color:"#fff" }}>{d.nombre}</div>
                    <div style={{ fontSize:10, color:"rgba(255,255,255,.65)" }}>{d.d.toLocaleDateString("es-AR",{day:"numeric",month:"long"})}</div>
                    {countDia(d.fecha)>0 && (
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:3 }}>
                        <span style={{ fontSize:9, color:"#ffcc80", fontWeight:600 }}>{countDia(d.fecha)} trabajo{countDia(d.fecha)!==1?"s":""}</span>
                        <button onClick={()=>limpiarDia(d.fecha)} style={{ background:"rgba(255,255,255,.15)", border:"none", color:"#fff", borderRadius:4, padding:"1px 5px", fontSize:9, cursor:"pointer" }} title="Limpiar slots manuales">🗑</button>
                      </div>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {cfg.cats.map((cat,ci)=>{
                const expandida = isCatExpandida(cat.id);
                return (
                <tr key={cat.id}>
                  {/* Label categoría — clickeable para expandir/colapsar */}
                  <td onClick={()=>toggleCat(cat.id)}
                    style={{ background:cat.bg, padding:"6px 10px", borderRight:"1px solid #ddd", borderTop:"1px solid #ddd", verticalAlign:"middle", cursor:"pointer", userSelect:"none" }}>
                    <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:4 }}>
                      <span style={{ fontSize:10, fontWeight:800, color:cat.color, textTransform:"uppercase", letterSpacing:".4px" }}>{cat.label}</span>
                      <span style={{ fontSize:10, color:cat.color, opacity:.7 }}>{expandida?"▲":"▼"}</span>
                    </div>
                  </td>
                  {/* Slots por día */}
                  {dias.map(d=>{
                    const slots = grilla[d.fecha]?.[cat.id] || [{tel:"",desc:""}];
                    const presenciales = pedidosDelDia(d.fecha, cat.id);
                    const tieneAlgo = presenciales.length>0 || slots.some(s=>s?.tel||s?.desc);
                    return (
                      <td key={d.fecha} onClick={!expandida&&!tieneAlgo ? ()=>toggleCat(cat.id) : undefined}
                        style={{ padding: expandida?"5px 6px":"2px 6px", borderRight:"1px solid #e8e8e8", borderTop:"1px solid #e8e8e8",
                          verticalAlign:"top", background: expandida?"#fff": tieneAlgo?cat.bg+"80":"#fafafa",
                          cursor: !expandida&&!tieneAlgo?"pointer":"default" }}>

                        {/* Colapsado — solo mostrar badges si tiene algo */}
                        {!expandida && tieneAlgo && (
                          <div style={{ display:"flex", flexWrap:"wrap", gap:3, padding:"2px 0" }}>
                            {presenciales.map(p=>(
                              <span key={p.fireId} style={{ background:p.estado==="Listo"?"#ef5350":cat.color, color:"#fff", borderRadius:4, padding:"1px 5px", fontSize:9, fontWeight:700,
                                textDecoration:p.estado==="Listo"?"line-through":"none", opacity:p.estado==="Listo"?.7:1 }}>
                                {p.estado==="Listo"?"✓ ":"📋 "}{p.telefono||p.nombre.slice(0,8)}
                              </span>
                            ))}
                            {slots.filter(s=>s?.tel||s?.desc).map((s,i)=>(
                              <span key={i} style={{ background:cat.bg, color:cat.color, border:`1px solid ${cat.color}50`, borderRadius:4, padding:"1px 5px", fontSize:9, fontWeight:600 }}>
                                {s.tel||s.desc?.slice(0,8)}
                              </span>
                            ))}
                          </div>
                        )}
                        {!expandida && !tieneAlgo && (
                          <div style={{ height:6 }}/>
                        )}

                        {/* Expandido — vista completa */}
                        {expandida && (
                          <>
                            {presenciales.map(p=>{
                              const estadoP = p.estadoCalendario||0; // 0=pend, 1=prod, 2=listo
                              const enProd  = estadoP===1;
                              const listo   = estadoP===2;
                              const nextEst = (estadoP+1)%3;
                              const toggleEstado = async () => {
                                const estadoMap = { 0:"Pendiente", 1:"En Producción", 2:"Listo" };
                                await updateDoc(doc(db,"pedidos",p.fireId), {
                                  estadoCalendario: nextEst,
                                  estado: estadoMap[nextEst]
                                });
                                // Al pasar a En Producción ofrecer imprimir orden
                                if (nextEst === 1) {
                                  if (window.confirm("¿Querés imprimir la orden de trabajo?")) {
                                    const empSnap = await getDoc(doc(db,"config","empresa"));
                                    const emp = empSnap.exists() ? empSnap.data() : {};
                                    const html = buildOrdenHTML({...p, estado:"En Producción"}, emp);
                                    const win = window.open("","_blank","width=800,height=600");
                                    win.document.write(html); win.document.close(); win.print();
                                  }
                                }
                              };
                              return (
                                <div key={p.fireId} style={{ display:"flex", alignItems:"center", gap:4, marginBottom:4,
                                  padding:"4px 6px", borderRadius:5, transition:"all .2s",
                                  background: listo?"#ffebee": enProd?"#fffde7":cat.bg,
                                  border:`1.5px solid ${listo?"#ef5350": enProd?"#f9a825":cat.color}`,
                                  opacity: listo?.7:1 }}>
                                  <button onClick={toggleEstado}
                                    title={estadoP===0?"Marcar en producción":estadoP===1?"Marcar como listo":"Volver a pendiente"}
                                    style={{ background: listo?"#ef5350": enProd?"#f9a825":"transparent",
                                      border:`1.5px solid ${listo?"#ef5350": enProd?"#f9a825":"#ccc"}`,
                                      borderRadius:4, width:16, height:16, flexShrink:0,
                                      cursor:"pointer", display:"flex", alignItems:"center",
                                      justifyContent:"center", fontSize:9,
                                      color:(listo||enProd)?"#fff":"#bbb", padding:0, transition:"all .2s" }}>
                                    {listo?"✓": enProd?"⚙":""}
                                  </button>
                                  <div style={{ flex:1, minWidth:0 }}>
                                    <div style={{ fontSize:10, fontWeight:700,
                                      color:listo?"#ef5350": enProd?"#f57f17":cat.color,
                                      overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap",
                                      textDecoration:listo?"line-through":"none" }}>{p.telefono||"Sin tel"}</div>
                                    <div style={{ fontSize:10,
                                      color:listo?"#999": enProd?"#7a6000":"#4a5568",
                                      overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap",
                                      textDecoration:listo?"line-through":"none" }}>{p.nombre}</div>
                                  </div>
                                  {setViewApp && (
                                    <button onClick={()=>{
                                      const fresh = pedidosDB.find(x=>x.fireId===p.fireId)||p;
                                      if(setSelectedPedido) setSelectedPedido(fresh);
                                      if(setViewApp) setViewApp("detalle");
                                    }}
                                      style={{ background:listo?"#ef5350": enProd?"#f9a825":cat.color, border:"none", color:"#fff", borderRadius:4, padding:"2px 5px", fontSize:9, cursor:"pointer", flexShrink:0, fontWeight:700 }}>→</button>
                                  )}
                                </div>
                              );
                            })}
                            {slots.map((sl,si)=>{
                              const ok     = sl.tel||sl.desc;
                              // estado: 0=pendiente, 1=en producción, 2=listo
                              const estado = sl.estado||0;
                              const nextEstado = (estado+1) % 3;
                              const enProd = estado===1;
                              const listo  = estado===2;
                              return (
                                <div key={si} style={{ display:"flex", gap:3, marginBottom:4,
                                  padding:"3px 4px", borderRadius:5, transition:"all .2s",
                                  background: listo?"#ffebee": enProd?"#fffde7": ok?cat.bg:"#f8f9fa",
                                  border:`1px solid ${listo?"#ef9a9a": enProd?"#f9a825": ok?cat.color+"50":"#ebebeb"}`,
                                  opacity: listo?.75:1 }}>
                                  {/* Check 3 estados */}
                                  <button
                                    onClick={()=>updateSlot(d.fecha,cat.id,si,"estado",nextEstado)}
                                    title={estado===0?"Marcar en producción":estado===1?"Marcar como listo":"Volver a pendiente"}
                                    style={{
                                      background: listo?"#ef5350": enProd?"#f9a825":"transparent",
                                      border:`1.5px solid ${listo?"#ef5350": enProd?"#f9a825":"#ddd"}`,
                                      borderRadius:4, width:16, height:16, flexShrink:0, cursor:"pointer",
                                      display:"flex", alignItems:"center", justifyContent:"center",
                                      fontSize:9, color: (listo||enProd)?"#fff":"#bbb",
                                      padding:0, alignSelf:"center", transition:"all .2s" }}>
                                    {listo?"✓": enProd?"⚙":""}
                                  </button>
                                  <input value={sl.tel} onChange={e=>updateSlot(d.fecha,cat.id,si,"tel",e.target.value)}
                                    placeholder="Tel" style={{ ...inp, width:52,
                                      color: listo?"#ef5350": enProd?"#f57f17":cat.color,
                                      fontWeight:ok?600:400,
                                      textDecoration:listo?"line-through":"none" }}/>
                                  <input value={sl.desc} onChange={e=>updateSlot(d.fecha,cat.id,si,"desc",e.target.value)}
                                    placeholder="Detalle" style={{ ...inp, flex:1,
                                      textDecoration:listo?"line-through":"none",
                                      color:listo?"#999": enProd?"#7a6000":"inherit" }}/>
                                  {slots.length>1 && (
                                    <button onClick={()=>eliminarSlot(d.fecha,cat.id,si)}
                                      style={{ background:"transparent", border:"none", color:"#ccc", cursor:"pointer", fontSize:11, padding:"0 2px", lineHeight:1, flexShrink:0 }}>✕</button>
                                  )}
                                </div>
                              );
                            })}
                            <button onClick={()=>abrirModalNuevo(d.fecha,cat.id)}
                              style={{ width:"100%", padding:"3px 0", background:"transparent", border:`1px dashed ${cat.color}50`,
                                color:cat.color, borderRadius:5, fontSize:12, cursor:"pointer", opacity:.6, fontWeight:700 }}>+</button>
                          </>
                        )}
                      </td>
                    );
                  })}
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Leyenda */}
      <div style={{ display:"flex", gap:12, flexWrap:"wrap", marginTop:12, alignItems:"center" }}>
        <div style={{ display:"flex", alignItems:"center", gap:5, fontSize:11 }}>
          <div style={{ width:10, height:10, borderRadius:2, background:"#e3f2fd", border:"1.5px solid #1565c0" }}/>
          <span style={{ color:"#4a5568" }}>📋 Pedido — clic en + para agregar</span>
        </div>
      </div>

      {/* Modal nuevo pedido desde calendario */}
      {modalNuevo && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:400, padding:16 }}
          onClick={()=>setModalNuevo(null)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"26px 30px", width:500, maxHeight:"90vh", overflowY:"auto", boxShadow:"0 24px 80px rgba(0,0,0,.25)" }}
            onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:18, color:"#1a2340", marginBottom:4 }}>➕ Nuevo pedido</div>
            <div style={{ fontSize:12, color:"#a09080", marginBottom:20 }}>
              {modalNuevo.catId} · entrega {fmtFecha(modalNuevo.fecha)}
            </div>

            <div style={{ display:"flex", flexDirection:"column", gap:13 }}>

              {/* Teléfono con sugerencias */}
              <div style={{ position:"relative" }}>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>Teléfono</label>
                <input value={mTel} onChange={e=>{
                    setMTel(e.target.value);
                    setMClienteBusq(e.target.value);
                    setMShowSugg(true);
                  }}
                  onFocus={()=>setMShowSugg(true)}
                  placeholder="Ej: 341 555-1234"
                  style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                {/* Sugerencias de clientes por teléfono */}
                {mShowSugg && mTel.length > 2 && (() => {
                  const sugg = clientes.filter(c =>
                    (c.telefono||"").includes(mTel) ||
                    (`${c.nombre||""} ${c.apellido||""}`).toLowerCase().includes(mTel.toLowerCase())
                  ).slice(0,5);
                  return sugg.length > 0 ? (
                    <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:"1.5px solid #f0d5c0", borderRadius:8, boxShadow:"0 8px 24px rgba(0,0,0,.12)", zIndex:10, overflow:"hidden" }}>
                      {sugg.map(c=>(
                        <div key={c.fireId} onClick={()=>{
                            setMTel(c.telefono||"");
                            setMClienteId(c.fireId);
                            setMClienteNombre(`${c.nombre||""} ${c.apellido||""}`.trim());
                            setMShowSugg(false);
                          }}
                          style={{ padding:"10px 14px", cursor:"pointer", borderBottom:"1px solid #fef0e8", fontSize:13 }}
                          onMouseEnter={e=>e.currentTarget.style.background="#fff8f5"}
                          onMouseLeave={e=>e.currentTarget.style.background="#fff"}>
                          <div style={{ fontWeight:600, color:"#1a2340" }}>{`${c.nombre||""} ${c.apellido||""}`.trim()}</div>
                          <div style={{ fontSize:11, color:"#a09080" }}>{c.telefono}</div>
                        </div>
                      ))}
                    </div>
                  ) : null;
                })()}
              </div>

              {/* Cliente con sugerencias */}
              <div style={{ position:"relative" }}>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>
                  Cliente
                  {mClienteId && <span style={{ marginLeft:8, fontSize:11, color:"#e65100", fontWeight:600 }}>✓ vinculado</span>}
                </label>
                <input value={mClienteNombre} onChange={e=>{
                    setMClienteNombre(e.target.value);
                    setMClienteId(null);
                    setMShowSugg(true);
                  }}
                  onFocus={()=>setMShowSugg(true)}
                  placeholder="Nombre del cliente"
                  style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:`1.5px solid ${mClienteId?"#e65100":"#f0d5c0"}`, fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                {/* Sugerencias por nombre */}
                {mShowSugg && mClienteNombre.length > 1 && !mClienteId && (() => {
                  const sugg = clientes.filter(c =>
                    (`${c.nombre||""} ${c.apellido||""}`).toLowerCase().includes(mClienteNombre.toLowerCase()) ||
                    (c.empresa||"").toLowerCase().includes(mClienteNombre.toLowerCase())
                  ).slice(0,5);
                  return sugg.length > 0 ? (
                    <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:"1.5px solid #f0d5c0", borderRadius:8, boxShadow:"0 8px 24px rgba(0,0,0,.12)", zIndex:10, overflow:"hidden" }}>
                      {sugg.map(c=>(
                        <div key={c.fireId} onClick={()=>{
                            setMClienteId(c.fireId);
                            setMClienteNombre(`${c.nombre||""} ${c.apellido||""}`.trim());
                            if (!mTel) setMTel(c.telefono||"");
                            setMShowSugg(false);
                          }}
                          style={{ padding:"10px 14px", cursor:"pointer", borderBottom:"1px solid #fef0e8", fontSize:13 }}
                          onMouseEnter={e=>e.currentTarget.style.background="#fff8f5"}
                          onMouseLeave={e=>e.currentTarget.style.background="#fff"}>
                          <div style={{ fontWeight:600, color:"#1a2340" }}>{`${c.nombre||""} ${c.apellido||""}`.trim()}</div>
                          <div style={{ fontSize:11, color:"#a09080" }}>{c.telefono} {c.empresa ? `· ${c.empresa}`:""}</div>
                        </div>
                      ))}
                    </div>
                  ) : null;
                })()}
              </div>

              {/* Nombre del pedido */}
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>Nombre del pedido *</label>
                <input value={mNombre} onChange={e=>setMNombre(e.target.value)}
                  onFocus={()=>setMShowSugg(false)}
                  placeholder="Ej: Vinilo puerta local"
                  style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #e65100", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box", fontWeight:600 }}/>
              </div>

              {/* Precio y seña */}
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>Precio ($)</label>
                  <input type="number" value={mPrecio} onChange={e=>setMPrecio(e.target.value)} placeholder="0"
                    style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>Seña ($)</label>
                  <input type="number" value={mSeña} onChange={e=>setMSeña(e.target.value)} placeholder="0"
                    style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                </div>
              </div>

              {/* Detalle */}
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>Detalle del pedido</label>
                <div style={{ display:"flex", flexDirection:"column", gap:5 }}>
                  {mDetalleItems.map((item, idx) => (
                    <div key={idx} style={{ display:"flex", gap:6, alignItems:"center" }}>
                      <span style={{ fontSize:11, color:"#a09080", minWidth:16, textAlign:"right" }}>{idx+1}.</span>
                      <input value={item}
                        onChange={e => { const arr=[...mDetalleItems]; arr[idx]=e.target.value; setMDetalleItems(arr); }}
                        onKeyDown={e => {
                          if (e.key==="Enter") { e.preventDefault(); const arr=[...mDetalleItems]; arr.splice(idx+1,0,""); setMDetalleItems(arr); }
                          if (e.key==="Backspace" && !item && mDetalleItems.length>1) { e.preventDefault(); const arr=[...mDetalleItems]; arr.splice(idx,1); setMDetalleItems(arr); }
                        }}
                        placeholder={idx===0 ? "Medidas, color, cantidad..." : ""}
                        style={{ flex:1, padding:"8px 10px", borderRadius:7, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                      {mDetalleItems.length>1 && (
                        <button onClick={()=>{ const arr=[...mDetalleItems]; arr.splice(idx,1); setMDetalleItems(arr); }}
                          style={{ background:"transparent", border:"none", color:"#ccc", cursor:"pointer", fontSize:15, padding:"0 3px" }}>✕</button>
                      )}
                    </div>
                  ))}
                  <button onClick={()=>setMDetalleItems(a=>[...a,""])}
                    style={{ alignSelf:"flex-start", background:"transparent", border:"1px dashed #f0d5c0", color:"#e65100", borderRadius:6, padding:"3px 10px", fontSize:12, cursor:"pointer", marginTop:2 }}>
                    + Agregar ítem
                  </button>
                </div>
              </div>

              {/* Fechas */}
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>Fecha de solicitud</label>
                  <div style={{ padding:"10px 12px", borderRadius:8, background:"#f8f9fa", fontSize:13, color:"#a09080" }}>
                    {fmtFecha(new Date().toISOString().split("T")[0])}
                  </div>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 }}>Fecha de entrega</label>
                  <input type="date" value={mEntrega} onChange={e=>setMEntrega(e.target.value)}
                    style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                </div>
              </div>

            </div>

            <div style={{ display:"flex", gap:10, marginTop:22 }}>
              <button onClick={()=>setModalNuevo(null)}
                style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>
                Cancelar
              </button>
              <button onClick={guardarPedidoDesdeCalendario} disabled={savingM||!mNombre.trim()}
                style={{ flex:2, padding:"11px", background:!mNombre.trim()?"#f0d5c0":"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:!mNombre.trim()?"not-allowed":"pointer" }}>
                {savingM ? "Guardando..." : "✅ Crear pedido"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Componente: Control de Producción ────────────────────────────────────
const SQ_FT_TO_M2 = 0.092903;
const MESES = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"];

function ProduccionView({ showToast }) {
  const [tabProd, setTabProd] = useState("plotter");

  const TABS = [
    { id:"plotter", label:"🖨️ Hancolor i3200" },
    { id:"konica",  label:"🖥️ Konica Minolta C558" },
    { id:"tinta",   label:"💧 Impresoras de tinta" },
  ];

  return (
    <div>
      {/* Tabs */}
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTabProd(t.id)}
            style={{ padding:"10px 22px", borderRadius:20, fontSize:14, fontWeight:600,
              cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
              background:tabProd===t.id?"#e65100":"#fff",
              color:tabProd===t.id?"#fff":"#4a5568",
              boxShadow:tabProd===t.id?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(0,0,0,.06)" }}>
            {t.label}
          </button>
        ))}
      </div>
      {tabProd==="plotter" && <PlotterView showToast={showToast}/>}
      {tabProd==="konica"  && <KonicaView  showToast={showToast}/>}
      {tabProd==="tinta"   && <TintaView   showToast={showToast}/>}
    </div>
  );
}

// ── Impresoras de Tinta ───────────────────────────────────────────────────
const COLORES_TINTA = [
  { id:"negro",     label:"Negro",      color:"#212121", bg:"#f5f5f5" },
  { id:"cian",      label:"Cian",       color:"#0097a7", bg:"#e0f7fa" },
  { id:"magenta",   label:"Magenta",    color:"#c2185b", bg:"#fce4ec" },
  { id:"amarillo",  label:"Amarillo",   color:"#f9a825", bg:"#fffde7" },
  { id:"foto_neg",  label:"Negro foto", color:"#424242", bg:"#eeeeee" },
  { id:"otro",      label:"Otro",       color:"#546e7a", bg:"#eceff1" },
];

const TIPOS_PAPEL = ["Brillante", "Mate", "Satinado", "Seda", "Canvas", "Adhesivo brillante", "Adhesivo mate", "Otro"];
const TAMAÑOS_PAPEL = ["10×15", "13×18", "15×20", "A4", "A3", "A3+", "Rollo", "Otro"];

function TintaView({ showToast }) {
  const [tintas,   setTintas]   = useState([]);
  const [papeles,  setPapeles]  = useState([]);
  const [loadingT, setLoadingT] = useState(true);
  const [loadingP, setLoadingP] = useState(true);
  const [modalTinta,  setModalTinta]  = useState(false);
  const [modalPapel,  setModalPapel]  = useState(false);
  const [tabInk, setTabInk]          = useState("tintas");

  // Form tinta
  const [tColor,    setTColor]   = useState("negro");
  const [tMarca,    setTMarca]   = useState("");
  const [tCantidad, setTCantidad]= useState("");
  const [tPrecio,   setTPrecio]  = useState("");
  const [tFecha,    setTFecha]   = useState(new Date().toISOString().split("T")[0]);
  const [tNota,     setTNota]    = useState("");
  const [savingT,   setSavingT]  = useState(false);

  // Form papel
  const [pTipo,     setPTipo]    = useState("Brillante");
  const [pTamaño,   setPTamaño]  = useState("A4");
  const [pCantidad, setPCantidad]= useState("");
  const [pPrecio,   setPPrecio]  = useState("");
  const [pFecha,    setPFecha]   = useState(new Date().toISOString().split("T")[0]);
  const [pNota,     setPNota]    = useState("");
  const [savingP,   setSavingP]  = useState(false);

  useEffect(() => {
    const u1 = onSnapshot(collection(db,"tintasInkjet"), snap => {
      setTintas(snap.docs.map(d=>({...d.data(),fireId:d.id}))
        .sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")));
      setLoadingT(false);
    });
    const u2 = onSnapshot(collection(db,"papelesInkjet"), snap => {
      setPapeles(snap.docs.map(d=>({...d.data(),fireId:d.id}))
        .sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")));
      setLoadingP(false);
    });
    return ()=>{ u1(); u2(); };
  }, []);

  const handleGuardarTinta = async () => {
    if (!tMarca.trim()) { showToast("Ingresá la marca/modelo","error"); return; }
    setSavingT(true);
    await addDoc(collection(db,"tintasInkjet"), {
      color:tColor, marca:tMarca, cantidad:parseFloat(tCantidad)||1,
      precio:parseFloat(tPrecio)||0, fecha:tFecha, nota:tNota,
      cargadoEn:new Date().toISOString()
    });
    showToast("Tinta registrada ✅");
    setSavingT(false); setModalTinta(false);
    setTMarca(""); setTCantidad(""); setTPrecio(""); setTNota("");
  };

  const handleGuardarPapel = async () => {
    if (!pCantidad) { showToast("Ingresá la cantidad","error"); return; }
    setSavingP(true);
    await addDoc(collection(db,"papelesInkjet"), {
      tipo:pTipo, tamaño:pTamaño, cantidad:parseInt(pCantidad)||0,
      precio:parseFloat(pPrecio)||0, fecha:pFecha, nota:pNota,
      cargadoEn:new Date().toISOString()
    });
    showToast("Papel registrado ✅");
    setSavingP(false); setModalPapel(false);
    setPCantidad(""); setPPrecio(""); setPNota("");
  };

  const delTinta = async (r) => {
    if (!window.confirm("¿Eliminar?")) return;
    await deleteDoc(doc(db,"tintasInkjet",r.fireId));
    showToast("Eliminado","error");
  };
  const delPapel = async (r) => {
    if (!window.confirm("¿Eliminar?")) return;
    await deleteDoc(doc(db,"papelesInkjet",r.fireId));
    showToast("Eliminado","error");
  };

  const totalTintas = tintas.reduce((s,r)=>s+parseFloat(r.precio||0),0);
  const totalPapeles = papeles.reduce((s,r)=>s+parseFloat(r.precio||0),0);

  const inp = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0",
    fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };

  return (
    <div>
      {/* Sub-tabs + botones */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:10 }}>
        <div style={{ display:"flex", gap:8 }}>
          {[["tintas","💧 Tintas"],["papeles","📄 Papeles fotográficos"]].map(([id,lbl])=>(
            <button key={id} onClick={()=>setTabInk(id)}
              style={{ padding:"9px 20px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none",
                background:tabInk===id?"#1a2340":"#fff", color:tabInk===id?"#fff":"#4a5568",
                boxShadow:tabInk===id?"0 3px 10px rgba(26,35,64,.2)":"0 1px 6px rgba(0,0,0,.06)" }}>
              {lbl}
            </button>
          ))}
        </div>
        <div style={{ display:"flex", gap:10 }}>
          <button onClick={()=>setModalPapel(true)}
            style={{ background:"#1a2340", color:"#fff", border:"none", padding:"10px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            ➕ Registrar papel
          </button>
          <button onClick={()=>setModalTinta(true)}
            style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            ➕ Registrar tinta
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:20 }}>
        {[
          { label:"Reposiciones de tinta", valor:tintas.length, color:"#e65100" },
          { label:"Invertido en tinta", valor:`$${totalTintas.toLocaleString("es-AR")}`, color:"#e65100" },
          { label:"Compras de papel", valor:papeles.length, color:"#1a2340" },
          { label:"Invertido en papel", valor:`$${totalPapeles.toLocaleString("es-AR")}`, color:"#1a2340" },
        ].map((k,i)=>(
          <div key={i} style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px" }}>
            <div style={{ fontSize:10, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:6 }}>{k.label}</div>
            <div style={{ fontSize:20, fontWeight:800, color:k.color }}>{k.valor}</div>
          </div>
        ))}
      </div>

      {/* ── TAB TINTAS ── */}
      {tabInk==="tintas" && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <div style={{ padding:"16px 20px", borderBottom:"1px solid #f0d5c0", display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:10 }}>
            <div style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>💧 Historial de tintas</div>
            {/* Resumen por color */}
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {COLORES_TINTA.map(c=>{
                const cant = tintas.filter(t=>t.color===c.id).length;
                if (!cant) return null;
                return <span key={c.id} style={{ background:c.bg, color:c.color, border:`1.5px solid ${c.color}40`, padding:"2px 10px", borderRadius:20, fontSize:11, fontWeight:700 }}>{c.label}: {cant}</span>;
              })}
            </div>
          </div>
          {loadingT ? <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Cargando...</div>
          : tintas.length===0 ? <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Sin registros — registrá tu primera reposición</div>
          : (
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
              <thead><tr style={{ background:"#f8f9fa" }}>
                {["Fecha","Color","Marca / Modelo","Cantidad","Precio","Notas",""].map(h=>(
                  <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".5px", borderBottom:"1px solid #f0d5c0" }}>{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {tintas.map(r=>{
                  const c = COLORES_TINTA.find(x=>x.id===r.color)||COLORES_TINTA[0];
                  return (
                    <tr key={r.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                      <td style={{ padding:"11px 14px", color:"#4a5568" }}>{fmtFecha(r.fecha)}</td>
                      <td style={{ padding:"11px 14px" }}>
                        <span style={{ background:c.bg, color:c.color, border:`1.5px solid ${c.color}50`, padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:700 }}>{c.label}</span>
                      </td>
                      <td style={{ padding:"11px 14px", fontWeight:600, color:"#1a2340" }}>{r.marca}</td>
                      <td style={{ padding:"11px 14px", color:"#4a5568" }}>{r.cantidad} u.</td>
                      <td style={{ padding:"11px 14px", fontWeight:700, color:"#e65100" }}>{r.precio?`$${parseFloat(r.precio).toLocaleString("es-AR")}`:"—"}</td>
                      <td style={{ padding:"11px 14px", color:"#a09080", fontStyle:"italic" }}>{r.nota||"—"}</td>
                      <td style={{ padding:"11px 10px" }}>
                        <button onClick={()=>delTinta(r)} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* ── TAB PAPELES ── */}
      {tabInk==="papeles" && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <div style={{ padding:"16px 20px", borderBottom:"1px solid #f0d5c0", fontWeight:700, fontSize:15, color:"#1a2340" }}>📄 Historial de papeles fotográficos</div>
          {loadingP ? <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Cargando...</div>
          : papeles.length===0 ? <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Sin registros — registrá tu primera compra de papel</div>
          : (
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
              <thead><tr style={{ background:"#f8f9fa" }}>
                {["Fecha","Tipo","Tamaño","Cantidad","Precio","Notas",""].map(h=>(
                  <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".5px", borderBottom:"1px solid #f0d5c0" }}>{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {papeles.map(r=>(
                  <tr key={r.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                    <td style={{ padding:"11px 14px", color:"#4a5568" }}>{fmtFecha(r.fecha)}</td>
                    <td style={{ padding:"11px 14px" }}>
                      <span style={{ background:"#e3f2fd", color:"#1565c0", padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:600 }}>{r.tipo}</span>
                    </td>
                    <td style={{ padding:"11px 14px", fontWeight:600, color:"#1a2340" }}>{r.tamaño}</td>
                    <td style={{ padding:"11px 14px", color:"#4a5568" }}>{parseInt(r.cantidad).toLocaleString("es-AR")} hojas</td>
                    <td style={{ padding:"11px 14px", fontWeight:700, color:"#e65100" }}>{r.precio?`$${parseFloat(r.precio).toLocaleString("es-AR")}`:"—"}</td>
                    <td style={{ padding:"11px 14px", color:"#a09080", fontStyle:"italic" }}>{r.nota||"—"}</td>
                    <td style={{ padding:"11px 10px" }}>
                      <button onClick={()=>delPapel(r)} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* Modal tinta */}
      {modalTinta && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={()=>setModalTinta(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:460, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:20 }}>💧 Registrar tinta</div>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:8 }}>Color</label>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
                  {COLORES_TINTA.map(c=>(
                    <div key={c.id} onClick={()=>setTColor(c.id)}
                      style={{ padding:"9px", borderRadius:10, cursor:"pointer", textAlign:"center",
                        border:`2px solid ${tColor===c.id?c.color:"#f0d5c0"}`,
                        background:tColor===c.id?c.bg:"#fff" }}>
                      <div style={{ fontWeight:700, fontSize:12, color:c.color }}>{c.label}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Marca / Modelo *</label>
                <input value={tMarca} onChange={e=>setTMarca(e.target.value)} placeholder="Ej: Epson T664 original, compatible genérico..." style={inp} autoFocus/>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Fecha</label>
                  <input type="date" value={tFecha} onChange={e=>setTFecha(e.target.value)} style={inp}/>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Cantidad</label>
                  <input type="number" value={tCantidad} onChange={e=>setTCantidad(e.target.value)} placeholder="1" style={inp}/>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio ($)</label>
                  <input type="number" value={tPrecio} onChange={e=>setTPrecio(e.target.value)} placeholder="0" style={inp}/>
                </div>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nota (opcional)</label>
                <input value={tNota} onChange={e=>setTNota(e.target.value)} placeholder="Ej: comprado en Mercado Libre" style={inp}/>
              </div>
            </div>
            <div style={{ display:"flex", gap:10, marginTop:22 }}>
              <button onClick={()=>setModalTinta(false)} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleGuardarTinta} disabled={savingT}
                style={{ flex:2, padding:"11px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
                {savingT?"Guardando...":"💧 Registrar"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal papel */}
      {modalPapel && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={()=>setModalPapel(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:460, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:20 }}>📄 Registrar papel fotográfico</div>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Tipo de papel</label>
                  <select value={pTipo} onChange={e=>setPTipo(e.target.value)} style={{ ...inp, cursor:"pointer" }}>
                    {TIPOS_PAPEL.map(t=><option key={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Tamaño</label>
                  <select value={pTamaño} onChange={e=>setPTamaño(e.target.value)} style={{ ...inp, cursor:"pointer" }}>
                    {TAMAÑOS_PAPEL.map(t=><option key={t}>{t}</option>)}
                  </select>
                </div>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Fecha</label>
                  <input type="date" value={pFecha} onChange={e=>setPFecha(e.target.value)} style={inp}/>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Cantidad (hojas)</label>
                  <input type="number" value={pCantidad} onChange={e=>setPCantidad(e.target.value)} placeholder="100" style={inp} autoFocus/>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio ($)</label>
                  <input type="number" value={pPrecio} onChange={e=>setPPrecio(e.target.value)} placeholder="0" style={inp}/>
                </div>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nota (opcional)</label>
                <input value={pNota} onChange={e=>setPNota(e.target.value)} placeholder="Ej: papel Epson premium, comprado en proveedor X" style={inp}/>
              </div>
            </div>
            <div style={{ display:"flex", gap:10, marginTop:22 }}>
              <button onClick={()=>setModalPapel(false)} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleGuardarPapel} disabled={savingP}
                style={{ flex:2, padding:"11px", background:"#1a2340", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
                {savingP?"Guardando...":"📄 Registrar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Plotter Hancolor i3200 (ex ProduccionView) ────────────────────────────
function PlotterView({ showToast }) {
  const [registros, setRegistros] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [modal, setModal]         = useState(false);
  const [anioVer, setAnioVer]     = useState(new Date().getFullYear());

  // Form
  const [mes,   setMes]   = useState(new Date().getMonth());
  const [anio,  setAnio]  = useState(new Date().getFullYear());
  const [sqft,  setSqft]  = useState("");
  const [nota,  setNota]  = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db,"produccion"), snap => {
      setRegistros(snap.docs.map(d=>({...d.data(),fireId:d.id}))
        .sort((a,b)=>a.anio!==b.anio?a.anio-b.anio:a.mes-b.mes));
      setLoading(false);
    });
    return ()=>unsub();
  }, []);

  const handleGuardar = async () => {
    if (!sqft || parseFloat(sqft)<=0) { showToast("Ingresá los sq ft","error"); return; }
    setSaving(true);
    const m2 = parseFloat(sqft) * SQ_FT_TO_M2;
    // Si ya existe ese mes/año, actualizar
    const existe = registros.find(r=>r.mes===parseInt(mes)&&r.anio===parseInt(anio));
    if (existe) {
      await updateDoc(doc(db,"produccion",existe.fireId), { sqft:parseFloat(sqft), m2, nota });
      showToast("Registro actualizado ✅");
    } else {
      await addDoc(collection(db,"produccion"), { mes:parseInt(mes), anio:parseInt(anio), sqft:parseFloat(sqft), m2, nota, cargadoEn:new Date().toISOString() });
      showToast("Registro guardado ✅");
    }
    setSaving(false);
    setModal(false);
    setSqft(""); setNota("");
  };

  const handleEliminar = async (r) => {
    if (!window.confirm("¿Eliminar este registro?")) return;
    await deleteDoc(doc(db,"produccion",r.fireId));
    showToast("Eliminado","error");
  };

  // Datos del año seleccionado para el gráfico
  const delAnio = registros.filter(r=>r.anio===anioVer);
  const anios   = [...new Set(registros.map(r=>r.anio))].sort();
  const totalAnio = delAnio.reduce((s,r)=>s+r.m2,0);
  const maxM2     = Math.max(...delAnio.map(r=>r.m2), 1);

  // Acumulado histórico para línea de crecimiento
  let acum = 0;
  const acumulado = registros.map(r=>{ acum+=r.m2; return {...r, acum}; });

  const fmt = n => n>=1000 ? `${(n/1000).toFixed(1)}k` : Math.round(n).toString();

  return (
    <div>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <div style={{ display:"flex", gap:10, alignItems:"center" }}>
          {anios.map(a=>(
            <button key={a} onClick={()=>setAnioVer(a)}
              style={{ padding:"7px 16px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none",
                background:anioVer===a?"#e65100":"#fff", color:anioVer===a?"#fff":"#4a5568",
                boxShadow:anioVer===a?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(0,0,0,.06)" }}>
              {a}
            </button>
          ))}
        </div>
        <button onClick={()=>setModal(true)}
          style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 22px", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
          ➕ Cargar mes
        </button>
      </div>

      {/* KPIs */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14, marginBottom:20 }}>
        {[
          { label:`Total ${anioVer}`, valor:`${totalAnio.toLocaleString("es-AR",{maximumFractionDigits:1})} m²`, sub:`${(totalAnio/SQ_FT_TO_M2).toLocaleString("es-AR",{maximumFractionDigits:0})} sq ft` },
          { label:"Promedio mensual", valor:`${(delAnio.length>0?totalAnio/delAnio.length:0).toLocaleString("es-AR",{maximumFractionDigits:1})} m²`, sub:`${delAnio.length} meses cargados` },
          { label:"Total histórico", valor:`${registros.reduce((s,r)=>s+r.m2,0).toLocaleString("es-AR",{maximumFractionDigits:1})} m²`, sub:"desde el inicio" },
        ].map((k,i)=>(
          <div key={i} style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"16px 20px" }}>
            <div style={{ fontSize:11, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:6 }}>{k.label}</div>
            <div style={{ fontSize:22, fontWeight:800, color:"#e65100" }}>{k.valor}</div>
            <div style={{ fontSize:11, color:"#a09080", marginTop:3 }}>{k.sub}</div>
          </div>
        ))}
      </div>

      {/* Gráfico de barras mensual */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"22px 24px", marginBottom:20 }}>
        <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:4 }}>📊 m² impresos por mes — {anioVer}</div>
        <div style={{ fontSize:12, color:"#a09080", marginBottom:18 }}>1 sq ft = 0.0929 m²</div>
        {delAnio.length===0 ? (
          <div style={{ textAlign:"center", padding:"32px 0", color:"#a09080", fontSize:13 }}>Sin datos para {anioVer} — cargá el primer mes</div>
        ) : (
          <div style={{ display:"flex", alignItems:"flex-end", gap:8, height:180 }}>
            {MESES.map((m,i)=>{
              const r = delAnio.find(x=>x.mes===i);
              const h = r ? Math.max((r.m2/maxM2)*160, 4) : 0;
              return (
                <div key={i} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
                  {r && <div style={{ fontSize:9, fontWeight:700, color:"#e65100" }}>{fmt(r.m2)}</div>}
                  <div style={{ width:"100%", borderRadius:"4px 4px 0 0", transition:"height .4s",
                    height:h, background:r?"#e65100":"#f5e8e0",
                    minHeight: r?4:0 }}/>
                  <div style={{ fontSize:10, color:r?"#1a2340":"#c0b0a0", fontWeight:r?700:400 }}>{m}</div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Gráfico acumulado histórico */}
      {registros.length>1 && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"22px 24px", marginBottom:20 }}>
          <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:16 }}>📈 Crecimiento acumulado histórico</div>
          <div style={{ display:"flex", alignItems:"flex-end", gap:4, height:120 }}>
            {acumulado.map((r,i)=>{
              const h = Math.max((r.acum/acumulado[acumulado.length-1].acum)*100,4);
              return (
                <div key={i} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:3 }}>
                  <div style={{ width:"100%", borderRadius:"3px 3px 0 0", background:"#1a2340",
                    height:`${h}%`, minHeight:4, transition:"height .4s" }}/>
                  <div style={{ fontSize:9, color:"#a09080", textAlign:"center", lineHeight:1.2 }}>
                    {MESES[r.mes]}<br/>{r.anio}
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ marginTop:12, textAlign:"right", fontSize:13, color:"#a09080" }}>
            Total acumulado: <strong style={{color:"#1a2340"}}>{Math.round(acumulado[acumulado.length-1]?.acum||0).toLocaleString("es-AR")} m²</strong>
          </div>
        </div>
      )}

      {/* Tabla detalle */}
      {registros.length>0 && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
            <thead><tr style={{ background:"#fff8f5" }}>
              {["Período","Sq Ft","m²","Notas",""].map(h=>(
                <th key={h} style={{ padding:"11px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f0d5c0" }}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {[...registros].reverse().map(r=>(
                <tr key={r.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                  <td style={{ padding:"11px 16px", fontWeight:700, color:"#1a2340" }}>{MESES[r.mes]} {r.anio}</td>
                  <td style={{ padding:"11px 16px", color:"#4a5568" }}>{r.sqft.toLocaleString("es-AR",{maximumFractionDigits:1})}</td>
                  <td style={{ padding:"11px 16px", fontWeight:700, color:"#e65100" }}>{r.m2.toLocaleString("es-AR",{maximumFractionDigits:2})} m²</td>
                  <td style={{ padding:"11px 16px", color:"#a09080", fontStyle:"italic" }}>{r.nota||"—"}</td>
                  <td style={{ padding:"11px 14px" }}>
                    <div style={{ display:"flex", gap:6 }}>
                      <button onClick={()=>{ setMes(r.mes); setAnio(r.anio); setSqft(r.sqft); setNota(r.nota||""); setModal(true); }}
                        style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>✏️</button>
                      <button onClick={()=>handleEliminar(r)}
                        style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal cargar mes */}
      {modal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={()=>setModal(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:420, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:20 }}>📥 Cargar producción mensual</div>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Mes</label>
                  <select value={mes} onChange={e=>setMes(parseInt(e.target.value))}
                    style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none" }}>
                    {MESES.map((m,i)=><option key={i} value={i}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Año</label>
                  <input type="number" value={anio} onChange={e=>setAnio(parseInt(e.target.value))}
                    style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                </div>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Sq Ft impresos (del sistema)</label>
                <input type="number" step="0.1" value={sqft} onChange={e=>setSqft(e.target.value)} placeholder="Ej: 1250.5" autoFocus
                  style={{ width:"100%", padding:"11px 14px", borderRadius:8, border:"1.5px solid #e65100", fontSize:16, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box", fontWeight:700 }}/>
                {sqft>0 && (
                  <div style={{ marginTop:8, background:"#fff8f5", borderRadius:8, padding:"8px 14px", display:"flex", justifyContent:"space-between" }}>
                    <span style={{ fontSize:13, color:"#a09080" }}>{parseFloat(sqft).toLocaleString("es-AR",{maximumFractionDigits:1})} sq ft =</span>
                    <span style={{ fontWeight:800, fontSize:16, color:"#e65100" }}>{(parseFloat(sqft)*SQ_FT_TO_M2).toLocaleString("es-AR",{maximumFractionDigits:2})} m²</span>
                  </div>
                )}
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nota (opcional)</label>
                <input value={nota} onChange={e=>setNota(e.target.value)} placeholder="Ej: mes con trabajo de lona grande"
                  style={{ width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
              </div>
            </div>
            <div style={{ display:"flex", gap:10, marginTop:22 }}>
              <button onClick={()=>setModal(false)} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleGuardar} disabled={saving||!sqft}
                style={{ flex:2, padding:"11px", background:!sqft?"#f0d5c0":"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:!sqft?"not-allowed":"pointer" }}>
                {saving?"Guardando...":"💾 Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Konica Minolta C558 ───────────────────────────────────────────────────
const TONERES = [
  { id:"cian",     label:"Cian",    color:"#0097a7", bg:"#e0f7fa" },
  { id:"magenta",  label:"Magenta", color:"#c2185b", bg:"#fce4ec" },
  { id:"amarillo", label:"Amarillo",color:"#f9a825", bg:"#fffde7" },
  { id:"negro",    label:"Negro",   color:"#212121", bg:"#f5f5f5" },
];

function KonicaView({ showToast }) {
  const [contadores, setContadores] = useState([]);
  const [toners,     setToners]     = useState([]);
  const [loadingC,   setLoadingC]   = useState(true);
  const [loadingT,   setLoadingT]   = useState(true);
  const [modalCont,  setModalCont]  = useState(false);
  const [modalToner, setModalToner] = useState(false);

  // Form contador
  const [mes,    setMes]    = useState(new Date().getMonth());
  const [anio,   setAnio]   = useState(new Date().getFullYear());
  const [pagBN,  setPagBN]  = useState("");
  const [pagCol, setPagCol] = useState("");
  const [notaC,  setNotaC]  = useState("");
  const [saving, setSaving] = useState(false);

  // Form toner
  const [tonerTipo,   setTonerTipo]   = useState("cian");
  const [tonerFecha,  setTonerFecha]  = useState(new Date().toISOString().split("T")[0]);
  const [tonerNota,   setTonerNota]   = useState("");
  const [tonerPrecio, setTonerPrecio] = useState("");
  const [savingT,     setSavingT]     = useState(false);

  // Form consumibles
  const [consumibles,      setConsumibles]      = useState([]);
  const [loadingCons,      setLoadingCons]      = useState(true);
  const [modalCons,        setModalCons]        = useState(false);
  const [consDesc,         setConsDesc]         = useState("");
  const [consFecha,        setConsFecha]        = useState(new Date().toISOString().split("T")[0]);
  const [consValor,        setConsValor]        = useState("");
  const [consNota,         setConsNota]         = useState("");
  const [savingCons,       setSavingCons]       = useState(false);

  const anioActual = new Date().getFullYear();
  const [anioVer, setAnioVer] = useState(anioActual);

  useEffect(() => {
    const u1 = onSnapshot(collection(db,"konicaContadores"), snap => {
      setContadores(snap.docs.map(d=>({...d.data(),fireId:d.id}))
        .sort((a,b)=>a.anio!==b.anio?a.anio-b.anio:a.mes-b.mes));
      setLoadingC(false);
    });
    const u2 = onSnapshot(collection(db,"konicaToners"), snap => {
      setToners(snap.docs.map(d=>({...d.data(),fireId:d.id}))
        .sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")));
      setLoadingT(false);
    });
    const u3 = onSnapshot(collection(db,"konicaConsumibles"), snap => {
      setConsumibles(snap.docs.map(d=>({...d.data(),fireId:d.id}))
        .sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")));
      setLoadingCons(false);
    });
    return ()=>{ u1(); u2(); u3(); };
  }, []);

  const handleGuardarContador = async () => {
    if (!pagBN && !pagCol) { showToast("Ingresá al menos un contador","error"); return; }
    setSaving(true);
    const existe = contadores.find(r=>r.mes===parseInt(mes)&&r.anio===parseInt(anio));
    const data = { mes:parseInt(mes), anio:parseInt(anio),
      pagBN:parseInt(pagBN)||0, pagCol:parseInt(pagCol)||0, nota:notaC,
      cargadoEn:new Date().toISOString() };
    if (existe) {
      await updateDoc(doc(db,"konicaContadores",existe.fireId), data);
      showToast("Contador actualizado ✅");
    } else {
      await addDoc(collection(db,"konicaContadores"), data);
      showToast("Contador guardado ✅");
    }
    setSaving(false); setModalCont(false); setPagBN(""); setPagCol(""); setNotaC("");
  };

  const handleGuardarToner = async () => {
    setSavingT(true);
    await addDoc(collection(db,"konicaToners"), {
      tipo: tonerTipo, fecha: tonerFecha, nota: tonerNota,
      precio: parseFloat(tonerPrecio)||0,
      cargadoEn: new Date().toISOString()
    });
    showToast("Reposición registrada ✅");
    setSavingT(false); setModalToner(false); setTonerNota(""); setTonerPrecio("");
  };

  const handleGuardarCons = async () => {
    if (!consDesc.trim()) { showToast("Ingresá una descripción","error"); return; }
    setSavingCons(true);
    await addDoc(collection(db,"konicaConsumibles"), {
      descripcion: consDesc, fecha: consFecha,
      valor: parseFloat(consValor)||0, nota: consNota,
      cargadoEn: new Date().toISOString()
    });
    showToast("Consumible registrado ✅");
    setSavingCons(false); setModalCons(false);
    setConsDesc(""); setConsValor(""); setConsNota("");
    setConsFecha(new Date().toISOString().split("T")[0]);
  };

  const delCons = async (r) => {
    if (!window.confirm("¿Eliminar este registro?")) return;
    await deleteDoc(doc(db,"konicaConsumibles",r.fireId));
    showToast("Eliminado","error");
  };

  const delContador = async (r) => {
    if (!window.confirm("¿Eliminar este registro?")) return;
    await deleteDoc(doc(db,"konicaContadores",r.fireId));
    showToast("Eliminado","error");
  };
  const delToner = async (r) => {
    if (!window.confirm("¿Eliminar este registro?")) return;
    await deleteDoc(doc(db,"konicaToners",r.fireId));
    showToast("Eliminado","error");
  };

  const delAnio = contadores.filter(r=>r.anio===anioVer);
  const anios   = [...new Set(contadores.map(r=>r.anio))].sort();
  const totalBN  = delAnio.reduce((s,r)=>s+r.pagBN,0);
  const totalCol = delAnio.reduce((s,r)=>s+r.pagCol,0);

  // Calcular diferencias mes a mes
  const conDiff = delAnio.map((r,i)=>{
    const prev = delAnio[i-1];
    return { ...r,
      diffBN:  prev ? r.pagBN  - prev.pagBN  : null,
      diffCol: prev ? r.pagCol - prev.pagCol : null,
    };
  });

  const inp = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0",
    fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };

  return (
    <div>
      {/* Botones */}
      <div style={{ display:"flex", gap:10, justifyContent:"flex-end", marginBottom:20, flexWrap:"wrap" }}>
        <button onClick={()=>setModalCons(true)}
          style={{ background:"#4a5568", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
          🔧 Registrar consumible / service
        </button>
        <button onClick={()=>setModalToner(true)}
          style={{ background:"#1a2340", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
          🖊️ Registrar reposición de tóner
        </button>
        <button onClick={()=>setModalCont(true)}
          style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
          ➕ Cargar contador mensual
        </button>
      </div>

      {/* KPIs */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:14, marginBottom:20 }}>
        {[
          { label:`Páginas B/N ${anioVer}`, valor:totalBN.toLocaleString("es-AR"), color:"#212121" },
          { label:`Páginas Color ${anioVer}`, valor:totalCol.toLocaleString("es-AR"), color:"#e65100" },
          { label:"Total páginas año", valor:(totalBN+totalCol).toLocaleString("es-AR"), color:"#1a2340" },
        ].map((k,i)=>(
          <div key={i} style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"16px 20px" }}>
            <div style={{ fontSize:11, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:6 }}>{k.label}</div>
            <div style={{ fontSize:22, fontWeight:800, color:k.color }}>{k.valor}</div>
          </div>
        ))}
      </div>

      {/* Selector año */}
      <div style={{ display:"flex", gap:8, marginBottom:16 }}>
        {anios.map(a=>(
          <button key={a} onClick={()=>setAnioVer(a)}
            style={{ padding:"7px 16px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none",
              background:anioVer===a?"#e65100":"#fff", color:anioVer===a?"#fff":"#4a5568",
              boxShadow:anioVer===a?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(0,0,0,.06)" }}>
            {a}
          </button>
        ))}
      </div>

      {/* Tabla contadores */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden", marginBottom:24 }}>
        <div style={{ padding:"16px 20px", borderBottom:"1px solid #f0d5c0", fontWeight:700, fontSize:15, color:"#1a2340" }}>
          📊 Registro de contadores — {anioVer}
        </div>
        {loadingC ? (
          <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Cargando...</div>
        ) : conDiff.length===0 ? (
          <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Sin registros para {anioVer}</div>
        ) : (
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
            <thead><tr style={{ background:"#f8f9fa" }}>
              {["Mes","Contador B/N","Páginas B/N mes","Contador Color","Páginas Color mes","Notas",""].map(h=>(
                <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".5px", borderBottom:"1px solid #f0d5c0" }}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {[...conDiff].reverse().map(r=>(
                <tr key={r.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                  <td style={{ padding:"11px 14px", fontWeight:700, color:"#1a2340" }}>{MESES[r.mes]} {r.anio}</td>
                  <td style={{ padding:"11px 14px", color:"#1a2340" }}>{r.pagBN.toLocaleString("es-AR")}</td>
                  <td style={{ padding:"11px 14px" }}>
                    {r.diffBN!==null
                      ? <span style={{ fontWeight:700, color:"#212121" }}>+{r.diffBN.toLocaleString("es-AR")}</span>
                      : <span style={{ color:"#a09080" }}>—</span>}
                  </td>
                  <td style={{ padding:"11px 14px", color:"#1a2340" }}>{r.pagCol.toLocaleString("es-AR")}</td>
                  <td style={{ padding:"11px 14px" }}>
                    {r.diffCol!==null
                      ? <span style={{ fontWeight:700, color:"#e65100" }}>+{r.diffCol.toLocaleString("es-AR")}</span>
                      : <span style={{ color:"#a09080" }}>—</span>}
                  </td>
                  <td style={{ padding:"11px 14px", color:"#a09080", fontStyle:"italic" }}>{r.nota||"—"}</td>
                  <td style={{ padding:"11px 10px" }}>
                    <button onClick={()=>delContador(r)}
                      style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Historial tóners */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
        <div style={{ padding:"16px 20px", borderBottom:"1px solid #f0d5c0", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>🖊️ Historial de reposición de tóner</div>
          <div style={{ display:"flex", gap:8 }}>
            {TONERES.map(t=>{
              const cant = toners.filter(r=>r.tipo===t.id).length;
              return (
                <span key={t.id} style={{ background:t.bg, color:t.color, border:`1.5px solid ${t.color}40`,
                  padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:700 }}>
                  {t.label}: {cant}
                </span>
              );
            })}
          </div>
        </div>
        {loadingT ? (
          <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Cargando...</div>
        ) : toners.length===0 ? (
          <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Sin reposiciones registradas</div>
        ) : (
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
            <thead><tr style={{ background:"#f8f9fa" }}>
              {["Fecha","Tóner","Precio","Notas",""].map(h=>(
                <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".5px", borderBottom:"1px solid #f0d5c0" }}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {toners.map(r=>{
                const t = TONERES.find(x=>x.id===r.tipo)||TONERES[3];
                return (
                  <tr key={r.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                    <td style={{ padding:"11px 14px", color:"#4a5568" }}>{fmtFecha(r.fecha)}</td>
                    <td style={{ padding:"11px 14px" }}>
                      <span style={{ background:t.bg, color:t.color, border:`1.5px solid ${t.color}50`,
                        padding:"3px 12px", borderRadius:20, fontSize:12, fontWeight:700 }}>
                        ⬛ {t.label}
                      </span>
                    </td>
                    <td style={{ padding:"11px 14px", fontWeight:700, color:"#1a2340" }}>
                      {r.precio ? `$${parseFloat(r.precio).toLocaleString("es-AR")}` : "—"}
                    </td>
                    <td style={{ padding:"11px 14px", color:"#a09080", fontStyle:"italic" }}>{r.nota||"—"}</td>
                    <td style={{ padding:"11px 10px" }}>
                      <button onClick={()=>delToner(r)}
                        style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Consumibles / Services */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden", marginTop:24 }}>
        <div style={{ padding:"16px 20px", borderBottom:"1px solid #f0d5c0", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>🔧 Consumibles y servicios</div>
          {consumibles.length>0 && (
            <span style={{ fontSize:13, color:"#4a5568" }}>
              Total invertido: <strong style={{color:"#e65100"}}>${consumibles.reduce((s,r)=>s+parseFloat(r.valor||0),0).toLocaleString("es-AR")}</strong>
            </span>
          )}
        </div>
        {loadingCons ? (
          <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Cargando...</div>
        ) : consumibles.length===0 ? (
          <div style={{ padding:32, textAlign:"center", color:"#a09080" }}>Sin consumibles registrados</div>
        ) : (
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
            <thead><tr style={{ background:"#f8f9fa" }}>
              {["Fecha","Descripción","Valor","Notas",""].map(h=>(
                <th key={h} style={{ padding:"10px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".5px", borderBottom:"1px solid #f0d5c0" }}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {consumibles.map(r=>(
                <tr key={r.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                  <td style={{ padding:"11px 14px", color:"#4a5568" }}>{fmtFecha(r.fecha)}</td>
                  <td style={{ padding:"11px 14px", fontWeight:600, color:"#1a2340" }}>{r.descripcion}</td>
                  <td style={{ padding:"11px 14px", fontWeight:700, color:"#e65100" }}>
                    {r.valor ? `$${parseFloat(r.valor).toLocaleString("es-AR")}` : "—"}
                  </td>
                  <td style={{ padding:"11px 14px", color:"#a09080", fontStyle:"italic" }}>{r.nota||"—"}</td>
                  <td style={{ padding:"11px 10px" }}>
                    <button onClick={()=>delCons(r)}
                      style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal contador */}
      {modalCont && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={()=>setModalCont(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:440, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:20 }}>📊 Cargar contador mensual</div>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Mes</label>
                  <select value={mes} onChange={e=>setMes(parseInt(e.target.value))} style={{ ...inp, cursor:"pointer" }}>
                    {MESES.map((m,i)=><option key={i} value={i}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Año</label>
                  <input type="number" value={anio} onChange={e=>setAnio(parseInt(e.target.value))} style={inp}/>
                </div>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#212121", marginBottom:6 }}>Contador Blanco y Negro</label>
                <input type="number" value={pagBN} onChange={e=>setPagBN(e.target.value)} placeholder="Ej: 125430" style={inp}/>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#e65100", marginBottom:6 }}>Contador Color</label>
                <input type="number" value={pagCol} onChange={e=>setPagCol(e.target.value)} placeholder="Ej: 48320" style={inp}/>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nota (opcional)</label>
                <input value={notaC} onChange={e=>setNotaC(e.target.value)} placeholder="Ej: después de mantenimiento" style={inp}/>
              </div>
            </div>
            <div style={{ display:"flex", gap:10, marginTop:22 }}>
              <button onClick={()=>setModalCont(false)} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleGuardarContador} disabled={saving}
                style={{ flex:2, padding:"11px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
                {saving?"Guardando...":"💾 Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal tóner */}
      {modalToner && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={()=>setModalToner(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:420, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:20 }}>🖊️ Registrar reposición de tóner</div>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:8 }}>Tóner repuesto</label>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                  {TONERES.map(t=>(
                    <div key={t.id} onClick={()=>setTonerTipo(t.id)}
                      style={{ padding:"12px", borderRadius:10, cursor:"pointer", textAlign:"center",
                        border:`2px solid ${tonerTipo===t.id?t.color:"#f0d5c0"}`,
                        background:tonerTipo===t.id?t.bg:"#fff" }}>
                      <div style={{ fontWeight:700, fontSize:13, color:t.color }}>{t.label}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Fecha</label>
                <input type="date" value={tonerFecha} onChange={e=>setTonerFecha(e.target.value)} style={inp}/>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio pagado ($)</label>
                <input type="number" value={tonerPrecio} onChange={e=>setTonerPrecio(e.target.value)} placeholder="Ej: 45000" style={inp}/>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nota (opcional)</label>
                <input value={tonerNota} onChange={e=>setTonerNota(e.target.value)} placeholder="Ej: tóner original Konica" style={inp}/>
              </div>
            </div>
            <div style={{ display:"flex", gap:10, marginTop:22 }}>
              <button onClick={()=>setModalToner(false)} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleGuardarToner} disabled={savingT}
                style={{ flex:2, padding:"11px", background:"#1a2340", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
                {savingT?"Guardando...":"✅ Registrar"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal consumibles */}
      {modalCons && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={()=>setModalCons(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:440, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:20 }}>🔧 Registrar consumible / service</div>
            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Descripción *</label>
                <input value={consDesc} onChange={e=>setConsDesc(e.target.value)}
                  placeholder="Ej: Cambio de cuchilla, Service trimestral, Kit de fusión..."
                  style={inp} autoFocus/>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Fecha</label>
                  <input type="date" value={consFecha} onChange={e=>setConsFecha(e.target.value)} style={inp}/>
                </div>
                <div>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Valor ($)</label>
                  <input type="number" value={consValor} onChange={e=>setConsValor(e.target.value)} placeholder="0" style={inp}/>
                </div>
              </div>
              <div>
                <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Notas adicionales (opcional)</label>
                <input value={consNota} onChange={e=>setConsNota(e.target.value)} placeholder="Proveedor, garantía, observaciones..." style={inp}/>
              </div>
            </div>
            <div style={{ display:"flex", gap:10, marginTop:22 }}>
              <button onClick={()=>setModalCons(false)} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleGuardarCons} disabled={savingCons}
                style={{ flex:2, padding:"11px", background:"#4a5568", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
                {savingCons?"Guardando...":"🔧 Registrar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Componente: Configuración ─────────────────────────────────────────────
// ── Guardar parte de la configuración general ────────────────────────────
async function guardarAppCfg(parcial) {
  await setDoc(doc(db, "config", "app"), { ...parcial, actualizadoEn: new Date().toISOString() }, { merge: true });
}
const cfgCard = { background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"26px 30px" };
const cfgInp  = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box", color:"#1a2340" };
const cfgLbl  = { display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 };
const cfgTitulo = (t, sub) => (
  <div style={{ marginBottom:18 }}>
    <div style={{ fontSize:20, fontWeight:700, color:"#1a2340" }}>{t}</div>
    {sub && <div style={{ fontSize:13, color:"#a09080", marginTop:4 }}>{sub}</div>}
  </div>
);
const CfgGuardar = ({ dirty, saving, onClick, texto="💾 Guardar" }) => (
  <div style={{ display:"flex", justifyContent:"flex-end", alignItems:"center", gap:12, marginTop:22 }}>
    {dirty && <span style={{ fontSize:12, color:"#e65100", fontWeight:600 }}>Hay cambios sin guardar</span>}
    <button onClick={onClick} disabled={saving||!dirty}
      style={{ background:dirty?"#e65100":"#f0d5c0", color:"#fff", border:"none", padding:"11px 28px", borderRadius:8, fontSize:15, fontWeight:600, cursor:dirty?"pointer":"default" }}>
      {saving ? "Guardando..." : texto}
    </button>
  </div>
);

// ── Configuración: Mensajes y documentos ─────────────────────────────────
function MensajesConfig({ showToast }) {
  const campos = ["msgListoSaldo","msgListoPago","prefijoWhatsapp","validezPresupuesto","condicionesPresupuesto","piePresupuesto","firmaOrden","pieOrden"];
  const [f, setF]         = useState(() => Object.fromEntries(campos.map(k => [k, APP_CFG[k]])));
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [foco, setFoco]   = useState("msgListoSaldo");
  const set = (k, v) => { setF(x => ({ ...x, [k]:v })); setDirty(true); };

  const ejemplo = { cliente:"David Silva", nombre:"Tarjetas personales", nroOT:12, precio:"9000", seña: foco==="msgListoPago" ? "9000" : "4500" };
  const preview = (() => {
    const backup = { msgListoSaldo:APP_CFG.msgListoSaldo, msgListoPago:APP_CFG.msgListoPago };
    APP_CFG.msgListoSaldo = f.msgListoSaldo; APP_CFG.msgListoPago = f.msgListoPago;
    const t = armarMensajeListo(ejemplo);
    Object.assign(APP_CFG, backup);
    return t;
  })();

  const insertar = (marcador) => {
    if (foco!=="msgListoSaldo" && foco!=="msgListoPago") return;
    const el = document.getElementById("cfg-"+foco);
    const v = f[foco] || "";
    const pos = el ? el.selectionStart : v.length;
    set(foco, v.slice(0,pos) + marcador + v.slice(pos));
    setTimeout(() => { if (el) { el.focus(); el.selectionStart = el.selectionEnd = pos + marcador.length; } }, 0);
  };

  const guardar = async () => {
    setSaving(true);
    try { await guardarAppCfg({ ...f, validezPresupuesto: parseInt(f.validezPresupuesto)||7 }); setDirty(false); showToast("Mensajes y documentos guardados ✅"); }
    catch(e) { console.error(e); showToast("Error al guardar","error"); }
    setSaving(false);
  };
  const restaurar = (ks) => { ks.forEach(k => set(k, APP_CFG_DEFAULT[k])); };

  const marcadores = [["{nombre}","Primer nombre"],["{cliente}","Nombre completo"],["{ot}","N° de OT"],["{pedido}","Nombre del pedido"],["{total}","Total"],["{saldo}","Saldo"],["{seña}","Seña"]];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:20 }}>
      <div style={cfgCard}>
        {cfgTitulo("💬 Mensaje de pedido listo", "Es el texto que se arma al marcar un pedido como Listo. Los marcadores entre llaves se reemplazan solos. Usá *asteriscos* para negrita en WhatsApp.")}
        <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:14 }}>
          {marcadores.map(([m,d]) => (
            <button key={m} onClick={()=>insertar(m)} title={`Insertar: ${d}`}
              style={{ background:"#fff8f5", border:"1.5px solid #f0d5c0", color:"#e65100", padding:"4px 10px", borderRadius:20, fontSize:12, fontWeight:700, cursor:"pointer", fontFamily:"monospace" }}>
              {m} <span style={{ fontFamily:"'DM Sans',sans-serif", fontWeight:400, color:"#a09080" }}>{d}</span>
            </button>
          ))}
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(280px, 1fr))", gap:16 }}>
          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            <div>
              <label style={cfgLbl}>Cuando queda saldo por pagar</label>
              <textarea id="cfg-msgListoSaldo" rows={5} value={f.msgListoSaldo} onFocus={()=>setFoco("msgListoSaldo")} onChange={e=>set("msgListoSaldo",e.target.value)}
                style={{ ...cfgInp, resize:"vertical", fontSize:13, borderColor:foco==="msgListoSaldo"?"#e65100":"#f0d5c0" }}/>
            </div>
            <div>
              <label style={cfgLbl}>Cuando está todo pago</label>
              <textarea id="cfg-msgListoPago" rows={5} value={f.msgListoPago} onFocus={()=>setFoco("msgListoPago")} onChange={e=>set("msgListoPago",e.target.value)}
                style={{ ...cfgInp, resize:"vertical", fontSize:13, borderColor:foco==="msgListoPago"?"#e65100":"#f0d5c0" }}/>
            </div>
            <div style={{ display:"flex", gap:12, alignItems:"flex-end", flexWrap:"wrap" }}>
              <div style={{ width:160 }}>
                <label style={cfgLbl}>Código de país WhatsApp</label>
                <input value={f.prefijoWhatsapp} onChange={e=>set("prefijoWhatsapp",e.target.value)} placeholder="549" style={cfgInp}/>
              </div>
              <div style={{ fontSize:11, color:"#a09080", flex:1, minWidth:160, paddingBottom:4 }}>Para celulares de Argentina es <b>549</b>. Si el teléfono ya empieza con 54, se respeta.</div>
            </div>
            <button onClick={()=>restaurar(["msgListoSaldo","msgListoPago","prefijoWhatsapp"])}
              style={{ alignSelf:"flex-start", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", padding:"6px 12px", borderRadius:8, fontSize:12, cursor:"pointer" }}>↺ Volver a los mensajes originales</button>
          </div>
          <div>
            <label style={cfgLbl}>Vista previa ({foco==="msgListoPago" ? "todo pago" : "con saldo"})</label>
            <div style={{ background:"#e7ffdb", borderRadius:"10px 10px 10px 2px", padding:"12px 14px", fontSize:13, color:"#1a2340", whiteSpace:"pre-wrap", lineHeight:1.5, boxShadow:"0 1px 2px rgba(0,0,0,.1)" }}>
              {preview.split(/(\*[^*]+\*)/g).map((t,i) => t.startsWith("*")&&t.endsWith("*") ? <b key={i}>{t.slice(1,-1)}</b> : t)}
            </div>
            <div style={{ fontSize:11, color:"#a09080", marginTop:6 }}>Ejemplo con datos de prueba. Si un pedido no tiene precio cargado, los renglones con {"{total}"}, {"{saldo}"} o {"{seña}"} se omiten.</div>
          </div>
        </div>
      </div>

      <div style={cfgCard}>
        {cfgTitulo("📄 Presupuestos impresos")}
        <div style={{ display:"grid", gridTemplateColumns:"140px 1fr", gap:14, marginBottom:14 }}>
          <div>
            <label style={cfgLbl}>Validez (días)</label>
            <input type="number" min="1" value={f.validezPresupuesto} onChange={e=>set("validezPresupuesto",e.target.value)} style={cfgInp}/>
          </div>
          <div>
            <label style={cfgLbl}>Aclaración junto a la validez</label>
            <input value={f.condicionesPresupuesto} onChange={e=>set("condicionesPresupuesto",e.target.value)} placeholder="Sujeto a cambios de precio" style={cfgInp}/>
          </div>
        </div>
        <label style={cfgLbl}>Texto al pie del presupuesto (opcional)</label>
        <textarea rows={3} value={f.piePresupuesto} onChange={e=>set("piePresupuesto",e.target.value)}
          placeholder="Ej: Se requiere 50% de seña para comenzar el trabajo. Precios con IVA incluido."
          style={{ ...cfgInp, resize:"vertical", fontSize:13 }}/>
      </div>

      <div style={cfgCard}>
        {cfgTitulo("🧾 Orden de trabajo impresa")}
        <div style={{ marginBottom:14, maxWidth:320 }}>
          <label style={cfgLbl}>Texto bajo la línea de firma</label>
          <input value={f.firmaOrden} onChange={e=>set("firmaOrden",e.target.value)} placeholder="Firma operario" style={cfgInp}/>
        </div>
        <label style={cfgLbl}>Texto al pie de la orden (opcional)</label>
        <textarea rows={3} value={f.pieOrden} onChange={e=>set("pieOrden",e.target.value)}
          placeholder="Ej: Los trabajos no retirados dentro de los 30 días no podrán ser reclamados."
          style={{ ...cfgInp, resize:"vertical", fontSize:13 }}/>
        <CfgGuardar dirty={dirty} saving={saving} onClick={guardar} texto="💾 Guardar mensajes y documentos"/>
      </div>
    </div>
  );
}

// ── Editor de lista genérico (usado por métodos de pago y accesos) ───────
function ListaEditable({ items, setItems, columnas, onDirty }) {
  const upd = (i, k, v) => { setItems(l => l.map((x,j) => j===i ? { ...x, [k]:v } : x)); onDirty(); };
  const mover = (i, d) => { const j=i+d; if (j<0||j>=items.length) return; setItems(l => { const a=[...l]; [a[i],a[j]]=[a[j],a[i]]; return a; }); onDirty(); };
  const quitar = (i) => { setItems(l => l.filter((_,j) => j!==i)); onDirty(); };
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
      {items.map((x, i) => (
        <div key={i} style={{ display:"flex", alignItems:"center", gap:8, padding:"8px 10px", borderRadius:10, background:"#fffaf7", border:"1.5px solid #f5e8e0", flexWrap:"wrap" }}>
          <div style={{ display:"flex", flexDirection:"column" }}>
            <button onClick={()=>mover(i,-1)} disabled={i===0} style={{ background:"transparent", border:"none", cursor:"pointer", color:i===0?"#ddd":"#a09080", fontSize:11, lineHeight:1, padding:"1px 4px" }}>▲</button>
            <button onClick={()=>mover(i,1)} disabled={i===items.length-1} style={{ background:"transparent", border:"none", cursor:"pointer", color:i===items.length-1?"#ddd":"#a09080", fontSize:11, lineHeight:1, padding:"1px 4px" }}>▼</button>
          </div>
          {columnas.map(col => (
            <input key={col.k} value={x[col.k]||""} onChange={e=>upd(i,col.k,e.target.value)} placeholder={col.ph} maxLength={col.max} title={col.titulo}
              style={{ ...cfgInp, ...(col.estilo||{}), background:"#fff" }}/>
          ))}
          <button onClick={()=>quitar(i)} title="Eliminar"
            style={{ background:"#ffebee", border:"none", color:"#c62828", width:32, height:32, borderRadius:8, cursor:"pointer", fontSize:14, flexShrink:0 }}>🗑</button>
        </div>
      ))}
    </div>
  );
}

// ── Configuración: Métodos de pago ───────────────────────────────────────
function MetodosPagoConfig({ showToast }) {
  const [items, setItems] = useState(() => JSON.parse(JSON.stringify(APP_CFG.metodosPago||[])));
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const fila = (m) => (
    <div style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 14px", borderRadius:10, background:"#f8f9fa", border:"1.5px dashed #e0e0e0" }}>
      <span style={{ fontSize:18 }}>{m.icono}</span>
      <span style={{ fontWeight:700, color:"#4a5568", flex:1 }}>{m.nombre}</span>
      <span style={{ fontSize:11, color:"#a09080" }}>🔒 fijo</span>
    </div>
  );
  const guardar = async () => {
    const limpia = items.map(x => ({ nombre:(x.nombre||"").trim(), icono:(x.icono||"").trim()||"💳", corto:(x.corto||"").trim() })).filter(x => x.nombre);
    const nombres = [...limpia.map(x=>x.nombre.toLowerCase()), "efectivo", "cuenta corriente"];
    if (nombres.length !== new Set(nombres).size) { showToast("Hay métodos repetidos (o con el nombre de uno fijo)","error"); return; }
    setSaving(true);
    try { await guardarAppCfg({ metodosPago: limpia }); setItems(limpia); setDirty(false); showToast("Métodos de pago guardados ✅"); }
    catch(e) { console.error(e); showToast("Error al guardar","error"); }
    setSaving(false);
  };
  return (
    <div style={cfgCard}>
      {cfgTitulo("💳 Métodos de pago", "Aparecen al cobrar una venta, entregar un pedido y armar un presupuesto. Finanzas los suma por separado.")}
      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
        {fila(METODO_EFECTIVO)}
        <ListaEditable items={items} setItems={setItems} onDirty={()=>setDirty(true)} columnas={[
          { k:"icono",  ph:"💳", max:4, titulo:"Ícono", estilo:{ width:52, textAlign:"center", fontSize:18, padding:"6px 4px" } },
          { k:"nombre", ph:"Nombre (ej: Mercado Pago)", titulo:"Nombre completo", estilo:{ flex:2, minWidth:150, fontWeight:600 } },
          { k:"corto",  ph:"Texto del botón (opcional)", titulo:"Nombre corto para los botones", estilo:{ flex:1, minWidth:120 } },
        ]}/>
        {fila(METODO_CTACTE)}
      </div>
      <button onClick={()=>{ setItems(l => [...l, { nombre:"", icono:"💳", corto:"" }]); setDirty(true); }}
        style={{ marginTop:12, background:"#1a2340", color:"#fff", border:"none", padding:"9px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>+ Agregar método</button>
      <div style={{ fontSize:12, color:"#a09080", marginTop:14, lineHeight:1.6 }}>
        🔒 <b>Efectivo</b> y <b>Cuenta Corriente</b> quedan fijos: el sistema los usa para la caja y para el saldo de los clientes.<br/>
        Si renombrás o borrás un método, las ventas viejas conservan el nombre con el que se cobraron y Finanzas las sigue mostrando.
      </div>
      <CfgGuardar dirty={dirty} saving={saving} onClick={guardar} texto="💾 Guardar métodos de pago"/>
    </div>
  );
}

// ── Configuración: Accesos directos del menú ─────────────────────────────
function AccesosConfig({ showToast }) {
  const [items, setItems] = useState(() => JSON.parse(JSON.stringify(APP_CFG.accesos||[])));
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const guardar = async () => {
    const limpia = items.map(x => {
      let url = (x.url||"").trim();
      if (url && !/^https?:\/\//i.test(url)) url = "https://" + url;
      return { nombre:(x.nombre||"").trim(), icono:(x.icono||"").trim()||"🔗", url };
    }).filter(x => x.url);
    setSaving(true);
    try { await guardarAppCfg({ accesos: limpia }); setItems(limpia); setDirty(false); showToast("Accesos del menú guardados ✅"); }
    catch(e) { console.error(e); showToast("Error al guardar","error"); }
    setSaving(false);
  };
  return (
    <div style={cfgCard}>
      {cfgTitulo("🔗 Accesos directos del menú", "Aparecen en el menú lateral, después de Presupuestos, y se abren en una pestaña nueva.")}
      {items.length===0 && <div style={{ fontSize:13, color:"#c0bdb9", fontStyle:"italic", marginBottom:10 }}>No hay accesos. Agregá uno con el botón de abajo.</div>}
      <ListaEditable items={items} setItems={setItems} onDirty={()=>setDirty(true)} columnas={[
        { k:"icono",  ph:"🔗", max:4, titulo:"Ícono", estilo:{ width:52, textAlign:"center", fontSize:18, padding:"6px 4px" } },
        { k:"nombre", ph:"Nombre (ej: Drive)", titulo:"Nombre en el menú", estilo:{ flex:1, minWidth:120, fontWeight:600 } },
        { k:"url",    ph:"Dirección (ej: drive.google.com/...)", titulo:"Dirección web", estilo:{ flex:2, minWidth:200, fontSize:13 } },
      ]}/>
      <div style={{ display:"flex", gap:8, marginTop:12, flexWrap:"wrap" }}>
        <button onClick={()=>{ setItems(l => [...l, { nombre:"", icono:"🔗", url:"" }]); setDirty(true); }}
          style={{ background:"#1a2340", color:"#fff", border:"none", padding:"9px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>+ Agregar acceso</button>
        <button onClick={()=>{ setItems(JSON.parse(JSON.stringify(APP_CFG_DEFAULT.accesos))); setDirty(true); }}
          style={{ background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", padding:"8px 14px", borderRadius:8, fontSize:12, cursor:"pointer" }}>↺ Restaurar Cotizador y PhotoPrint</button>
      </div>
      <CfgGuardar dirty={dirty} saving={saving} onClick={guardar} texto="💾 Guardar accesos"/>
    </div>
  );
}

// ── Configuración con solapas ────────────────────────────────────────────
function ConfiguracionView({ empresa, setEmpresa, empresaSaved, setEmpresaSaved, pedidos, showToast, catsVersion, cfgVersion }) {
  const [tab, setTab] = useState("local");
  const tabs = [
    ["local",      "🏪 Local"],
    ["categorias", "🏷️ Categorías"],
    ["mensajes",   "💬 Mensajes y documentos"],
    ["pagos",      "💳 Ventas"],
    ["menu",       "🔗 Menú"],
  ];
  return (
    <div>
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {tabs.map(([id, l]) => (
          <button key={id} onClick={()=>setTab(id)}
            style={{ padding:"9px 18px", borderRadius:20, fontSize:13, fontWeight:700, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
              background:tab===id?"#e65100":"#fff", color:tab===id?"#fff":"#4a5568",
              boxShadow:tab===id?"0 3px 12px rgba(230,81,0,.25)":"0 2px 8px rgba(230,81,0,.07)" }}>{l}</button>
        ))}
      </div>
      {tab==="local"      && <ConfigView empresa={empresa} setEmpresa={setEmpresa} empresaSaved={empresaSaved} setEmpresaSaved={setEmpresaSaved}/>}
      {tab==="categorias" && <CategoriasEditor key={catsVersion} pedidos={pedidos} showToast={showToast}/>}
      {tab==="mensajes"   && <MensajesConfig  key={cfgVersion} showToast={showToast}/>}
      {tab==="pagos"      && <MetodosPagoConfig key={cfgVersion} showToast={showToast}/>}
      {tab==="menu"       && <AccesosConfig   key={cfgVersion} showToast={showToast}/>}
    </div>
  );
}

// ── Componente: Editor de categorías ─────────────────────────────────────
function CategoriasEditor({ pedidos, showToast }) {
  const inicial = () => CATEGORIAS.map(n => ({ nombre:n, nombreOriginal:n, icono:CATEGORIA_ICON[n], ...CATEGORIA_COLOR[n] }));
  const [lista, setLista]       = useState(inicial);
  const [nuevoNombre, setNuevoNombre] = useState("");
  const [nuevoIcono, setNuevoIcono]   = useState("📦");
  const [paletaAbierta, setPaletaAbierta] = useState(null);
  const [saving, setSaving]     = useState(false);
  const [dirty, setDirty]       = useState(false);

  const cuentaPedidos = (nombre) => pedidos.filter(p => p.categoria === nombre).length;
  const upd = (i, campos) => { setLista(l => l.map((x,j) => j===i ? { ...x, ...campos } : x)); setDirty(true); };
  const mover = (i, d) => {
    const j = i + d; if (j < 0 || j >= lista.length) return;
    setLista(l => { const a=[...l]; [a[i],a[j]]=[a[j],a[i]]; return a; }); setDirty(true);
  };
  const quitar = (i) => {
    const x = lista[i]; const n = cuentaPedidos(x.nombreOriginal||x.nombre);
    if (!window.confirm(n
      ? `"${x.nombre}" tiene ${n} pedido${n!==1?"s":""}. Los pedidos no se borran: siguen apareciendo con su categoría, pero ya no vas a poder elegirla para pedidos nuevos. ¿Continuar?`
      : `¿Eliminar la categoría "${x.nombre}"?`)) return;
    setLista(l => l.filter((_,j) => j!==i)); setDirty(true);
  };
  const agregar = () => {
    const n = nuevoNombre.trim();
    if (!n) return;
    if (lista.some(x => x.nombre.toLowerCase() === n.toLowerCase())) { showToast("Esa categoría ya existe","error"); return; }
    const col = PALETA_CATEGORIAS[lista.length % PALETA_CATEGORIAS.length];
    setLista(l => [...l, { nombre:n, nombreOriginal:null, icono:nuevoIcono||"📦", ...col }]);
    setNuevoNombre(""); setNuevoIcono("📦"); setDirty(true);
  };

  const guardar = async () => {
    const limpia = lista.map(x => ({ ...x, nombre:x.nombre.trim() })).filter(x => x.nombre);
    const nombres = limpia.map(x => x.nombre.toLowerCase());
    if (nombres.length !== new Set(nombres).size) { showToast("Hay dos categorías con el mismo nombre","error"); return; }
    if (!limpia.length) { showToast("Tiene que haber al menos una categoría","error"); return; }

    // Renombradas: ofrecer actualizar los pedidos que ya la usan
    const renombradas = limpia.filter(x => x.nombreOriginal && x.nombreOriginal !== x.nombre && cuentaPedidos(x.nombreOriginal) > 0);
    let actualizarPedidos = false;
    if (renombradas.length) {
      const detalle = renombradas.map(x => `• ${x.nombreOriginal} → ${x.nombre} (${cuentaPedidos(x.nombreOriginal)} pedidos)`).join("\n");
      actualizarPedidos = window.confirm(`Renombraste categorías que ya tienen pedidos:\n${detalle}\n\n¿Actualizo también esos pedidos al nombre nuevo?`);
    }

    setSaving(true);
    try {
      await setDoc(doc(db, "config", "categorias"), {
        lista: limpia.map(({ nombre, icono, bg, text, accent }) => ({ nombre, icono, bg, text, accent })),
        actualizadoEn: new Date().toISOString(),
      });
      if (actualizarPedidos) {
        for (const r of renombradas) {
          for (const p of pedidos.filter(p => p.categoria === r.nombreOriginal)) {
            await updateDoc(doc(db, "pedidos", p.fireId), { categoria: r.nombre });
          }
        }
      }
      setDirty(false);
      showToast("Categorías guardadas ✅");
    } catch(e) {
      console.error(e);
      showToast("Error al guardar las categorías","error");
    }
    setSaving(false);
  };

  const restaurar = () => {
    if (!window.confirm("¿Volver a las categorías originales? (no afecta los pedidos)")) return;
    setLista(CATEGORIAS_DEFAULT.map(x => ({ ...x, nombreOriginal:x.nombre }))); setDirty(true);
  };

  const inp = { padding:"8px 10px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };

  return (
    <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"28px 32px" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12, flexWrap:"wrap", marginBottom:6 }}>
        <div>
          <div style={{ fontSize:20, fontWeight:700, color:"#1a2340" }}>🏷️ Categorías de pedidos</div>
          <div style={{ fontSize:13, color:"#a09080", marginTop:4 }}>Se usan en Pedidos, Calendario, Presupuestos y en las órdenes de trabajo. El orden de esta lista es el orden en que aparecen.</div>
        </div>
        <button onClick={restaurar} style={{ background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", padding:"7px 14px", borderRadius:8, fontSize:12, fontWeight:600, cursor:"pointer", whiteSpace:"nowrap" }}>↺ Restaurar originales</button>
      </div>

      <div style={{ display:"flex", flexDirection:"column", gap:8, margin:"18px 0" }}>
        {lista.map((x, i) => {
          const n = x.nombreOriginal ? cuentaPedidos(x.nombreOriginal) : 0;
          return (
            <div key={i} style={{ display:"flex", alignItems:"center", gap:8, padding:"8px 10px", borderRadius:10, background:x.bg, border:`1.5px solid ${x.accent}40`, flexWrap:"wrap", position:"relative" }}>
              <div style={{ display:"flex", flexDirection:"column" }}>
                <button onClick={()=>mover(i,-1)} disabled={i===0} style={{ background:"transparent", border:"none", cursor:i===0?"default":"pointer", color:i===0?"#ccc":x.text, fontSize:11, lineHeight:1, padding:"1px 4px" }}>▲</button>
                <button onClick={()=>mover(i,1)} disabled={i===lista.length-1} style={{ background:"transparent", border:"none", cursor:i===lista.length-1?"default":"pointer", color:i===lista.length-1?"#ccc":x.text, fontSize:11, lineHeight:1, padding:"1px 4px" }}>▼</button>
              </div>
              <input value={x.icono} onChange={e=>upd(i,{ icono:e.target.value })} maxLength={4} title="Ícono (podés pegar un emoji)"
                style={{ ...inp, width:46, textAlign:"center", fontSize:18, padding:"5px 4px", background:"#fff" }}/>
              <input value={x.nombre} onChange={e=>upd(i,{ nombre:e.target.value })}
                style={{ ...inp, flex:1, minWidth:140, fontWeight:700, color:x.text, background:"#fff" }}/>
              {n > 0 && <span style={{ fontSize:11, color:x.text, opacity:.8, whiteSpace:"nowrap" }}>{n} pedido{n!==1?"s":""}</span>}
              <button onClick={()=>setPaletaAbierta(paletaAbierta===i?null:i)} title="Cambiar color"
                style={{ width:30, height:30, borderRadius:8, border:`2px solid ${x.text}`, background:x.accent, cursor:"pointer", flexShrink:0 }}/>
              <button onClick={()=>quitar(i)} title="Eliminar"
                style={{ background:"#fff", border:"none", color:"#c62828", width:30, height:30, borderRadius:8, cursor:"pointer", fontSize:14, flexShrink:0 }}>🗑</button>
              {paletaAbierta===i && (
                <div style={{ width:"100%", display:"flex", gap:6, flexWrap:"wrap", paddingTop:6 }}>
                  {PALETA_CATEGORIAS.map((col, k) => (
                    <button key={k} onClick={()=>{ upd(i, col); setPaletaAbierta(null); }}
                      style={{ width:28, height:28, borderRadius:7, cursor:"pointer", background:col.bg,
                        border:`3px solid ${x.accent===col.accent && x.bg===col.bg ? col.text : col.accent}` }}/>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ display:"flex", gap:8, padding:"12px", border:"1.5px dashed #f0d5c0", borderRadius:10, marginBottom:20 }}>
        <input value={nuevoIcono} onChange={e=>setNuevoIcono(e.target.value)} maxLength={4} style={{ ...inp, width:52, textAlign:"center", fontSize:18 }}/>
        <input value={nuevoNombre} onChange={e=>setNuevoNombre(e.target.value)} onKeyDown={e=>{ if(e.key==="Enter") agregar(); }}
          placeholder="Nueva categoría (ej: Banderas)" style={{ ...inp, flex:1 }}/>
        <button onClick={agregar} style={{ background:"#1a2340", color:"#fff", border:"none", padding:"8px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>+ Agregar</button>
      </div>

      <div style={{ display:"flex", justifyContent:"flex-end", alignItems:"center", gap:12 }}>
        {dirty && <span style={{ fontSize:12, color:"#e65100", fontWeight:600 }}>Hay cambios sin guardar</span>}
        <button onClick={guardar} disabled={saving||!dirty}
          style={{ background:dirty?"#e65100":"#f0d5c0", color:"#fff", border:"none", padding:"11px 28px", borderRadius:8, fontSize:15, fontWeight:600, cursor:dirty?"pointer":"default" }}>
          {saving ? "Guardando..." : "💾 Guardar categorías"}
        </button>
      </div>
    </div>
  );
}

function ConfigView({ empresa, setEmpresa, empresaSaved, setEmpresaSaved }) {
  const [form, setForm]       = useState({ ...empresa });
  const [preview, setPreview] = useState(empresa.logo || "");

  const handleLogo = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => { setPreview(ev.target.result); setForm(f => ({ ...f, logo: ev.target.result })); };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    await setDoc(doc(db, "config", "empresa"), form);
    setEmpresa(form);
    setEmpresaSaved(true);
    setTimeout(() => setEmpresaSaved(false), 2500);
  };

  const field = (label, key, placeholder) => (
    <div>
      <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>{label}</label>
      <input value={form[key]} onChange={e=>setForm(f=>({...f,[key]:e.target.value}))} placeholder={placeholder}
        style={{ width:"100%", padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", color:"#1a2340", outline:"none", boxSizing:"border-box" }}/>
    </div>
  );

  return (
    <div>
      <div style={{ marginBottom:26 }}>
        <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:26, fontWeight:700, color:"#1a2340", marginBottom:4 }}>⚙️ Configuración del Local</h2>
        <p style={{ fontSize:14, color:"#a09080" }}>Estos datos aparecerán en todas las órdenes de trabajo que imprimas.</p>
      </div>

      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"32px 36px" }}>
        {/* Logo */}
        <div style={{ marginBottom:28 }}>
          <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:10 }}>Logo del local</label>
          <div style={{ display:"flex", alignItems:"center", gap:20 }}>
            <div style={{ width:90, height:90, borderRadius:14, border:"2px dashed #c5cce0", background:"#fffaf7", display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden", flexShrink:0 }}>
              {preview ? <img src={preview} alt="Logo" style={{ width:"100%", height:"100%", objectFit:"contain" }}/> : <span style={{ fontSize:32, opacity:.4 }}>🖼️</span>}
            </div>
            <div>
              <label style={{ display:"inline-block", background:"#e65100", color:"#fff", padding:"9px 18px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>
                📁 Subir imagen
                <input type="file" accept="image/*" onChange={handleLogo} style={{ display:"none" }}/>
              </label>
              {preview && (
                <button onClick={() => { setPreview(""); setForm(f=>({...f,logo:""})); }}
                  style={{ marginLeft:10, background:"transparent", border:"1.5px solid #ef5350", color:"#ef5350", padding:"8px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>
                  ✕ Quitar
                </button>
              )}
              <p style={{ fontSize:12, color:"#a09080", marginTop:8 }}>PNG, JPG o SVG. Recomendado: fondo transparente.</p>
            </div>
          </div>
        </div>

        <div style={{ borderTop:"1px solid #edf0f7", paddingTop:24, display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
          <div style={{ gridColumn:"1 / -1" }}>{field("Nombre del local / empresa", "nombre", "Ej: Mafalda Gráfica")}</div>
          {field("Titular / Responsable", "titular", "Nombre y apellido")}
          {field("CUIT", "cuit", "XX-XXXXXXXX-X")}
          {field("Dirección", "direccion", "Calle, número, ciudad")}
          {field("Teléfono / WhatsApp", "telefono", "11-xxxx-xxxx")}
        </div>

        {/* Preview */}
        <div style={{ marginTop:28, background:"#fff8f5", borderRadius:12, padding:"18px 20px" }}>
          <div style={{ fontSize:12, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:12 }}>👁️ Vista previa del encabezado de la orden</div>
          <div style={{ background:"#fff", borderRadius:10, padding:"16px 20px", borderBottom:"3px solid #e65100", display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div style={{ display:"flex", alignItems:"center", gap:12 }}>
              {preview && <img src={preview} alt="Logo" style={{ width:50, height:50, objectFit:"contain", borderRadius:7 }}/>}
              <div>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#e65100" }}>{form.nombre||"Nombre del local"}</div>
                <div style={{ fontSize:11, color:"#8a7060", marginTop:3, lineHeight:1.7 }}>
                  {form.titular   && <div>Titular: {form.titular}</div>}
                  {form.cuit      && <div>CUIT: {form.cuit}</div>}
                  {form.direccion && <div>📍 {form.direccion}</div>}
                  {form.telefono  && <div>📞 {form.telefono}</div>}
                </div>
              </div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#e65100" }}>OT-0001</div>
              <div style={{ fontSize:11, color:"#a09080", marginTop:2 }}>Emitida: hoy</div>
            </div>
          </div>
        </div>

        <div style={{ display:"flex", justifyContent:"flex-end", marginTop:24 }}>
          <button style={{ background:"#e65100", color:"#fff", border:"none", padding:"11px 28px", borderRadius:8, fontSize:15, fontWeight:600, fontFamily:"'DM Sans',sans-serif", cursor:"pointer", display:"inline-flex", alignItems:"center", gap:8 }} onClick={handleSave}>
            {empresaSaved ? "✅ ¡Guardado!" : "💾 Guardar configuración"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Pantalla de Login ─────────────────────────────────────────────────────
function LoginScreen() {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);

  const handleLogin = async () => {
    if (!email || !password) { setError("Completá email y contraseña"); return; }
    setLoading(true);
    setError("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (e) {
      setError("Email o contraseña incorrectos");
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(135deg, #e65100 0%, #bf360c 100%)", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'DM Sans',sans-serif", padding:20 }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');`}</style>
      <div style={{ background:"#fff", borderRadius:20, padding:"48px 44px", width:"100%", maxWidth:420, boxShadow:"0 24px 60px rgba(0,0,0,.25)" }}>
        {/* Logo / título */}
        <div style={{ textAlign:"center", marginBottom:36 }}>
          <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:32, fontWeight:700, color:"#e65100", marginBottom:6 }}>Mafalda Gráfica</div>
          <div style={{ fontSize:14, color:"#a09080" }}>Sistema de gestión de pedidos</div>
        </div>

        {/* Form */}
        <div style={{ marginBottom:18 }}>
          <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:7 }}>Email</label>
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleLogin()}
            placeholder="tu@email.com"
            style={{ width:"100%", padding:"11px 14px", borderRadius:9, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", color:"#1a2340", outline:"none", boxSizing:"border-box" }}/>
        </div>
        <div style={{ marginBottom:24 }}>
          <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:7 }}>Contraseña</label>
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleLogin()}
            placeholder="••••••••"
            style={{ width:"100%", padding:"11px 14px", borderRadius:9, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", color:"#1a2340", outline:"none", boxSizing:"border-box" }}/>
        </div>

        {error && (
          <div style={{ background:"#ffebee", color:"#c62828", padding:"10px 14px", borderRadius:8, fontSize:13, marginBottom:18, textAlign:"center" }}>
            ⚠️ {error}
          </div>
        )}

        <button onClick={handleLogin} disabled={loading}
          style={{ width:"100%", padding:"13px", background:"#e65100", color:"#fff", border:"none", borderRadius:9, fontSize:15, fontWeight:700, fontFamily:"'DM Sans',sans-serif", cursor:"pointer", transition:"all .18s", opacity:loading?0.7:1 }}>
          {loading ? "Ingresando..." : "🔐 Ingresar"}
        </button>

        <div style={{ textAlign:"center", marginTop:20, fontSize:12, color:"#d4bfb0" }}>
          Acceso restringido · Solo personal autorizado
        </div>
      </div>
    </div>
  );
}

// ── Helpers para comprobante ─────────────────────────────────────────────
function buildComprobanteHTML(venta, empresa) {
  const num    = `X-${String(venta.numero||1).padStart(5,"0")}`;
  const now    = new Date();
  const fecha  = venta.fecha || now.toLocaleDateString("es-AR");
  const hora   = now.toLocaleTimeString("es-AR",{hour:"2-digit",minute:"2-digit"});
  const nombre = empresa?.nombre || "Mafalda Gráfica";
  const rows   = venta.items.map(it => `
    <tr>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0">${it.cantidad}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0">${it.codigo||"—"}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0">${it.nombre}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0;text-align:right">$${parseFloat(it.precio).toLocaleString("es-AR")}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0;text-align:right;font-weight:700">$${(it.cantidad*it.precio).toLocaleString("es-AR")}</td>
    </tr>`).join("");
  return `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"/>
<title>${num}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}#root{width:100%;min-height:100vh;display:flex;flex-direction:column}
  body{font-family:'DM Sans',sans-serif;background:#fff;color:#1a2340;padding:20mm}
  .hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:14px;border-bottom:3px solid #e65100;margin-bottom:18px}
  .brand{font-family:'DM Sans',sans-serif;font-size:24px;font-weight:800;color:#e65100}
  .brand-sub{font-size:11px;color:#a09080;margin-top:3px;line-height:1.6}
  .comp-num{font-family:'DM Sans',sans-serif;font-size:20px;font-weight:800;color:#e65100;text-align:right}
  .comp-tipo{font-size:11px;color:#a09080;text-align:right;margin-top:3px}
  .badge-x{display:inline-block;background:#fff3e0;color:#e65100;border:2px solid #e65100;border-radius:6px;padding:3px 10px;font-size:13px;font-weight:700;margin-top:4px}
  .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:18px}
  .ibox{background:#fffaf7;border-radius:7px;padding:9px 12px;border-left:3px solid #e65100}
  .ilbl{font-size:10px;font-weight:600;color:#a09080;text-transform:uppercase;letter-spacing:.7px;margin-bottom:3px}
  .ival{font-size:13px;font-weight:600;color:#1a2340}
  table{width:100%;border-collapse:collapse;font-size:13px;margin-bottom:16px}
  thead tr{background:#fff3e0}
  th{padding:9px 10px;text-align:left;font-size:11px;font-weight:700;color:#bf360c;text-transform:uppercase;letter-spacing:.5px}
  th:last-child,th:nth-last-child(2){text-align:right}
  .total-box{background:#fff3e0;border-radius:8px;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
  .total-lbl{font-size:13px;font-weight:600;color:#bf360c;text-transform:uppercase;letter-spacing:.7px}
  .total-val{font-family:'DM Sans',sans-serif;font-size:26px;font-weight:800;color:#e65100}
  .metodo{font-size:12px;color:#a09080;margin-bottom:16px}
  .foot{border-top:1.5px solid #f0e8e0;padding-top:12px;display:flex;justify-content:space-between;font-size:10px;color:#c0b0a0}
  .no-valido{text-align:center;font-size:11px;color:#c0b0a0;margin-bottom:10px;letter-spacing:.5px}
  @media print{body{padding:12mm 14mm}}
</style></head><body>
<div class="hdr">
  <div>
    ${empresa?.logo?`<img src="${empresa.logo}" style="height:50px;object-fit:contain;margin-bottom:6px;display:block"/>`:""}
    <div class="brand">${nombre}</div>
    <div class="brand-sub">
      ${empresa?.titular?`Titular: ${empresa.titular}<br/>`:""}
      ${empresa?.cuit?`CUIT: ${empresa.cuit}<br/>`:""}
      ${empresa?.direccion?`${empresa.direccion}<br/>`:""}
      ${empresa?.telefono?`Tel: ${empresa.telefono}`:""}
    </div>
  </div>
  <div style="text-align:right">
    <div class="comp-num">${num}</div>
    <div class="comp-tipo">Comprobante</div>
    <div class="badge-x">NO VÁLIDO COMO FACTURA</div>
    <div style="font-size:11px;color:#a09080;margin-top:4px">${fecha}${hora?` · ${hora}`:""}</div>
  </div>
</div>
<div class="info-grid">
  <div class="ibox"><div class="ilbl">Cliente</div><div class="ival">${venta.clienteNombre||"Consumidor Final"}</div></div>
  <div class="ibox"><div class="ilbl">Método de Pago</div><div class="ival">${venta.metodoPago||"—"}</div></div>
</div>
<table>
  <thead><tr><th>Cant.</th><th>Código</th><th>Detalle</th><th style="text-align:right">P.Unit.</th><th style="text-align:right">Subtotal</th></tr></thead>
  <tbody>${rows}</tbody>
</table>
<div class="total-box">
  <div class="total-lbl">Total</div>
  <div class="total-val">$${parseFloat(venta.total).toLocaleString("es-AR")}</div>
</div>
<div class="no-valido">⚠️ Este comprobante no tiene validez fiscal · Solo para uso interno</div>
<div class="foot"><span>${nombre}</span><span>${num} · ${fecha}</span></div>
<script>window.onload=()=>window.print();</script>
</body></html>`;
}


function buildPresupuestoHTML(datos, empresa) {
  const num   = `P-${String(datos.numero||1).padStart(5,"0")}`;
  const base  = datos.fecha ? new Date(datos.fecha+"T12:00:00") : new Date();
  const fecha = base.toLocaleDateString("es-AR");
  const hora  = datos.fecha ? "" : new Date().toLocaleTimeString("es-AR",{hour:"2-digit",minute:"2-digit"});
  const nombre = empresa?.nombre || "Mafalda Gráfica";
  const diasValidez = parseInt(datos.validezDias)||parseInt(APP_CFG.validezPresupuesto)||7;
  const validez = new Date(base.getTime() + diasValidez*24*60*60*1000).toLocaleDateString("es-AR");
  const rows = datos.items.map(it => `
    <tr>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0">${it.cantidad}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0">${it.nombre}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0;text-align:right">$${parseFloat(it.precio).toLocaleString("es-AR")}</td>
      <td style="padding:7px 10px;border-bottom:1px solid #f0f0f0;text-align:right;font-weight:700">$${(it.cantidad*it.precio).toLocaleString("es-AR")}</td>
    </tr>`).join("");
  return `<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"/>
<title>Presupuesto ${num}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'DM Sans',sans-serif;background:#fff;color:#1a2340;padding:20mm}
  .hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:14px;border-bottom:3px solid #1a2340;margin-bottom:18px}
  .brand{font-size:24px;font-weight:800;color:#1a2340}
  .brand-sub{font-size:11px;color:#a09080;margin-top:3px;line-height:1.6}
  .pres-num{font-size:20px;font-weight:800;color:#1a2340;text-align:right}
  .pres-badge{display:inline-block;background:#e8eaf6;color:#1a2340;border:2px solid #1a2340;border-radius:6px;padding:3px 10px;font-size:13px;font-weight:700;margin-top:4px}
  .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:18px}
  .ibox{background:#f5f5f5;border-radius:7px;padding:9px 12px;border-left:3px solid #1a2340}
  .ilbl{font-size:10px;font-weight:600;color:#a09080;text-transform:uppercase;letter-spacing:.7px;margin-bottom:3px}
  .ival{font-size:13px;font-weight:600;color:#1a2340}
  table{width:100%;border-collapse:collapse;font-size:13px;margin-bottom:16px}
  thead tr{background:#f0f3f9}
  th{padding:9px 10px;text-align:left;font-size:11px;font-weight:700;color:#1a2340;text-transform:uppercase;letter-spacing:.5px}
  th:last-child,th:nth-last-child(2){text-align:right}
  .total-box{background:#f0f3f9;border-radius:8px;padding:12px 16px;display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
  .total-lbl{font-size:13px;font-weight:600;color:#1a2340;text-transform:uppercase;letter-spacing:.7px}
  .total-val{font-size:26px;font-weight:800;color:#1a2340}
  .validez{text-align:center;font-size:11px;color:#a09080;margin-bottom:10px;padding:8px;background:#fffde7;border-radius:6px}
  .foot{border-top:1.5px solid #e0e0e0;padding-top:12px;display:flex;justify-content:space-between;font-size:10px;color:#a0a0a0}
  @media print{body{padding:12mm 14mm}}
</style></head><body>
<div class="hdr">
  <div>
    ${empresa?.logo?`<img src="${empresa.logo}" style="height:50px;object-fit:contain;margin-bottom:6px;display:block"/>`:""}
    <div class="brand">${nombre}</div>
    <div class="brand-sub">
      ${empresa?.titular?`Titular: ${empresa.titular}<br/>`:""}
      ${empresa?.cuit?`CUIT: ${empresa.cuit}<br/>`:""}
      ${empresa?.direccion?`${empresa.direccion}<br/>`:""}
      ${empresa?.telefono?`Tel: ${empresa.telefono}`:""}
    </div>
  </div>
  <div style="text-align:right">
    <div class="pres-num">${num}</div>
    <div style="font-size:11px;color:#a09080;margin-top:3px">Presupuesto</div>
    <div class="pres-badge">📋 PRESUPUESTO</div>
    <div style="font-size:11px;color:#a09080;margin-top:4px">${fecha}${hora?` · ${hora}`:""}</div>
  </div>
</div>
<div class="info-grid">
  <div class="ibox"><div class="ilbl">Cliente</div><div class="ival">${datos.clienteNombre||"Consumidor Final"}</div></div>
  <div class="ibox"><div class="ilbl">Válido hasta</div><div class="ival">${validez}</div></div>
  ${datos.tiempoEntrega?`<div class="ibox"><div class="ilbl">Tiempo de entrega aprox.</div><div class="ival">${datos.tiempoEntrega}</div></div>`:""}
  ${datos.metodoPago?`<div class="ibox"><div class="ilbl">Forma de pago</div><div class="ival">${datos.metodoPago}</div></div>`:""}
</div>
<table>
  <thead><tr><th>Cant.</th><th>Detalle</th><th style="text-align:right">P.Unit.</th><th style="text-align:right">Subtotal</th></tr></thead>
  <tbody>${rows}</tbody>
</table>
<div class="total-box">
  <div class="total-lbl">Total presupuestado</div>
  <div class="total-val">$${parseFloat(datos.total).toLocaleString("es-AR")}</div>
</div>
${datos.observaciones?`<div style="font-size:12px;color:#4a5568;margin-bottom:12px;padding:10px 12px;border:1px dashed #d0d0d0;border-radius:6px"><b>Observaciones:</b> ${datos.observaciones}</div>`:""}
<div class="validez">⏳ Este presupuesto tiene validez de ${diasValidez} día${diasValidez!==1?"s":""}${APP_CFG.condicionesPresupuesto?` · ${APP_CFG.condicionesPresupuesto}`:""}</div>
${APP_CFG.piePresupuesto?`<div style="font-size:11px;color:#4a5568;margin:10px 0;white-space:pre-wrap">${APP_CFG.piePresupuesto}</div>`:""}
<div class="foot"><span>${nombre}</span><span>${num} · ${fecha}</span></div>
<script>window.onload=()=>window.print();</script>
</body></html>`;
}

function imprimirPresupuesto(datos, empresa) {
  const html = buildPresupuestoHTML(datos, empresa);
  const win  = window.open("","_blank","width=860,height=700");
  if (!win) { alert("Habilitá los popups para imprimir."); return; }
  win.document.write(html);
  win.document.close();
}

function imprimirComprobante(venta, empresa) {
  const html = buildComprobanteHTML(venta, empresa);
  const win  = window.open("","_blank","width=860,height=700");
  if (!win) { alert("Habilitá los popups para imprimir."); return; }
  win.document.write(html);
  win.document.close();
}

// ── Tipos de evento agenda ────────────────────────────────────────────────
const TIPO_EVENTO = {
  recordatorio: { label:"Recordatorio", color:"#1565c0", bg:"#e3f2fd", icon:"🔔" },
  pago:         { label:"Pago",         color:"#2e7d32", bg:"#e8f5e9", icon:"💵" },
  vencimiento:  { label:"Vencimiento",  color:"#c62828", bg:"#ffebee", icon:"⏰" },
  cliente:      { label:"Visita cliente",color:"#6a1b9a",bg:"#f3e5f5", icon:"🤝" },
  libre:        { label:"Libre",        color:"#e65100", bg:"#fff3e0", icon:"📌" },
};

// ── Componente: Agenda ────────────────────────────────────────────────────
function AgendaView({ nuevoEventoModal, setNuevoEventoModal, showToast }) {
  const [eventos, setEventos]       = useState([]);
  const [fechaBase, setFechaBase]   = useState(new Date());
  const [modoVista, setModoVista]   = useState("mes");
  const [editEvento, setEditEvento] = useState(null);
  const [verEvento, setVerEvento]   = useState(null);
  const DIAS = ["Lun","Mar","Mié","Jue","Vie","Sáb","Dom"];

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "eventos"), snap => {
      setEventos(snap.docs.map(d=>({...d.data(), fireId:d.id})));
    });
    return () => unsub();
  }, []);

  // Solicitar permiso notificaciones
  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  // Chequear eventos próximos cada minuto
  useEffect(() => {
    const check = () => {
      if (!("Notification" in window) || Notification.permission !== "granted") return;
      const ahora = new Date();
      eventos.forEach(ev => {
        if (!ev.notificar) return;
        const evDate = new Date(`${ev.fecha}T${ev.hora||"00:00"}`);
        const diff   = (evDate - ahora) / 60000; // minutos
        if (diff > 0 && diff <= 30 && !ev._notificado) {
          new Notification(`${TIPO_EVENTO[ev.tipo]?.icon||"📌"} ${ev.titulo}`, {
            body: `En ${Math.round(diff)} minutos · ${ev.hora||""}`,
          });
          // Marcar como notificado en memoria
          ev._notificado = true;
        }
      });
    };
    check();
    const interval = setInterval(check, 60000);
    return () => clearInterval(interval);
  }, [eventos]);

  const fmtFecha = d => d.toISOString().split("T")[0];
  const hoy      = fmtFecha(new Date());

  const diasMes = () => {
    const año  = fechaBase.getFullYear();
    const mes  = fechaBase.getMonth();
    const first = new Date(año, mes, 1);
    const last  = new Date(año, mes+1, 0);
    const start = new Date(first); start.setDate(start.getDate()-((start.getDay()+6)%7));
    const end   = new Date(last);  end.setDate(end.getDate()+(6-(end.getDay()+6)%7));
    const dias  = [];
    const cur   = new Date(start);
    while (cur <= end) { dias.push(new Date(cur)); cur.setDate(cur.getDate()+1); }
    return dias;
  };

  const diasSemana = () => {
    const lunes = new Date(fechaBase);
    lunes.setDate(lunes.getDate()-((lunes.getDay()+6)%7));
    return Array.from({length:7},(_,i)=>{ const d=new Date(lunes); d.setDate(d.getDate()+i); return d; });
  };

  const dias = modoVista==="mes" ? diasMes() : modoVista==="semana" ? diasSemana() : [new Date(fechaBase)];

  const eventosDia = (fecha) => eventos
    .filter(ev => ev.fecha === fmtFecha(fecha))
    .sort((a,b) => (a.hora||"00:00").localeCompare(b.hora||"00:00"));

  const moverFecha = dir => {
    const d = new Date(fechaBase);
    if (modoVista==="dia")    d.setDate(d.getDate()+dir);
    if (modoVista==="semana") d.setDate(d.getDate()+dir*7);
    if (modoVista==="mes")    d.setMonth(d.getMonth()+dir);
    setFechaBase(d);
  };

  const titulo = () => {
    if (modoVista==="dia")    return fechaBase.toLocaleDateString("es-AR",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
    if (modoVista==="semana") {
      const ds = diasSemana();
      return `${ds[0].getDate()} ${ds[0].toLocaleDateString("es-AR",{month:"short"})} — ${ds[6].getDate()} ${ds[6].toLocaleDateString("es-AR",{month:"short",year:"numeric"})}`;
    }
    return fechaBase.toLocaleDateString("es-AR",{month:"long",year:"numeric"});
  };

  const handleDelete = async (ev) => {
    if (!window.confirm("¿Eliminar este evento?")) return;
    await deleteDoc(doc(db, "eventos", ev.fireId));
    setVerEvento(null);
    showToast("Evento eliminado","error");
  };

  // Próximos eventos (hoy en adelante)
  const proximos = eventos
    .filter(ev => ev.fecha >= hoy)
    .sort((a,b) => a.fecha.localeCompare(b.fecha)||(a.hora||"").localeCompare(b.hora||""))
    .slice(0,5);

  return (
    <div>
      <div className="grid-agenda">

        {/* ── Calendario ── */}
        <div>
          {/* Controles */}
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16, flexWrap:"wrap", gap:10 }}>
            <div style={{ display:"flex", gap:6 }}>
              {["dia","semana","mes"].map(m=>(
                <button key={m} onClick={()=>setModoVista(m)}
                  style={{ padding:"7px 16px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
                    background:modoVista===m?"#e65100":"#fff", color:modoVista===m?"#fff":"#4a5568",
                    boxShadow:modoVista===m?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
                  {m==="dia"?"Día":m==="semana"?"Semana":"Mes"}
                </button>
              ))}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <button onClick={()=>moverFecha(-1)} style={{ background:"#fff", border:"1.5px solid #f0d5c0", color:"#1a2340", width:34, height:34, borderRadius:8, fontSize:16, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>‹</button>
              <span style={{ fontFamily:"'DM Sans',sans-serif", fontWeight:700, fontSize:16, color:"#1a2340", minWidth:240, textAlign:"center", textTransform:"capitalize" }}>{titulo()}</span>
              <button onClick={()=>moverFecha(1)}  style={{ background:"#fff", border:"1.5px solid #f0d5c0", color:"#1a2340", width:34, height:34, borderRadius:8, fontSize:16, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center" }}>›</button>
              <button onClick={()=>setFechaBase(new Date())} style={{ padding:"7px 14px", borderRadius:8, fontSize:12, fontWeight:600, border:"1.5px solid #e65100", color:"#e65100", background:"#fff", cursor:"pointer" }}>Hoy</button>
              <button onClick={()=>setNuevoEventoModal(true)} style={{ padding:"7px 16px", borderRadius:8, fontSize:13, fontWeight:700, background:"#e65100", color:"#fff", border:"none", cursor:"pointer" }}>+ Evento</button>
            </div>
          </div>

          {/* Grilla */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
            {modoVista!=="dia" && (
              <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)", borderBottom:"2px solid #f5e8e0" }}>
                {DIAS.map(d=>(
                  <div key={d} style={{ padding:"10px 8px", textAlign:"center", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px" }}>{d}</div>
                ))}
              </div>
            )}

            {modoVista==="dia" ? (
              <div style={{ padding:"24px 28px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:20 }}>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:fmtFecha(fechaBase)===hoy?"#e65100":"#1a2340", textTransform:"capitalize" }}>
                    {fechaBase.toLocaleDateString("es-AR",{weekday:"long",day:"numeric",month:"long"})}
                  </div>
                  {fmtFecha(fechaBase)===hoy && <span style={{ background:"#e65100", color:"#fff", padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:700 }}>Hoy</span>}
                </div>
                {eventosDia(fechaBase).length===0 ? (
                  <div style={{ textAlign:"center", padding:"40px 0", color:"#d4bfb0" }}>Sin eventos — <span style={{ color:"#e65100", cursor:"pointer", fontWeight:600 }} onClick={()=>setNuevoEventoModal(true)}>+ Agregar</span></div>
                ) : eventosDia(fechaBase).map(ev=>{
                  const t = TIPO_EVENTO[ev.tipo]||TIPO_EVENTO.libre;
                  return (
                    <div key={ev.fireId} onClick={()=>setVerEvento(ev)}
                      style={{ display:"flex", alignItems:"center", gap:14, padding:"14px 18px", borderRadius:10, border:`1.5px solid ${t.color}22`, background:t.bg, marginBottom:10, cursor:"pointer" }}>
                      <span style={{ fontSize:24 }}>{t.icon}</span>
                      <div style={{ flex:1 }}>
                        <div style={{ fontWeight:700, color:"#1a2340", fontSize:14 }}>{ev.titulo}</div>
                        {ev.descripcion && <div style={{ fontSize:12, color:"#6b7a9a", marginTop:2 }}>{ev.descripcion}</div>}
                      </div>
                      <div style={{ textAlign:"right" }}>
                        <span style={{ background:t.bg, color:t.color, padding:"3px 8px", borderRadius:20, fontSize:11, fontWeight:700, border:`1px solid ${t.color}33` }}>{t.label}</span>
                        {ev.hora && <div style={{ fontSize:12, color:"#a09080", marginTop:4 }}>🕐 {ev.hora}</div>}
                        {ev.notificar && <div style={{ fontSize:10, color:"#2e7d32", marginTop:2 }}>🔔 con alerta</div>}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)" }}>
                {dias.map((d,i)=>{
                  const fecha   = fmtFecha(d);
                  const evs     = eventosDia(d);
                  const esHoy   = fecha===hoy;
                  const esMes   = modoVista==="semana" || d.getMonth()===fechaBase.getMonth();
                  const domingo = d.getDay()===0;
                  return (
                    <div key={i} onClick={()=>{setFechaBase(d);setModoVista("dia");}}
                      style={{ minHeight:modoVista==="mes"?110:160, padding:"8px", borderRight:i%7!==6?"1px solid #f5e8e0":"none", borderBottom:"1px solid #f5e8e0",
                        background:esHoy?"#fff8f5":!esMes?"#fafafa":"#fff", opacity:!esMes?.6:1, cursor:"pointer" }}
                      onMouseOver={e=>e.currentTarget.style.background=esHoy?"#fff3e0":"#fffaf7"}
                      onMouseOut={e=>e.currentTarget.style.background=esHoy?"#fff8f5":!esMes?"#fafafa":"#fff"}>
                      <div style={{ marginBottom:4, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                        <span style={{ fontSize:12, fontWeight:700, width:24, height:24, display:"inline-flex", alignItems:"center", justifyContent:"center", borderRadius:"50%",
                          background:esHoy?"#e65100":"transparent", color:esHoy?"#fff":domingo?"#c62828":"#4a5568" }}>
                          {d.getDate()}
                        </span>
                        {evs.length>0 && <span style={{ fontSize:10, fontWeight:700, color:"#e65100", background:"#fff3e0", borderRadius:10, padding:"1px 5px" }}>{evs.length}</span>}
                      </div>
                      {(modoVista==="mes"?evs.slice(0,2):evs).map(ev=>{
                        const t = TIPO_EVENTO[ev.tipo]||TIPO_EVENTO.libre;
                        return (
                          <div key={ev.fireId} onClick={e=>{e.stopPropagation();setVerEvento(ev);}}
                            style={{ background:t.bg, borderLeft:`2px solid ${t.color}`, borderRadius:4, padding:"2px 5px", marginBottom:2, fontSize:10, fontWeight:600, color:t.color, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                            {t.icon} {ev.titulo}
                          </div>
                        );
                      })}
                      {modoVista==="mes" && evs.length>2 && <div style={{ fontSize:10, color:"#a09080", paddingLeft:4 }}>+{evs.length-2} más</div>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* ── Panel lateral: próximos eventos ── */}
        <div>
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px" }}>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:16, fontWeight:700, color:"#1a2340", marginBottom:14 }}>📋 Próximos eventos</div>
            {proximos.length===0 ? (
              <div style={{ textAlign:"center", padding:"20px 0", color:"#d4bfb0", fontSize:13 }}>Sin eventos próximos</div>
            ) : proximos.map(ev=>{
              const t = TIPO_EVENTO[ev.tipo]||TIPO_EVENTO.libre;
              return (
                <div key={ev.fireId} onClick={()=>setVerEvento(ev)}
                  style={{ display:"flex", gap:10, padding:"10px 0", borderBottom:"1px solid #fef0e8", cursor:"pointer" }}
                  onMouseOver={e=>e.currentTarget.style.background="#fffaf7"}
                  onMouseOut={e=>e.currentTarget.style.background="transparent"}>
                  <span style={{ fontSize:20, flexShrink:0 }}>{t.icon}</span>
                  <div style={{ flex:1 }}>
                    <div style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{ev.titulo}</div>
                    <div style={{ fontSize:11, color:"#a09080", marginTop:2 }}>
                      {ev.fecha===hoy?"Hoy":ev.fecha} {ev.hora&&`· ${ev.hora}`}
                    </div>
                  </div>
                  <span style={{ background:t.bg, color:t.color, padding:"2px 7px", borderRadius:10, fontSize:10, fontWeight:700, alignSelf:"flex-start" }}>{t.label}</span>
                </div>
              );
            })}
          </div>

          {/* Leyenda tipos */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"16px 20px", marginTop:16 }}>
            <div style={{ fontSize:12, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:10 }}>Tipos de evento</div>
            {Object.entries(TIPO_EVENTO).map(([key,t])=>(
              <div key={key} style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
                <span style={{ fontSize:16 }}>{t.icon}</span>
                <span style={{ background:t.bg, color:t.color, padding:"2px 8px", borderRadius:10, fontSize:12, fontWeight:600 }}>{t.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Modal nuevo/editar evento ── */}
      {(nuevoEventoModal||editEvento) && (
        <ModalEvento
          evento={editEvento}
          onClose={()=>{ setNuevoEventoModal(false); setEditEvento(null); }}
          showToast={showToast}
          fechaInicial={fmtFecha(fechaBase)}
        />
      )}

      {/* ── Modal ver evento ── */}
      {verEvento && (()=>{
        const t = TIPO_EVENTO[verEvento.tipo]||TIPO_EVENTO.libre;
        return (
          <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200 }} onClick={()=>setVerEvento(null)}>
            <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:400, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
              <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:16 }}>
                <span style={{ fontSize:32 }}>{t.icon}</span>
                <div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340" }}>{verEvento.titulo}</div>
                  <span style={{ background:t.bg, color:t.color, padding:"2px 8px", borderRadius:10, fontSize:12, fontWeight:600 }}>{t.label}</span>
                </div>
              </div>
              {verEvento.descripcion && <div style={{ fontSize:14, color:"#4a5568", marginBottom:12, lineHeight:1.5 }}>{verEvento.descripcion}</div>}
              <div style={{ fontSize:13, color:"#a09080", marginBottom:16 }}>
                📅 {verEvento.fecha} {verEvento.hora&&`· 🕐 ${verEvento.hora}`}
                {verEvento.notificar && <span style={{ marginLeft:8, color:"#2e7d32" }}>🔔 Con alerta</span>}
              </div>
              <div style={{ display:"flex", gap:8, justifyContent:"flex-end" }}>
                <button onClick={()=>handleDelete(verEvento)} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"8px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>🗑 Eliminar</button>
                <button onClick={()=>{ setEditEvento(verEvento); setVerEvento(null); }} style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"8px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>✏️ Editar</button>
                <button onClick={()=>setVerEvento(null)} style={{ background:"#e65100", color:"#fff", border:"none", padding:"8px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cerrar</button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

// ── Modal Nuevo/Editar Evento ─────────────────────────────────────────────
function ModalEvento({ evento, onClose, showToast, fechaInicial }) {
  const [form, setForm] = useState(evento || { titulo:"", tipo:"recordatorio", fecha:fechaInicial||"", hora:"", descripcion:"", notificar:true });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.titulo.trim() || !form.fecha) { showToast("Completá título y fecha","error"); return; }
    setSaving(true);
    if (evento?.fireId) {
      await updateDoc(doc(db,"eventos",evento.fireId), form);
      showToast("Evento actualizado ✅");
    } else {
      await addDoc(collection(db,"eventos"), form);
      showToast("Evento creado ✅");
    }
    setSaving(false);
    onClose();
  };

  const inp = { width:"100%", padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", color:"#1a2340", outline:"none", boxSizing:"border-box" };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:460, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
        <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340", marginBottom:20 }}>{evento?"✏️ Editar Evento":"➕ Nuevo Evento"}</div>
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Título *</label>
            <input value={form.titulo} onChange={e=>setForm(f=>({...f,titulo:e.target.value}))} placeholder="Ej: Pagar factura proveedor" style={inp}/>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
            <div>
              <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Tipo</label>
              <select value={form.tipo} onChange={e=>setForm(f=>({...f,tipo:e.target.value}))} style={{ ...inp, cursor:"pointer" }}>
                {Object.entries(TIPO_EVENTO).map(([k,t])=><option key={k} value={k}>{t.icon} {t.label}</option>)}
              </select>
            </div>
            <div>
              <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Fecha *</label>
              <input type="date" value={form.fecha} onChange={e=>setForm(f=>({...f,fecha:e.target.value}))} style={inp}/>
            </div>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
            <div>
              <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Hora</label>
              <input type="time" value={form.hora} onChange={e=>setForm(f=>({...f,hora:e.target.value}))} style={inp}/>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:10, paddingTop:24 }}>
              <input type="checkbox" id="notif" checked={form.notificar} onChange={e=>setForm(f=>({...f,notificar:e.target.checked}))} style={{ width:18, height:18, cursor:"pointer" }}/>
              <label htmlFor="notif" style={{ fontSize:13, fontWeight:600, color:"#4a5568", cursor:"pointer" }}>🔔 Notificarme</label>
            </div>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Descripción / Notas</label>
            <textarea value={form.descripcion} onChange={e=>setForm(f=>({...f,descripcion:e.target.value}))} placeholder="Detalles opcionales..." rows={3}
              style={{ ...inp, resize:"vertical" }}/>
          </div>
        </div>
        <div style={{ display:"flex", gap:10, justifyContent:"flex-end", marginTop:20 }}>
          <button onClick={onClose} style={{ padding:"10px 20px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={handleSave} disabled={saving} style={{ padding:"10px 24px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
            {saving?"Guardando...":"✅ Guardar"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Componente: Proveedores ───────────────────────────────────────────────
function ProveedoresView({ view, setView, showToast }) {
  const [proveedores, setProveedores] = useState([]);
  const [selected, setSelected]       = useState(null);
  const [busq, setBusq]               = useState("");
  const [editingId, setEditingId]     = useState(null);
  const [tabProv, setTabProv]         = useState("proveedores"); // proveedores | compras

  useEffect(() => {
    const unsub = onSnapshot(collection(db,"proveedores"), snap => {
      setProveedores(snap.docs.map(d=>({...d.data(),fireId:d.id})));
    });
    return () => unsub();
  }, []);

  const filtrados = proveedores.filter(p => {
    const q = busq.toLowerCase();
    return !busq || `${p.empresa||""} ${p.titular||""} ${p.telefono||""}`.toLowerCase().includes(q);
  });

  const handleDelete = async (p) => {
    if (!window.confirm(`¿Eliminar proveedor "${p.empresa||p.titular}"?`)) return;
    await deleteDoc(doc(db,"proveedores",p.fireId));
    setSelected(null);
    showToast("Proveedor eliminado","error");
  };

  // ── Vista detalle proveedor ──
  if (selected && view==="proveedores") {
    const prov = proveedores.find(p=>p.fireId===selected);
    if (!prov) { setSelected(null); return null; }
    return <ProveedorDetalle prov={prov} setSelected={setSelected} setEditingId={setEditingId} setView={setView} handleDelete={handleDelete} showToast={showToast}/>;
  }

  // ── Formulario nuevo/editar ──
  if (view==="nuevoProveedor"||view==="editarProveedor") {
    const provExistente = editingId ? proveedores.find(p=>p.fireId===editingId) : null;
    return <FormularioProveedor prov={provExistente} setView={setView} setSelected={setSelected} showToast={showToast}/>;
  }

  return (
    <div>
      {/* Tabs principales */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <div style={{ display:"flex", gap:8 }}>
          {[["proveedores","🏭 Proveedores"],["compras","🛒 Lista de Compras"]].map(([t,l])=>(
            <button key={t} onClick={()=>setTabProv(t)}
              style={{ padding:"9px 20px", borderRadius:20, fontSize:14, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
                background:tabProv===t?"#e65100":"#fff", color:tabProv===t?"#fff":"#4a5568",
                boxShadow:tabProv===t?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
              {l}
            </button>
          ))}
        </div>
        {tabProv==="proveedores" && (
          <button onClick={()=>{ setEditingId(null); setView("nuevoProveedor"); }}
            style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 22px", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
            ➕ Nuevo Proveedor
          </button>
        )}
      </div>

      {/* ── TAB: PROVEEDORES ── */}
      {tabProv==="proveedores" && (
        <div>
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18 }}>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)" }}>🔍</span>
              <input placeholder="Buscar proveedor..." value={busq} onChange={e=>setBusq(e.target.value)}
                style={{ width:"100%", padding:"10px 14px 10px 32px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
            </div>
          </div>

          {filtrados.length===0 ? (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px", textAlign:"center" }}>
              <div style={{ fontSize:40, marginBottom:14 }}>🏭</div>
              <div style={{ fontWeight:700, fontSize:18, fontFamily:"'DM Sans',sans-serif", marginBottom:6 }}>{busq?"Sin resultados":"No hay proveedores"}</div>
              <div style={{ color:"#a09080" }}>Agregá tu primer proveedor</div>
            </div>
          ) : (
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))", gap:16 }}>
              {filtrados.map(p=>(
                <div key={p.fireId} onClick={()=>setSelected(p.fireId)}
                  style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px", cursor:"pointer", borderTop:"3px solid #e65100", transition:"all .15s" }}
                  onMouseOver={e=>e.currentTarget.style.boxShadow="0 6px 24px rgba(230,81,0,.15)"}
                  onMouseOut={e=>e.currentTarget.style.boxShadow="0 2px 14px rgba(230,81,0,.07)"}>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:17, fontWeight:700, color:"#1a2340", marginBottom:4 }}>{p.empresa||"Sin nombre"}</div>
                  {p.titular && <div style={{ fontSize:13, color:"#a09080", marginBottom:8 }}>👤 {p.titular}</div>}
                  <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                    {p.telefono && <div style={{ fontSize:12, fontWeight:700, color:"#e65100" }}>📞 {p.telefono}</div>}
                    {p.mail     && <div style={{ fontSize:12, color:"#4a5568" }}>✉️ {p.mail}</div>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── TAB: LISTA DE COMPRAS ── */}
      {tabProv==="compras" && (
        <ListaComprasView proveedores={proveedores} showToast={showToast}/>
      )}
    </div>
  );
}

// ── Lista de Compras Global ───────────────────────────────────────────────
function ListaComprasView({ proveedores, showToast }) {
  const [items, setItems]         = useState([]);
  const [modalItem, setModalItem] = useState(null); // null | {} | item existente
  const [filtroProv, setFiltroProv] = useState("todos");
  const [filtroEstado, setFiltroEst] = useState("pendiente");

  useEffect(() => {
    const unsub = onSnapshot(collection(db,"listaCompras"), snap => {
      setItems(snap.docs.map(d=>({...d.data(),fireId:d.id}))
        .sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0));
    });
    return () => unsub();
  }, []);

  const filtrados = items.filter(i => {
    const matchProv  = filtroProv==="todos" || i.proveedorId===filtroProv;
    const matchEst   = filtroEstado==="todos" || i.estado===filtroEstado;
    return matchProv && matchEst;
  });

  const totalPendiente = filtrados.filter(i=>i.estado==="pendiente")
    .reduce((s,i)=>s+(parseFloat(i.precioInd||0)*parseInt(i.cantidad||1)),0);

  const marcarConseguido = async (item) => {
    await updateDoc(doc(db,"listaCompras",item.fireId),{estado:"conseguido",fechaConseguido:new Date().toISOString().split("T")[0]});
    showToast(`"${item.detalle}" marcado como conseguido ✅`);
  };

  const eliminar = async (item) => {
    await deleteDoc(doc(db,"listaCompras",item.fireId));
    showToast("Item eliminado","error");
  };

  const inp = {padding:"9px 12px",borderRadius:8,border:"1.5px solid #f0d5c0",fontSize:13,fontFamily:"'DM Sans',sans-serif",outline:"none",boxSizing:"border-box",width:"100%"};

  return (
    <div>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <div>
          <h3 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340" }}>🛒 Lista de Compras</h3>
          <p style={{ fontSize:13, color:"#a09080", marginTop:3 }}>
            {filtrados.filter(i=>i.estado==="pendiente").length} pendiente{filtrados.filter(i=>i.estado==="pendiente").length!==1?"s":""} · Total: <strong style={{color:"#e65100"}}>${totalPendiente.toLocaleString("es-AR")}</strong>
          </p>
        </div>
        <button onClick={()=>setModalItem({})}
          style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
          ➕ Agregar Item
        </button>
      </div>

      {/* Filtros */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18, display:"flex", gap:12, flexWrap:"wrap", alignItems:"center" }}>
        <select value={filtroProv} onChange={e=>setFiltroProv(e.target.value)}
          style={{ ...inp, width:"auto", minWidth:180, cursor:"pointer" }}>
          <option value="todos">Todos los proveedores</option>
          {proveedores.map(p=><option key={p.fireId} value={p.fireId}>{p.empresa||p.titular}</option>)}
        </select>
        <div style={{ display:"flex", gap:6 }}>
          {[["pendiente","⏳ Pendientes"],["conseguido","✅ Conseguidos"],["todos","Todos"]].map(([v,l])=>(
            <button key={v} onClick={()=>setFiltroEst(v)}
              style={{ padding:"7px 14px", borderRadius:20, fontSize:12, fontWeight:600, cursor:"pointer", border:"none",
                background:filtroEstado===v?"#e65100":"#fff8f5", color:filtroEstado===v?"#fff":"#a09080" }}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Tabla */}
      {filtrados.length===0 ? (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px", textAlign:"center", color:"#a09080" }}>
          <div style={{ fontSize:36, marginBottom:12 }}>🛒</div>
          <div style={{ fontWeight:700, fontSize:16, fontFamily:"'DM Sans',sans-serif" }}>Sin items en la lista</div>
          <div style={{ fontSize:13, marginTop:6 }}>Agregá lo que necesitás comprar</div>
        </div>
      ) : (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
            <thead>
              <tr style={{ background:"#fffaf7" }}>
                {["Cant.","Detalle","Proveedor","P. Individual","P. Total","Estado",""].map(h=>(
                  <th key={h} style={{ padding:"11px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0", whiteSpace:"nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtrados.map(item => {
                const prov = proveedores.find(p=>p.fireId===item.proveedorId);
                const cant = parseInt(item.cantidad||1);
                const pInd = parseFloat(item.precioInd||0);
                const pTot = cant * pInd;
                const conseguido = item.estado==="conseguido";
                return (
                  <tr key={item.fireId} style={{ borderBottom:"1px solid #fef0e8", opacity:conseguido?.6:1, background:conseguido?"#fffaf7":"#fff" }}>
                    <td style={{ padding:"12px 14px", fontWeight:700, color:"#e65100", fontSize:15 }}>{cant}</td>
                    <td style={{ padding:"12px 14px", color:"#1a2340", fontWeight:600 }}>
                      <div style={{ textDecoration:conseguido?"line-through":"none" }}>{item.detalle}</div>
                      {item.notas && <div style={{ fontSize:11, color:"#a09080", marginTop:2 }}>{item.notas}</div>}
                    </td>
                    <td style={{ padding:"12px 14px" }}>
                      {prov
                        ? <span style={{ background:"#fff3e0", color:"#e65100", padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:600 }}>{prov.empresa||prov.titular}</span>
                        : <span style={{ color:"#a09080", fontSize:12 }}>Sin asignar</span>
                      }
                    </td>
                    <td style={{ padding:"12px 14px", color:"#4a5568" }}>{pInd>0?`$${pInd.toLocaleString("es-AR")}`:"—"}</td>
                    <td style={{ padding:"12px 14px", fontWeight:700, color:pTot>0?"#1a2340":"#a09080" }}>{pTot>0?`$${pTot.toLocaleString("es-AR")}`:"—"}</td>
                    <td style={{ padding:"12px 14px" }}>
                      {conseguido
                        ? <span style={{ background:"#e8f5e9", color:"#2e7d32", padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:600 }}>✅ Conseguido</span>
                        : <span style={{ background:"#fff3e0", color:"#e65100", padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:600 }}>⏳ Pendiente</span>
                      }
                    </td>
                    <td style={{ padding:"12px 12px" }}>
                      <div style={{ display:"flex", gap:5 }}>
                        {!conseguido && (
                          <button onClick={()=>marcarConseguido(item)}
                            style={{ background:"#e8f5e9", border:"none", color:"#2e7d32", padding:"5px 9px", borderRadius:6, fontSize:13, cursor:"pointer", fontWeight:700 }} title="Marcar conseguido">
                            ✓
                          </button>
                        )}
                        <button onClick={()=>setModalItem(item)}
                          style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"5px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>✏️</button>
                        <button onClick={()=>eliminar(item)}
                          style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"5px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
            {totalPendiente > 0 && (
              <tfoot>
                <tr style={{ background:"#fff8f5", borderTop:"2px solid #f0d5c0" }}>
                  <td colSpan={4} style={{ padding:"12px 14px", fontWeight:700, color:"#a09080", fontSize:13 }}>TOTAL PENDIENTE</td>
                  <td style={{ padding:"12px 14px", fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#e65100" }}>${totalPendiente.toLocaleString("es-AR")}</td>
                  <td colSpan={2}></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      )}

      {/* Modal agregar/editar item */}
      {modalItem && (
        <ModalItemCompra
          item={modalItem.fireId ? modalItem : null}
          proveedores={proveedores}
          onClose={()=>setModalItem(null)}
          showToast={showToast}
        />
      )}
    </div>
  );
}

// ── Modal Item de Compra ──────────────────────────────────────────────────
function ModalItemCompra({ item, proveedores, onClose, showToast }) {
  const [form, setForm] = useState(item || { cantidad:1, detalle:"", proveedorId:"", precioInd:"", notas:"", estado:"pendiente" });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.detalle.trim()) { showToast("El detalle es obligatorio","error"); return; }
    setSaving(true);
    const data = { ...form, cantidad:parseInt(form.cantidad)||1, precioInd:parseFloat(form.precioInd)||0, fecha:form.fecha||new Date().toISOString().split("T")[0] };
    if (item?.fireId) {
      await updateDoc(doc(db,"listaCompras",item.fireId), data);
      showToast("Item actualizado ✅");
    } else {
      await addDoc(collection(db,"listaCompras"), data);
      showToast("Item agregado a la lista ✅");
    }
    setSaving(false);
    onClose();
  };

  const inp = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:500, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
        <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340", marginBottom:20 }}>
          {item?.fireId?"✏️ Editar Item":"➕ Nuevo Item de Compra"}
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
          <div style={{ gridColumn:"1 / -1" }}>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Detalle *</label>
            <input value={form.detalle} onChange={e=>setForm(f=>({...f,detalle:e.target.value}))} placeholder="Ej: Vinilo base blanca 1.52m" style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Cantidad</label>
            <input type="number" min="1" value={form.cantidad} onChange={e=>setForm(f=>({...f,cantidad:e.target.value}))} style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio Individual ($)</label>
            <input type="number" value={form.precioInd} onChange={e=>setForm(f=>({...f,precioInd:e.target.value}))} placeholder="0" style={inp}/>
          </div>
          <div style={{ gridColumn:"1 / -1" }}>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Proveedor</label>
            <select value={form.proveedorId||""} onChange={e=>setForm(f=>({...f,proveedorId:e.target.value}))} style={{ ...inp, cursor:"pointer" }}>
              <option value="">Sin asignar</option>
              {proveedores.map(p=><option key={p.fireId} value={p.fireId}>{p.empresa||p.titular}</option>)}
            </select>
          </div>
          <div style={{ gridColumn:"1 / -1" }}>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Notas (opcional)</label>
            <input value={form.notas||""} onChange={e=>setForm(f=>({...f,notas:e.target.value}))} placeholder="Medida, color, especificaciones..." style={inp}/>
          </div>
          {form.precioInd > 0 && form.cantidad > 0 && (
            <div style={{ gridColumn:"1 / -1", background:"#fff8f5", borderRadius:8, padding:"10px 14px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <span style={{ fontSize:13, color:"#a09080", fontWeight:600 }}>Total estimado:</span>
              <span style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#e65100" }}>
                ${(parseFloat(form.precioInd||0)*parseInt(form.cantidad||1)).toLocaleString("es-AR")}
              </span>
            </div>
          )}
        </div>
        <div style={{ display:"flex", gap:10, justifyContent:"flex-end", marginTop:20 }}>
          <button onClick={onClose} style={{ padding:"9px 18px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={handleSave} disabled={saving}
            style={{ padding:"9px 22px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            {saving?"Guardando...":"✅ Guardar"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Detalle Proveedor ─────────────────────────────────────────────────────
function ProveedorDetalle({ prov, setSelected, setEditingId, setView, handleDelete, showToast }) {
  const [pedidoModal, setPedidoModal]   = useState(false);
  const [pedidosList, setPedidosList]   = useState([]);
  const [facturas, setFacturas]         = useState([]);
  const [tabActiva, setTabActiva]       = useState("pedidos");
  const [nuevoPedItem, setNuevoPedItem] = useState("");

  useEffect(() => {
    const u1 = onSnapshot(collection(db,"pedidosProveedor"), snap => {
      setPedidosList(snap.docs.map(d=>({...d.data(),fireId:d.id})).filter(p=>p.proveedorId===prov.fireId));
    });
    const u2 = onSnapshot(collection(db,"facturasProveedor"), snap => {
      setFacturas(snap.docs.map(d=>({...d.data(),fireId:d.id})).filter(f=>f.proveedorId===prov.fireId).sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0));
    });
    return () => { u1(); u2(); };
  }, [prov.fireId]);

  const pendientes  = pedidosList.filter(p=>!p.conseguido);
  const conseguidos = pedidosList.filter(p=>p.conseguido);

  const agregarItem = async () => {
    if (!nuevoPedItem.trim()) return;
    await addDoc(collection(db,"pedidosProveedor"), { proveedorId:prov.fireId, item:nuevoPedItem.trim(), conseguido:false, fecha:new Date().toISOString().split("T")[0] });
    setNuevoPedItem("");
  };

  const marcarConseguido = async (p) => {
    await updateDoc(doc(db,"pedidosProveedor",p.fireId), { conseguido:true, fechaConseguido:new Date().toISOString().split("T")[0] });
    showToast(`"${p.item}" marcado como conseguido ✅`);
  };

  const eliminarItem = async (p) => {
    await deleteDoc(doc(db,"pedidosProveedor",p.fireId));
  };

  const subirFactura = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      await addDoc(collection(db,"facturasProveedor"), {
        proveedorId: prov.fireId,
        fecha:       new Date().toISOString().split("T")[0],
        nombre:      file.name,
        imagen:      ev.target.result,
      });
      showToast("Factura guardada ✅");
    };
    reader.readAsDataURL(file);
  };

  return (
    <div>
      <button onClick={()=>setSelected(null)} style={{ background:"transparent", border:"none", color:"#e65100", fontWeight:600, fontSize:14, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver a proveedores</button>

      {/* Ficha */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"24px 28px", marginBottom:20, display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
        <div>
          <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:24, fontWeight:700, color:"#1a2340", marginBottom:4 }}>{prov.empresa||"Sin nombre"}</div>
          {prov.titular   && <div style={{ fontSize:13, color:"#a09080", marginBottom:8 }}>👤 {prov.titular}</div>}
          <div style={{ display:"flex", flexWrap:"wrap", gap:16 }}>
            {prov.cuit      && <span style={{ fontSize:13 }}>🪪 {prov.cuit}</span>}
            {prov.telefono  && <span style={{ fontSize:13, fontWeight:700, color:"#e65100" }}>📞 {prov.telefono}</span>}
            {prov.mail      && <span style={{ fontSize:13 }}>✉️ {prov.mail}</span>}
            {prov.direccion && <span style={{ fontSize:13 }}>📍 {prov.direccion}</span>}
          </div>
        </div>
        <div style={{ display:"flex", gap:8 }}>
          <button onClick={()=>{ setEditingId(prov.fireId); setView("editarProveedor"); }}
            style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"7px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>✏️ Editar</button>
          <button onClick={()=>handleDelete(prov)}
            style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"7px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>🗑</button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", gap:8, marginBottom:16 }}>
        {[["pedidos","📋 Lista de pedidos"],["facturas","🧾 Facturas"],["historial","📦 Historial"]].map(([tab,lbl])=>(
          <button key={tab} onClick={()=>setTabActiva(tab)}
            style={{ padding:"8px 18px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
              background:tabActiva===tab?"#e65100":"#fff", color:tabActiva===tab?"#fff":"#4a5568",
              boxShadow:tabActiva===tab?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
            {lbl} {tab==="pedidos"&&pendientes.length>0&&<span style={{ background:tabActiva===tab?"rgba(255,255,255,.3)":"#fff3e0", color:tabActiva===tab?"#fff":"#e65100", borderRadius:10, padding:"0 6px", fontSize:11, fontWeight:700 }}>{pendientes.length}</span>}
          </button>
        ))}
      </div>

      {/* Tab: Lista de pedidos */}
      {tabActiva==="pedidos" && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px 24px" }}>
          <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:14 }}>📋 Cosas para pedir</div>
          <div style={{ display:"flex", gap:10, marginBottom:16 }}>
            <input value={nuevoPedItem} onChange={e=>setNuevoPedItem(e.target.value)}
              onKeyDown={e=>e.key==="Enter"&&agregarItem()}
              placeholder="Ej: Papel A4 120g, Vinilo blanco 1.52m..."
              style={{ flex:1, padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none" }}/>
            <button onClick={agregarItem} style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>+ Agregar</button>
          </div>
          {pendientes.length===0 ? (
            <div style={{ textAlign:"center", padding:"24px 0", color:"#d4bfb0", fontSize:13 }}>Sin pendientes — todo en orden 🎉</div>
          ) : pendientes.map(p=>(
            <div key={p.fireId} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 0", borderBottom:"1px solid #fef0e8" }}>
              <button onClick={()=>marcarConseguido(p)} style={{ width:22, height:22, borderRadius:5, border:"2px solid #e65100", background:"#fff", cursor:"pointer", flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", fontSize:12 }}>✓</button>
              <span style={{ flex:1, fontSize:14, color:"#1a2340", fontWeight:500 }}>{p.item}</span>
              <span style={{ fontSize:11, color:"#a09080" }}>{p.fecha}</span>
              <button onClick={()=>eliminarItem(p)} style={{ background:"transparent", border:"none", color:"#c62828", cursor:"pointer", fontSize:14 }}>✕</button>
            </div>
          ))}
        </div>
      )}

      {/* Tab: Facturas */}
      {tabActiva==="facturas" && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px 24px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
            <div style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>🧾 Facturas ({facturas.length})</div>
            <label style={{ background:"#e65100", color:"#fff", padding:"8px 16px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
              📷 Subir factura
              <input type="file" accept="image/*,application/pdf" onChange={subirFactura} style={{ display:"none" }}/>
            </label>
          </div>
          {facturas.length===0 ? (
            <div style={{ textAlign:"center", padding:"24px 0", color:"#d4bfb0", fontSize:13 }}>Sin facturas cargadas</div>
          ) : (
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(160px,1fr))", gap:12 }}>
              {facturas.map(f=>(
                <div key={f.fireId} style={{ borderRadius:10, border:"1.5px solid #f0d5c0", overflow:"hidden", cursor:"pointer" }}
                  onClick={()=>window.open(f.imagen,"_blank")}>
                  <img src={f.imagen} alt={f.nombre} style={{ width:"100%", height:120, objectFit:"cover" }}/>
                  <div style={{ padding:"8px 10px", background:"#fffaf7" }}>
                    <div style={{ fontSize:11, fontWeight:600, color:"#1a2340", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{f.nombre}</div>
                    <div style={{ fontSize:10, color:"#a09080", marginTop:2 }}>{f.fecha}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Historial */}
      {tabActiva==="historial" && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px 24px" }}>
          <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:14 }}>📦 Historial de pedidos conseguidos ({conseguidos.length})</div>
          {conseguidos.length===0 ? (
            <div style={{ textAlign:"center", padding:"24px 0", color:"#d4bfb0", fontSize:13 }}>Sin historial aún</div>
          ) : conseguidos.sort((a,b)=>b.fechaConseguido?.localeCompare(a.fechaConseguido||"")||0).map(p=>(
            <div key={p.fireId} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 0", borderBottom:"1px solid #fef0e8" }}>
              <span style={{ fontSize:16 }}>✅</span>
              <span style={{ flex:1, fontSize:14, color:"#4a5568", textDecoration:"line-through" }}>{p.item}</span>
              <div style={{ textAlign:"right", fontSize:11, color:"#a09080" }}>
                <div>Pedido: {p.fecha}</div>
                <div>Conseguido: {p.fechaConseguido||"—"}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Formulario Proveedor ──────────────────────────────────────────────────
function FormularioProveedor({ prov, setView, setSelected, showToast }) {
  const [form, setForm]     = useState(prov || { empresa:"", titular:"", cuit:"", direccion:"", telefono:"", mail:"" });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.empresa?.trim() && !form.titular?.trim()) { showToast("Ingresá al menos empresa o titular","error"); return; }
    setSaving(true);
    if (prov?.fireId) {
      await updateDoc(doc(db,"proveedores",prov.fireId), form);
      showToast("Proveedor actualizado ✅");
      setSelected(prov.fireId);
    } else {
      const ref = await addDoc(collection(db,"proveedores"), form);
      showToast("Proveedor creado ✅");
      setSelected(ref.id);
    }
    setSaving(false);
    setView("proveedores");
  };

  const inp = { width:"100%", padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", color:"#1a2340", outline:"none", boxSizing:"border-box" };

  return (
    <div>
      <button onClick={()=>setView("proveedores")} style={{ background:"transparent", border:"none", color:"#e65100", fontWeight:600, fontSize:14, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"32px 36px" }}>
        <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:24, fontWeight:700, color:"#1a2340", marginBottom:4 }}>{prov?"✏️ Editar Proveedor":"➕ Nuevo Proveedor"}</h2>
        <p style={{ fontSize:14, color:"#a09080", marginBottom:24 }}>Datos del proveedor.</p>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
          <div style={{ gridColumn:"1 / -1" }}>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Empresa / Nombre comercial *</label>
            <input value={form.empresa} onChange={e=>setForm(f=>({...f,empresa:e.target.value}))} placeholder="Ej: Distribuidora Sur" style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Titular / Contacto</label>
            <input value={form.titular} onChange={e=>setForm(f=>({...f,titular:e.target.value}))} placeholder="Nombre y apellido" style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>CUIT</label>
            <input value={form.cuit} onChange={e=>setForm(f=>({...f,cuit:e.target.value}))} placeholder="XX-XXXXXXXX-X" style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Teléfono</label>
            <input value={form.telefono} onChange={e=>setForm(f=>({...f,telefono:e.target.value}))} placeholder="11-xxxx-xxxx" style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Mail</label>
            <input value={form.mail} onChange={e=>setForm(f=>({...f,mail:e.target.value}))} placeholder="proveedor@mail.com" style={inp}/>
          </div>
          <div style={{ gridColumn:"1 / -1" }}>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Dirección</label>
            <input value={form.direccion} onChange={e=>setForm(f=>({...f,direccion:e.target.value}))} placeholder="Calle, número, ciudad" style={inp}/>
          </div>
        </div>
        <div style={{ display:"flex", justifyContent:"flex-end", gap:10, marginTop:28 }}>
          <button onClick={()=>setView("proveedores")} style={{ padding:"10px 22px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={handleSave} disabled={saving}
            style={{ padding:"10px 28px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer", opacity:saving?.7:1 }}>
            {saving?"Guardando...":prov?"💾 Guardar Cambios":"✅ Crear Proveedor"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Componente: Historial de Ventas ───────────────────────────────────────
function VentasView({ setView, showToast, clientes, empresa, configCargada }) {
  const [ventas, setVentas]           = useState([]);
  const [presupuestos, setPresupuestos] = useState([]);
  const [loading, setLoading]         = useState(true);
  const [busq, setBusq]               = useState("");
  const [filtroFecha, setFiltroFecha] = useState("hoy");
  const [tabActiva, setTabActiva]     = useState("ventas"); // ventas | presupuestos
  const [convirtiendo, setConvirtiendo] = useState(null);

  useEffect(() => {
    const u1 = onSnapshot(collection(db, "ventas"), snap => {
      setVentas(snap.docs.map(d=>({...d.data(), fireId:d.id}))
        .sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0));
      setLoading(false);
    });
    const u2 = onSnapshot(collection(db, "presupuestos"), snap => {
      setPresupuestos(snap.docs.map(d=>({...d.data(), fireId:d.id}))
        .sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0));
    });
    return () => { u1(); u2(); };
  }, []);

  const hoy = new Date().toISOString().split("T")[0];

  const filtradas = ventas.filter(v => {
    const q = busq.toLowerCase();
    const matchBusq = !busq || v.clienteNombre?.toLowerCase().includes(q) || v.numero?.toString().includes(q);
    if (filtroFecha==="hoy")    return matchBusq && v.fecha===hoy;
    if (filtroFecha==="semana") { const d=new Date(); d.setDate(d.getDate()-7); return matchBusq && v.fecha>=d.toISOString().split("T")[0]; }
    if (filtroFecha==="mes")    return matchBusq && v.fecha?.startsWith(hoy.slice(0,7));
    return matchBusq;
  });

  const presFiltrados = presupuestos.filter(p => {
    const q = busq.toLowerCase();
    return !busq || p.clienteNombre?.toLowerCase().includes(q) || p.numero?.toString().includes(q);
  });

  const totalFiltrado = filtradas.reduce((s,v)=>s+parseFloat(v.total||0),0);

  const handleDelete = async (v) => {
    if (!window.confirm("¿Eliminar esta venta?")) return;
    await deleteDoc(doc(db, "ventas", v.fireId));
    showToast("Venta eliminada", "error");
  };

  const handleDeletePres = async (p) => {
    if (!window.confirm("¿Eliminar este presupuesto?")) return;
    await deleteDoc(doc(db, "presupuestos", p.fireId));
    showToast("Presupuesto eliminado", "error");
  };

  const handleReimprimir = (p) => {
    imprimirPresupuesto(p, empresa);
  };

  const handleConvertirVenta = async (pres, metodoPago) => {
    setConvirtiendo(null);
    try {
      const snap = await getDocs(collection(db, "ventas"));
      const numero = snap.size + 1;
      const venta = {
        numero,
        fecha:         hoy,
        clienteId:     pres.clienteId||null,
        clienteNombre: pres.clienteNombre||"Consumidor Final",
        metodoPago,
        items:         pres.items,
        total:         pres.total,
        creadoEn:      new Date().toISOString(),
        origen:        "presupuesto",
        presupuestoId: pres.fireId,
      };
      await addDoc(collection(db, "ventas"), venta);
      // Marcar presupuesto como convertido
      await updateDoc(doc(db, "presupuestos", pres.fireId), { estado:"convertido", ventaId: pres.fireId });
      // Descontar stock
      if (pres.items) {
        for (const it of pres.items) {
          if (it.insumoId && !it.esLibre) {
            const insSnap = await getDoc(doc(db, "insumos", it.insumoId)).catch(()=>null);
            if (insSnap?.exists()) {
              const nuevoStock = Math.max(0, (parseFloat(insSnap.data().stock)||0) - it.cantidad);
              await updateDoc(doc(db, "insumos", it.insumoId), { stock: nuevoStock });
            }
          }
        }
      }
      showToast(`✅ Presupuesto convertido a venta · $${parseFloat(pres.total).toLocaleString("es-AR")}`);
      setTimeout(() => imprimirComprobante(venta, empresa), 400);
      setTabActiva("ventas");
    } catch(e) {
      console.error(e);
      showToast("Error al convertir", "error");
    }
  };

  const estadoPres = (p) => {
    if (p.estado==="convertido") return { label:"✅ Convertido", bg:"#e8f5e9", color:"#2e7d32" };
    // Verificar vencimiento (7 días)
    const fechaPres = new Date(p.fecha);
    const diff = (new Date() - fechaPres) / (1000*60*60*24);
    if (diff > 7) return { label:"⏰ Vencido", bg:"#ffebee", color:"#c62828" };
    return { label:"⏳ Pendiente", bg:"#fff3e0", color:"#e65100" };
  };

  return (
    <div>
      {/* Tabs */}
      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        <button onClick={()=>setTabActiva("ventas")}
          style={{ padding:"9px 20px", borderRadius:20, fontSize:14, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
            background:tabActiva==="ventas"?"#e65100":"#fff", color:tabActiva==="ventas"?"#fff":"#4a5568",
            boxShadow:tabActiva==="ventas"?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
          💰 Ventas
          {filtradas.length>0 && tabActiva!=="ventas" && <span style={{ marginLeft:6, background:"#fff3e0", color:"#e65100", borderRadius:20, padding:"1px 7px", fontSize:12, fontWeight:700 }}>{filtradas.length}</span>}
        </button>
        <button onClick={()=>setTabActiva("presupuestos")}
          style={{ padding:"9px 20px", borderRadius:20, fontSize:14, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
            background:tabActiva==="presupuestos"?"#1a2340":"#fff", color:tabActiva==="presupuestos"?"#fff":"#4a5568",
            boxShadow:tabActiva==="presupuestos"?"0 3px 10px rgba(26,35,64,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
          📋 Presupuestos
          {presupuestos.filter(p=>p.estado!=="convertido").length>0 && (
            <span style={{ marginLeft:6, background:tabActiva==="presupuestos"?"rgba(255,255,255,.2)":"#f0f3f9", color:tabActiva==="presupuestos"?"#fff":"#4a5568", borderRadius:20, padding:"1px 7px", fontSize:12, fontWeight:700 }}>
              {presupuestos.filter(p=>p.estado!=="convertido").length}
            </span>
          )}
        </button>
      </div>

      {/* ── TAB VENTAS ── */}
      {tabActiva==="ventas" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16, flexWrap:"wrap", gap:10 }}>
            <p style={{ fontSize:14, color:"#a09080" }}>{filtradas.length} venta{filtradas.length!==1?"s":""} · Total: <strong style={{color:"#e65100"}}>${totalFiltrado.toLocaleString("es-AR")}</strong></p>
          </div>

          {/* Filtros */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18, display:"flex", gap:12, flexWrap:"wrap", alignItems:"center" }}>
            <div style={{ position:"relative", flex:"1 1 200px" }}>
              <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)" }}>🔍</span>
              <input placeholder="Buscar por cliente o número..." value={busq} onChange={e=>setBusq(e.target.value)}
                style={{ width:"100%", padding:"10px 14px 10px 32px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
            </div>
            {["hoy","semana","mes","todos"].map(f => (
              <button key={f} onClick={() => setFiltroFecha(f)}
                style={{ padding:"8px 16px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
                  background:filtroFecha===f?"#e65100":"#fff8f5", color:filtroFecha===f?"#fff":"#a09080",
                  boxShadow:filtroFecha===f?"0 3px 10px rgba(230,81,0,.2)":"none" }}>
                {f==="hoy"?"Hoy":f==="semana"?"Esta semana":f==="mes"?"Este mes":"Todas"}
              </button>
            ))}
          </div>

          {loading ? (
            <div style={{ textAlign:"center", padding:40, color:"#a09080" }}>Cargando ventas...</div>
          ) : filtradas.length === 0 ? (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px 24px", textAlign:"center" }}>
              <div style={{ fontSize:40, marginBottom:14 }}>💰</div>
              <div style={{ fontWeight:700, fontSize:18, marginBottom:6 }}>Sin ventas {filtroFecha==="hoy"?"hoy":filtroFecha==="semana"?"esta semana":filtroFecha==="mes"?"este mes":""}</div>
              <div style={{ color:"#a09080", fontSize:14 }}>Registrá una nueva venta con el botón de arriba</div>
            </div>
          ) : (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
                <thead><tr style={{ background:"#fffaf7" }}>
                  {["N°","Fecha","Cliente","Items","Método","Total",""].map(h=>(
                    <th key={h} style={{ padding:"11px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0" }}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>
                  {filtradas.map(v=>(
                    <tr key={v.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                      <td style={{ padding:"11px 16px", color:"#a09080", fontFamily:"monospace", fontSize:12 }}>X-{String(v.numero||1).padStart(5,"0")}</td>
                      <td style={{ padding:"11px 16px", color:"#4a5568" }}>{v.fecha}</td>
                      <td style={{ padding:"11px 16px", fontWeight:600, color:"#1a2340" }}>
                        {v.clienteNombre||"Consumidor Final"}
                        {v.origen==="pedido" && <span style={{ marginLeft:6, background:"#e8eaf6", color:"#3949ab", padding:"1px 6px", borderRadius:10, fontSize:10, fontWeight:700 }}>PEDIDO</span>}
                        {v.origen==="presupuesto" && <span style={{ marginLeft:6, background:"#e8f5e9", color:"#2e7d32", padding:"1px 6px", borderRadius:10, fontSize:10, fontWeight:700 }}>PRES.</span>}
                      </td>
                      <td style={{ padding:"11px 16px", color:"#4a5568", maxWidth:200, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                        {v.items?.map(i=>`${i.cantidad}x ${i.nombre}`).join(", ")||"—"}
                      </td>
                      <td style={{ padding:"11px 16px" }}>
                        <span style={{ background:"#fff3e0", color:"#e65100", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{v.metodoPago}</span>
                      </td>
                      <td style={{ padding:"11px 16px", fontWeight:800, color:"#e65100", fontSize:15 }}>${parseFloat(v.total||0).toLocaleString("es-AR")}</td>
                      <td style={{ padding:"11px 14px" }}>
                        <div style={{ display:"flex", gap:6 }}>
                          <button onClick={() => imprimirComprobante(v, empresa)}
                            style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"5px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🖨️</button>
                          <button onClick={() => handleDelete(v)}
                            style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"5px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── TAB PRESUPUESTOS ── */}
      {tabActiva==="presupuestos" && (
        <div>
          <div style={{ marginBottom:16 }}>
            <p style={{ fontSize:14, color:"#a09080" }}>{presupuestos.length} presupuesto{presupuestos.length!==1?"s":""} · {presupuestos.filter(p=>p.estado!=="convertido").length} pendiente{presupuestos.filter(p=>p.estado!=="convertido").length!==1?"s":""}</p>
          </div>

          {/* Buscador */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18 }}>
            <div style={{ position:"relative" }}>
              <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)" }}>🔍</span>
              <input placeholder="Buscar por cliente o número..." value={busq} onChange={e=>setBusq(e.target.value)}
                style={{ width:"100%", padding:"10px 14px 10px 32px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
            </div>
          </div>

          {presFiltrados.length===0 ? (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px 24px", textAlign:"center" }}>
              <div style={{ fontSize:40, marginBottom:14 }}>📋</div>
              <div style={{ fontWeight:700, fontSize:18, marginBottom:6 }}>Sin presupuestos</div>
              <div style={{ color:"#a09080", fontSize:14 }}>Generá un presupuesto desde Nueva Venta</div>
            </div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              {presFiltrados.map(p => {
                const est = estadoPres(p);
                return (
                  <div key={p.fireId} style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 22px" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", gap:12, flexWrap:"wrap" }}>
                      <div style={{ flex:1 }}>
                        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:6 }}>
                          <span style={{ fontFamily:"monospace", fontSize:12, color:"#a09080" }}>P-{String(p.numero||1).padStart(5,"0")}</span>
                          <span style={{ background:est.bg, color:est.color, padding:"2px 10px", borderRadius:20, fontSize:11, fontWeight:700 }}>{est.label}</span>
                        </div>
                        <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:4 }}>{p.clienteNombre||"Consumidor Final"}</div>
                        <div style={{ fontSize:12, color:"#a09080", marginBottom:8 }}>
                          {p.fecha} · {p.items?.length||0} item{p.items?.length!==1?"s":""}
                        </div>
                        {/* Items */}
                        <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                          {p.items?.slice(0,4).map((it,i)=>(
                            <span key={i} style={{ background:"#f0f3f9", color:"#4a5568", padding:"2px 8px", borderRadius:20, fontSize:11 }}>
                              {it.cantidad}× {it.nombre.length>25?it.nombre.slice(0,25)+"...":it.nombre}
                            </span>
                          ))}
                          {p.items?.length>4 && <span style={{ background:"#f0f3f9", color:"#a09080", padding:"2px 8px", borderRadius:20, fontSize:11 }}>+{p.items.length-4} más</span>}
                        </div>
                      </div>
                      <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:10 }}>
                        <div style={{ fontWeight:800, fontSize:22, color:"#1a2340" }}>${parseFloat(p.total||0).toLocaleString("es-AR")}</div>
                        <div style={{ display:"flex", gap:8 }}>
                          <button onClick={()=>handleReimprimir(p)}
                            style={{ background:"#f0f3f9", border:"none", color:"#4a5568", padding:"7px 12px", borderRadius:8, fontSize:12, fontWeight:600, cursor:"pointer" }}>
                            🖨️ Reimprimir
                          </button>
                          <button onClick={()=>handleDeletePres(p)}
                            style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"7px 10px", borderRadius:8, fontSize:12, cursor:"pointer" }}>🗑</button>
                          {p.estado!=="convertido" && (
                            <button onClick={()=>setConvirtiendo(p)}
                              style={{ background:"#e65100", color:"#fff", border:"none", padding:"7px 14px", borderRadius:8, fontSize:12, fontWeight:700, cursor:"pointer" }}>
                              ✅ Convertir a venta
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Modal: elegir método de pago al convertir */}
      {convirtiendo && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={()=>setConvirtiendo(null)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:400, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:18, color:"#1a2340", marginBottom:6 }}>✅ Convertir a venta</div>
            <div style={{ fontSize:13, color:"#a09080", marginBottom:20 }}>
              {convirtiendo.clienteNombre} · <strong style={{color:"#e65100"}}>${parseFloat(convirtiendo.total).toLocaleString("es-AR")}</strong>
            </div>
            <div style={{ fontWeight:600, fontSize:13, color:"#4a5568", marginBottom:12 }}>Método de pago:</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:20 }}>
              {getMetodosPago().map(x=>x.nombre).map(m=>(
                <button key={m} onClick={()=>handleConvertirVenta(convirtiendo, m)}
                  style={{ padding:"12px 8px", borderRadius:8, border:"1.5px solid #f0d5c0", background:"#fff", fontSize:12, fontWeight:600, cursor:"pointer", color:"#1a2340", transition:"all .15s" }}
                  onMouseOver={e=>{e.currentTarget.style.background="#fff8f5";e.currentTarget.style.borderColor="#e65100";}}
                  onMouseOut={e=>{e.currentTarget.style.background="#fff";e.currentTarget.style.borderColor="#f0d5c0";}}>
                  {labelMetodo(m)}
                </button>
              ))}
            </div>
            <button onClick={()=>setConvirtiendo(null)} style={{ width:"100%", padding:"10px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Componente: Nueva Venta ───────────────────────────────────────────────
function NuevaVentaView({ setView, showToast, clientes, empresa, configCargada }) {
  const [insumos, setInsumos]           = useState([]);
  const [items, setItems]               = useState([]);
  const [busqProd, setBusqProd]         = useState("");
  const [clienteSearch, setClienteSearch] = useState("");
  const [clienteDropdown, setClienteDropdown] = useState(false);
  const [clienteSelId, setClienteSelId] = useState(null);
  const [clienteNombre, setClienteNombre] = useState("");
  const [metodoPago, setMetodoPago]     = useState("Efectivo");
  const [saving, setSaving]             = useState(false);
  const [tipoPrecios, setTipoPrecios]   = useState("venta"); // venta | gremio
  const [itemLibreNombre, setItemLibreNombre] = useState("");
  const [itemLibrePrecio, setItemLibrePrecio] = useState("");
  const [modalAgendarVenta, setModalAgendarVenta] = useState(false);
  const [ordenVenta, setOrdenVenta]     = useState("popular"); // popular | nombre | precio_asc | precio_desc
  const [ventasData, setVentasData]     = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "insumos"), snap => {
      setInsumos(snap.docs.map(d=>({...d.data(), fireId:d.id})));
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    // Cargar ventas para calcular popularidad
    getDocs(collection(db, "ventas")).then(snap => {
      setVentasData(snap.docs.map(d=>d.data()));
    });
  }, []);

  // Calcular popularidad: cuántas veces se vendió cada insumo
  const popularidad = useMemo(() => {
    const map = {};
    ventasData.forEach(v => {
      (v.items||[]).forEach(it => {
        if (it.insumoId) map[it.insumoId] = (map[it.insumoId]||0) + (it.cantidad||1);
      });
    });
    return map;
  }, [ventasData]);

  const prodFiltrados = useMemo(() => {
    const filtrados = insumos.filter(i => {
      if (!busqProd) return true;
      const palabras = busqProd.toLowerCase().split(/\s+/).filter(Boolean);
      const texto = `${i.nombre||""} ${i.codigo||""} ${i.categoria||""}`.toLowerCase();
      return palabras.every(p => texto.includes(p));
    });

    return filtrados.sort((a, b) => {
      if (ordenVenta === "popular") {
        const diff = (popularidad[b.fireId]||0) - (popularidad[a.fireId]||0);
        return diff !== 0 ? diff : (a.nombre||"").localeCompare(b.nombre||"");
      }
      if (ordenVenta === "nombre") return (a.nombre||"").localeCompare(b.nombre||"");
      const pa = parseFloat(a.precioVenta||0);
      const pb = parseFloat(b.precioVenta||0);
      if (ordenVenta === "precio_asc")  return pa - pb;
      if (ordenVenta === "precio_desc") return pb - pa;
      return 0;
    }).slice(0, 80);
  }, [insumos, busqProd, ordenVenta, popularidad]);

  const agregarItem = (ins) => {
    setItems(prev => {
      const existe = prev.find(it => it.insumoId === ins.fireId);
      if (existe) return prev.map(it => it.insumoId===ins.fireId ? {...it, cantidad:it.cantidad+1} : it);
      const precio = tipoPrecios==="gremio" ? (parseFloat(ins.precioGremio)||parseFloat(ins.precioVenta)||0) : (parseFloat(ins.precioVenta)||0);
      return [...prev, { insumoId:ins.fireId, codigo:ins.codigo||"", nombre:ins.nombre, precio, cantidad:1, stockDisp:parseFloat(ins.stock)||0 }];
    });
  };

  const updateCantidad = (insumoId, val) => {
    const n = Math.max(1, parseInt(val)||1);
    setItems(prev => prev.map(it => it.insumoId===insumoId ? {...it, cantidad:n} : it));
  };

  const removeItem = (insumoId) => setItems(prev => prev.filter(it => it.insumoId!==insumoId));

  const updatePrecio = (insumoId, val) => {
    const n = Math.max(0, parseFloat(val)||0);
    setItems(prev => prev.map(it => it.insumoId===insumoId ? {...it, precio:n} : it));
  };

  const total = items.reduce((s,it)=>s+it.cantidad*it.precio, 0);

  const handleGuardar = async () => {
    if (items.length===0) { showToast("Agregá al menos un producto", "error"); return; }
    setSaving(true);
    try {
      // Obtener número correlativo
      const ventasSnap = await import("firebase/firestore").then(m =>
        m.getDocs(m.collection(db, "ventas"))
      );
      const numero = ventasSnap.size + 1;

      // Guardar venta
      const venta = {
        numero,
        fecha:         new Date().toISOString().split("T")[0],
        clienteId:     clienteSelId||null,
        clienteNombre: clienteNombre||"Consumidor Final",
        metodoPago,
        items,
        total,
        creadoEn:      new Date().toISOString(),
      };
      await addDoc(collection(db, "ventas"), venta);

      // Descontar stock de cada insumo
      for (const it of items) {
        const ins = insumos.find(i => i.fireId===it.insumoId);
        if (ins) {
          const nuevoStock = Math.max(0, (parseFloat(ins.stock)||0) - it.cantidad);
          await updateDoc(doc(db, "insumos", ins.fireId), { stock: nuevoStock });
        }
      }

      // Si es cuenta corriente, sumar al saldo del cliente
      if (metodoPago==="Cuenta Corriente" && clienteSelId) {
        const cl = clientes.find(c=>c.fireId===clienteSelId);
        if (cl) {
          const nuevoSaldo = (parseFloat(cl.saldoCuenta)||0) + total;
          await updateDoc(doc(db, "clientes", clienteSelId), { saldoCuenta: nuevoSaldo });
          await addDoc(collection(db, "movimientosCuenta"), {
            clienteId: clienteSelId,
            tipo: "cargo",
            monto: total,
            fecha: new Date().toISOString().split("T")[0],
            descripcion: `Venta X-${String(numero).padStart(5,"0")}`
          });
        }
      }

      showToast(`Venta registrada ✅ · $${total.toLocaleString("es-AR")}`);

      // Imprimir comprobante
      setTimeout(() => imprimirComprobante(venta, empresa), 400);
      setView("ventas");
    } catch(e) {
      console.error(e);
      showToast("Error al guardar la venta", "error");
    }
    setSaving(false);
  };

  const handlePresupuesto = async () => {
    if (items.length===0) { showToast("Agregá al menos un producto", "error"); return; }
    setSaving(true);
    try {
      const numero = await getNextNroPresupuesto();
      const pres = {
        numero,
        fecha:         new Date().toISOString().split("T")[0],
        clienteId:     clienteSelId||null,
        clienteNombre: clienteNombre||"Consumidor Final",
        metodoPago,
        validezDias:   parseInt(APP_CFG.validezPresupuesto)||7,
        items,
        total,
        creadoEn:      new Date().toISOString(),
        estado:        "emitido",
      };
      await addDoc(collection(db, "presupuestos"), pres);
      // Si hay cliente, guardar en historial del cliente
      if (clienteSelId) {
        await addDoc(collection(db, "movimientosCuenta"), {
          clienteId: clienteSelId,
          tipo: "presupuesto",
          monto: total,
          fecha: new Date().toISOString().split("T")[0],
          descripcion: `Presupuesto P-${String(numero).padStart(5,"0")}`,
        });
      }
      showToast(`Presupuesto guardado ✅ · $${total.toLocaleString("es-AR")}`);
      setTimeout(() => imprimirPresupuesto(pres, empresa), 400);
      setView("ventas");
    } catch(e) {
      console.error(e);
      showToast("Error al generar presupuesto", "error");
    }
    setSaving(false);
  };

  const handleAgendarVenta = async (fechaEntrega, categoria, notas) => {
    if (items.length===0) return;
    const desc = items.map(it=>`${it.cantidad}x ${it.nombre} $${(it.cantidad*it.precio).toLocaleString("es-AR")}`).join("\n");
    const notaFinal = [notas, desc].filter(Boolean).join("\n---\n");
    const snap = await getDocs(collection(db,"pedidos"));
    const maxId = Math.max(...snap.docs.map(d=>d.data().id||0), 0);
    const nuevoPedido = {
      id:          maxId + 1,
      nombre:      items.length===1 ? items[0].nombre : `Pedido de ${clienteNombre||"cliente"} (${items.length} items)`,
      cliente:     clienteNombre || "Consumidor Final",
      clienteId:   clienteSelId || null,
      telefono:    "",
      categoria:   categoria || "Otros",
      estado:      "Pendiente",
      precio:      total,
      seña:        0,
      fechaPedido: new Date().toISOString().split("T")[0],
      fechaEntrega,
      notas:       notaFinal,
      itemsVenta:  items,
    };
    await addDoc(collection(db,"pedidos"), nuevoPedido);
    showToast("✅ Pedido creado desde la venta");
    setModalAgendarVenta(false);
    setView("lista");
  };

  const agregarItemLibre = () => {
    if (!itemLibreNombre.trim()) { showToast("Ingresá un nombre para el ítem", "error"); return; }
    const precio = parseFloat(itemLibrePrecio)||0;
    const id = `libre_${Date.now()}`;
    setItems(prev => [...prev, { insumoId:id, codigo:"CUSTOM", nombre:itemLibreNombre.trim(), precio, cantidad:1, stockDisp:999, esLibre:true }]);
    setItemLibreNombre("");
    setItemLibrePrecio("");
    showToast("Ítem personalizado agregado ✅");
  };

  return (
    <div>
      <button onClick={() => setView("ventas")} style={{ background:"transparent", border:"none", color:"#e65100", fontWeight:600, fontSize:14, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>

      <div className="grid-nueva-venta">

        {/* ── Columna izquierda: productos ── */}
        <div>
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px", marginBottom:16 }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
              <div style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>🔍 Productos</div>
              <div style={{ display:"flex", gap:6 }}>
                {[["venta","Precio Venta"],["gremio","Precio Gremio"]].map(([val,lbl]) => (
                  <button key={val} onClick={()=>setTipoPrecios(val)}
                    style={{ padding:"5px 12px", borderRadius:20, fontSize:12, fontWeight:600, cursor:"pointer", border:"none",
                      background:tipoPrecios===val?"#e65100":"#fff8f5", color:tipoPrecios===val?"#fff":"#a09080" }}>
                    {lbl}
                  </button>
                ))}
              </div>
            </div>
            <input placeholder="Buscar por nombre o código..." value={busqProd} onChange={e=>setBusqProd(e.target.value)}
              style={{ width:"100%", padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box", marginBottom:10 }}/>
            {/* Ordenamiento */}
            <div style={{ display:"flex", gap:6, marginBottom:14, flexWrap:"wrap" }}>
              <span style={{ fontSize:11, color:"#a09080", fontWeight:600, alignSelf:"center", marginRight:2 }}>Ordenar:</span>
              {[
                ["popular","⭐ Más vendidos"],
                ["nombre","🔤 A-Z"],
                ["precio_asc","💲 Menor precio"],
                ["precio_desc","💲 Mayor precio"],
              ].map(([val,lbl])=>(
                <button key={val} onClick={()=>setOrdenVenta(val)}
                  style={{ padding:"4px 11px", borderRadius:20, fontSize:11, fontWeight:600, cursor:"pointer", border:"none",
                    background:ordenVenta===val?"#1a2340":"#f0f3f9",
                    color:ordenVenta===val?"#fff":"#4a5568", transition:"all .15s" }}>
                  {lbl}
                </button>
              ))}
            </div>
            <div style={{ maxHeight:420, overflowY:"auto", display:"flex", flexDirection:"column", gap:6 }}>
              {prodFiltrados.length===0 ? (
                <div style={{ textAlign:"center", padding:"24px 0", color:"#a09080", fontSize:13 }}>Sin productos{busqProd?" con ese criterio":""}</div>
              ) : prodFiltrados.map(ins => {
                const precio = tipoPrecios==="gremio" ? (parseFloat(ins.precioGremio)||parseFloat(ins.precioVenta)||0) : (parseFloat(ins.precioVenta)||0);
                const enCarrito = items.find(it=>it.insumoId===ins.fireId);
                return (
                  <div key={ins.fireId} onClick={() => agregarItem(ins)}
                    style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 14px", borderRadius:9, border:`1.5px solid ${enCarrito?"#e65100":"#f0d5c0"}`, background:enCarrito?"#fff8f5":"#fff", cursor:"pointer", transition:"all .15s" }}
                    onMouseOver={e=>e.currentTarget.style.borderColor="#e65100"}
                    onMouseOut={e=>{ if(!enCarrito) e.currentTarget.style.borderColor="#f0d5c0"; }}>
                    <div>
                      <div style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{ins.nombre}</div>
                      <div style={{ fontSize:11, color:"#a09080", marginTop:2 }}>{ins.codigo||""} {ins.categoria?`· ${ins.categoria}`:""} · Stock: {parseFloat(ins.stock)||0}</div>
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      <span style={{ fontWeight:700, color:"#e65100", fontSize:14 }}>${precio.toLocaleString("es-AR")}</span>
                      {enCarrito
                        ? <span style={{ background:"#e65100", color:"#fff", borderRadius:"50%", width:22, height:22, display:"inline-flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700 }}>{enCarrito.cantidad}</span>
                        : <span style={{ color:"#e65100", fontSize:18, fontWeight:300 }}>+</span>
                      }
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Ítem personalizado */}
            <div style={{ marginTop:14, borderTop:"1.5px dashed #f0d5c0", paddingTop:14 }}>
              <div style={{ fontSize:12, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:10 }}>✏️ Ítem personalizado</div>
              <div style={{ display:"flex", gap:8 }}>
                <input value={itemLibreNombre} onChange={e=>setItemLibreNombre(e.target.value)}
                  placeholder="Nombre del ítem..."
                  style={{ flex:2, padding:"9px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none" }}/>
                <input type="number" value={itemLibrePrecio} onChange={e=>setItemLibrePrecio(e.target.value)}
                  placeholder="Precio"
                  style={{ flex:1, padding:"9px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none" }}/>
                <button onClick={agregarItemLibre}
                  style={{ padding:"9px 16px", background:"#1a2340", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>
                  + Agregar
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ── Columna derecha: carrito + datos ── */}
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>

          {/* Cliente */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
            <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>👤 Cliente</div>
            {clienteSelId ? (
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", background:"#fff8f5", borderRadius:8, padding:"10px 14px", border:"1.5px solid #e65100" }}>
                <div style={{ fontWeight:600, fontSize:13 }}>{clienteNombre}</div>
                <button onClick={() => { setClienteSelId(null); setClienteNombre(""); setClienteSearch(""); }}
                  style={{ background:"transparent", border:"none", color:"#c62828", cursor:"pointer", fontSize:16, fontWeight:700 }}>✕</button>
              </div>
            ) : (
              <div style={{ position:"relative" }}>
                <input value={clienteSearch} onChange={e=>{ setClienteSearch(e.target.value); setClienteDropdown(true); }} onFocus={()=>setClienteDropdown(true)}
                  placeholder="Consumidor Final (dejar vacío)"
                  style={{ width:"100%", padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                {clienteDropdown && clienteSearch && (
                  <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:"1.5px solid #f0d5c0", borderRadius:8, boxShadow:"0 8px 24px rgba(230,81,0,.1)", zIndex:100, maxHeight:180, overflowY:"auto", marginTop:4 }}>
                    {clientes.filter(c=>`${c.nombre} ${c.apellido} ${c.empresa||""}`.toLowerCase().includes(clienteSearch.toLowerCase())).map(cl=>(
                      <div key={cl.fireId} onClick={()=>{ setClienteSelId(cl.fireId); setClienteNombre(`${cl.nombre} ${cl.apellido}`.trim()); setClienteDropdown(false); }}
                        style={{ padding:"9px 14px", cursor:"pointer", fontSize:13, fontWeight:600, borderBottom:"1px solid #fef0e8" }}
                        onMouseOver={e=>e.currentTarget.style.background="#fff8f5"}
                        onMouseOut={e=>e.currentTarget.style.background="#fff"}>
                        {cl.nombre} {cl.apellido} {cl.empresa&&`— ${cl.empresa}`}
                        {cl.saldoCuenta>0 && <span style={{ marginLeft:8, fontSize:11, color:"#c62828", fontWeight:700 }}>Debe ${parseFloat(cl.saldoCuenta).toLocaleString("es-AR")}</span>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Método de pago */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
            <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>💳 Método de Pago</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
              {getMetodosPago().map(x=>x.nombre).map(m=>(
                <button key={m} onClick={()=>setMetodoPago(m)}
                  style={{ padding:"10px 8px", borderRadius:8, fontSize:12, fontWeight:700, cursor:"pointer", border:`2px solid ${metodoPago===m?"#e65100":"#f0d5c0"}`,
                    background:metodoPago===m?"#e65100":"#fff", color:metodoPago===m?"#fff":"#4a5568", transition:"all .15s" }}>
                  {labelMetodo(m)}
                </button>
              ))}
            </div>
            {metodoPago==="Cuenta Corriente" && !clienteSelId && (
              <div style={{ marginTop:10, fontSize:12, color:"#c62828", background:"#ffebee", padding:"8px 12px", borderRadius:7 }}>
                ⚠️ Seleccioná un cliente para usar cuenta corriente
              </div>
            )}
          </div>

          {/* Carrito */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
            <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>🛒 Carrito ({items.length})</div>
            {items.length===0 ? (
              <div style={{ textAlign:"center", padding:"20px 0", color:"#d4bfb0", fontSize:13 }}>Hacé clic en un producto para agregarlo</div>
            ) : (
              <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:14 }}>
                {items.map(it=>(
                  <div key={it.insumoId} style={{ padding:"8px 10px", borderRadius:8, background: it.esLibre?"#f0f3f9":"#fffaf7", border:`1px solid ${it.esLibre?"#c5cce0":"#f5e8e0"}` }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:6 }}>
                      {it.esLibre
                        ? <input value={it.nombre} onChange={e=>setItems(prev=>prev.map(x=>x.insumoId===it.insumoId?{...x,nombre:e.target.value}:x))}
                            style={{ flex:1, fontSize:12, fontWeight:600, color:"#1a2340", border:"1.5px solid #c5cce0", borderRadius:5, padding:"3px 8px", fontFamily:"'DM Sans',sans-serif", outline:"none", background:"#fff" }}/>
                        : <div style={{ flex:1, fontSize:12, fontWeight:600, color:"#1a2340", lineHeight:1.3 }}>{it.nombre}</div>
                      }
                      <button onClick={()=>removeItem(it.insumoId)} style={{ background:"transparent", border:"none", color:"#c62828", cursor:"pointer", fontSize:14, fontWeight:700 }}>✕</button>
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                      {/* Cantidad */}
                      <div style={{ display:"flex", alignItems:"center", gap:4 }}>
                        <button onClick={()=>updateCantidad(it.insumoId,it.cantidad-1)} style={{ background:"#ffebee", border:"none", color:"#c62828", width:22, height:22, borderRadius:5, fontWeight:700, cursor:"pointer" }}>−</button>
                        <input type="number" value={it.cantidad} onChange={e=>updateCantidad(it.insumoId,e.target.value)}
                          style={{ width:38, textAlign:"center", border:"1.5px solid #f0d5c0", borderRadius:5, fontSize:12, fontWeight:700, padding:"2px 3px", fontFamily:"'DM Sans',sans-serif" }}/>
                        <button onClick={()=>updateCantidad(it.insumoId,it.cantidad+1)} style={{ background:"#e8f5e9", border:"none", color:"#2e7d32", width:22, height:22, borderRadius:5, fontWeight:700, cursor:"pointer" }}>+</button>
                      </div>
                      {/* Precio unitario editable */}
                      <div style={{ display:"flex", alignItems:"center", gap:4, flex:1 }}>
                        <span style={{ fontSize:11, color:"#a09080", whiteSpace:"nowrap" }}>$ p/u</span>
                        <input type="number" value={it.precio} onChange={e=>updatePrecio(it.insumoId,e.target.value)}
                          style={{ width:"100%", textAlign:"right", border:"1.5px solid #e65100", borderRadius:5, fontSize:12, fontWeight:700, padding:"3px 6px", fontFamily:"'DM Sans',sans-serif", color:"#e65100", background:"#fff8f5", outline:"none" }}/>
                      </div>
                      {/* Total item */}
                      <div style={{ fontSize:13, fontWeight:800, color:"#e65100", minWidth:65, textAlign:"right" }}>${(it.cantidad*it.precio).toLocaleString("es-AR")}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {/* Total */}
            <div style={{ borderTop:"2px solid #f5e8e0", paddingTop:14 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>TOTAL</span>
                <span style={{ fontFamily:"'DM Sans',sans-serif", fontSize:26, fontWeight:700, color:"#e65100" }}>${total.toLocaleString("es-AR")}</span>
              </div>
            </div>
          </div>

          {/* Botones confirmar + presupuesto + pedido */}
          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            <button onClick={handleGuardar} disabled={saving||items.length===0}
              style={{ width:"100%", padding:"15px", background: items.length===0?"#f0d5c0":"#e65100", color:"#fff", border:"none", borderRadius:10, fontSize:15, fontWeight:700, cursor:items.length===0?"not-allowed":"pointer", fontFamily:"'DM Sans',sans-serif", transition:"all .2s" }}>
              {saving ? "Guardando..." : !configCargada ? "⏳ Cargando..." : "✅ Confirmar Venta · Imprimir Comprobante"}
            </button>
            <button onClick={handlePresupuesto} disabled={saving||items.length===0}
              style={{ width:"100%", padding:"13px", background: items.length===0?"#f0f3f9":"#fff", color:items.length===0?"#a09080":"#1a2340", border:`2px solid ${items.length===0?"#e0e0e0":"#1a2340"}`, borderRadius:10, fontSize:14, fontWeight:700, cursor:items.length===0?"not-allowed":"pointer", fontFamily:"'DM Sans',sans-serif", transition:"all .2s" }}>
              📋 Generar Presupuesto
            </button>
            <button onClick={()=>setModalAgendarVenta(true)} disabled={items.length===0}
              style={{ width:"100%", padding:"13px", background: items.length===0?"#f0f3f9":"#e8eaf6", color:items.length===0?"#a09080":"#3949ab", border:`2px solid ${items.length===0?"#e0e0e0":"#3949ab"}`, borderRadius:10, fontSize:14, fontWeight:700, cursor:items.length===0?"not-allowed":"pointer", fontFamily:"'DM Sans',sans-serif", transition:"all .2s" }}>
              📅 Crear Pedido con fecha de entrega
            </button>
          </div>

          {/* Modal agendar como pedido */}
          {modalAgendarVenta && (
            <ModalAgendarVenta
              items={items}
              total={total}
              clienteNombre={clienteNombre}
              onConfirmar={handleAgendarVenta}
              onClose={()=>setModalAgendarVenta(false)}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// ── Contador correlativo de presupuestos ─────────────────────────────────
async function getNextNroPresupuesto() {
  const ref  = doc(db, "config", "contadores");
  const snap = await getDoc(ref);
  let actual = snap.exists() ? snap.data().nroPresupuesto : undefined;
  if (actual === undefined) {
    // Primera vez: arrancar desde el número más alto ya usado
    const pres = await getDocs(collection(db, "presupuestos"));
    actual = Math.max(0, ...pres.docs.map(d => parseInt(d.data().numero)||0));
  }
  const siguiente = actual + 1;
  await setDoc(ref, { nroPresupuesto: siguiente }, { merge: true });
  return siguiente;
}

const presNum = (p) => `P-${String(p.numero||0).padStart(5,"0")}`;
const presVence = (p) => {
  if (!p.fecha) return null;
  const d = new Date(p.fecha+"T12:00:00");
  d.setDate(d.getDate() + (parseInt(p.validezDias)||parseInt(APP_CFG.validezPresupuesto)||7));
  return d.toISOString().split("T")[0];
};

// ── Componente: Presupuestos ─────────────────────────────────────────────
function PresupuestosView({ showToast, clientes, empresa, setView, setSelectedPedido }) {
  const [tab, setTab]                 = useState("emitidos"); // nuevo | emitidos | aprobados
  const [presupuestos, setPresupuestos] = useState([]);
  const [editando, setEditando]       = useState(null);   // presupuesto en edición
  const [aprobando, setAprobando]     = useState(null);   // presupuesto a aprobar
  const [busq, setBusq]               = useState("");

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "presupuestos"), snap => {
      setPresupuestos(snap.docs.map(d => ({ ...d.data(), fireId:d.id }))
        .sort((a,b) => (b.numero||0) - (a.numero||0)));
    });
    return () => unsub();
  }, []);

  const esAprobado = p => p.estado === "aprobado" || p.estado === "convertido";
  const emitidos   = presupuestos.filter(p => !esAprobado(p));
  const aprobados  = presupuestos.filter(esAprobado);
  const hoy        = new Date().toISOString().split("T")[0];

  const filtrar = lista => lista.filter(p => {
    if (!busq) return true;
    const q = busq.toLowerCase();
    return `${presNum(p)} ${p.clienteNombre||""} ${(p.items||[]).map(i=>i.nombre).join(" ")}`.toLowerCase().includes(q);
  });

  const eliminar = async (p) => {
    if (!window.confirm(`¿Eliminar el presupuesto ${presNum(p)}?`)) return;
    await deleteDoc(doc(db, "presupuestos", p.fireId));
    showToast("Presupuesto eliminado", "error");
  };

  const abrirNuevo  = () => { setEditando(null); setTab("nuevo"); };
  const abrirEditar = (p) => { setEditando(p); setTab("nuevo"); };

  const tabBtn = (id, label, count) => (
    <button onClick={() => id==="nuevo" ? abrirNuevo() : setTab(id)}
      style={{ padding:"10px 20px", borderRadius:20, fontSize:14, fontWeight:700, cursor:"pointer", border:"none",
        fontFamily:"'DM Sans',sans-serif", display:"flex", alignItems:"center", gap:8,
        background: tab===id ? (id==="nuevo"?"#e65100":"#1a2340") : "#fff",
        color: tab===id ? "#fff" : (id==="nuevo"?"#e65100":"#4a5568"),
        boxShadow: tab===id ? "0 3px 10px rgba(26,35,64,.2)" : "0 1px 6px rgba(0,0,0,.06)" }}>
      {label}
      {count!==undefined && <span style={{ background: tab===id?"rgba(255,255,255,.25)":"#f0d5c0", borderRadius:10, padding:"1px 8px", fontSize:12 }}>{count}</span>}
    </button>
  );

  const Tabla = ({ lista, aprobada }) => (
    <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
      {lista.length===0 ? (
        <div style={{ padding:48, textAlign:"center", color:"#a09080", fontSize:14 }}>
          {aprobada ? "Todavía no hay presupuestos aprobados" : "No hay presupuestos emitidos"}
        </div>
      ) : (
        <div style={{ overflowX:"auto" }}>
        <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
          <thead><tr style={{ background:"#fff8f5" }}>
            {["N°","Fecha","Cliente","Detalle","Total", aprobada?"Entrega":"Validez",""].map(h=>(
              <th key={h} style={{ padding:"11px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".5px", borderBottom:"1px solid #f0d5c0", whiteSpace:"nowrap" }}>{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {lista.map(p => {
              const vence   = presVence(p);
              const vencido = !aprobada && vence && vence < hoy;
              const detalle = (p.items||[]).map(i=>`${i.cantidad}× ${i.nombre}`).join(", ");
              return (
                <tr key={p.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                  <td style={{ padding:"11px 14px", fontFamily:"monospace", fontWeight:700, color:"#1a2340", whiteSpace:"nowrap" }}>{presNum(p)}</td>
                  <td style={{ padding:"11px 14px", color:"#4a5568", whiteSpace:"nowrap" }}>{fmtFecha(p.fecha)}</td>
                  <td style={{ padding:"11px 14px", fontWeight:600, color:"#1a2340" }}>{p.clienteNombre||"Consumidor Final"}</td>
                  <td style={{ padding:"11px 14px", color:"#4a5568", maxWidth:260, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }} title={detalle}>{detalle||"—"}</td>
                  <td style={{ padding:"11px 14px", fontWeight:800, color:"#e65100", whiteSpace:"nowrap" }}>${parseFloat(p.total||0).toLocaleString("es-AR")}</td>
                  <td style={{ padding:"11px 14px", whiteSpace:"nowrap" }}>
                    {aprobada
                      ? (p.estado==="convertido"
                          ? <span style={{ fontSize:12, color:"#2e7d32", fontWeight:700 }}>💰 Vendido</span>
                          : <span style={{ fontWeight:600, color:"#1a2340" }}>{fmtFecha(p.fechaEntrega)}</span>)
                      : <span style={{ fontWeight:600, color:vencido?"#c62828":"#4a5568" }}>{vencido?"⚠️ Vencido ":""}{fmtFecha(vence)}</span>}
                  </td>
                  <td style={{ padding:"8px 12px" }}>
                    <div style={{ display:"flex", gap:6, justifyContent:"flex-end" }}>
                      <button title="Imprimir" onClick={()=>imprimirPresupuesto(p, empresa)}
                        style={{ background:"#e65100", border:"none", color:"#fff", padding:"6px 10px", borderRadius:7, cursor:"pointer", fontSize:13 }}>🖨️</button>
                      {!aprobada && <>
                        <button title="Editar" onClick={()=>abrirEditar(p)}
                          style={{ background:"#fff", border:"1.5px solid #e65100", color:"#e65100", padding:"5px 10px", borderRadius:7, cursor:"pointer", fontSize:13 }}>✏️</button>
                        <button title="Aprobar" onClick={()=>setAprobando(p)}
                          style={{ background:"#2e7d32", border:"none", color:"#fff", padding:"6px 12px", borderRadius:7, cursor:"pointer", fontSize:12, fontWeight:700, whiteSpace:"nowrap" }}>✅ Aprobar</button>
                        <button title="Eliminar" onClick={()=>eliminar(p)}
                          style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"6px 10px", borderRadius:7, cursor:"pointer", fontSize:13 }}>🗑</button>
                      </>}
                      {aprobada && p.pedidoFireId && setSelectedPedido && (
                        <button onClick={()=>{ setSelectedPedido({ fireId:p.pedidoFireId }); setView("detalle"); }}
                          style={{ background:"#1a2340", border:"none", color:"#fff", padding:"6px 12px", borderRadius:7, cursor:"pointer", fontSize:12, fontWeight:700, whiteSpace:"nowrap" }}>Ver pedido →</button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        </div>
      )}
    </div>
  );

  return (
    <div>
      <div style={{ display:"flex", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        {tabBtn("nuevo", editando ? "✏️ Editando presupuesto" : "➕ Nuevo Presupuesto")}
        {tabBtn("emitidos", "📋 Emitidos", emitidos.length)}
        {tabBtn("aprobados", "✅ Aprobados", aprobados.length)}
      </div>

      {tab!=="nuevo" && (
        <input value={busq} onChange={e=>setBusq(e.target.value)} placeholder="🔍 Buscar por número, cliente o producto..."
          style={{ width:"100%", padding:"11px 16px", borderRadius:10, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box", marginBottom:16 }}/>
      )}

      {tab==="nuevo" && (
        <PresupuestoEditor key={editando?.fireId||"nuevo"} presupuesto={editando} clientes={clientes} empresa={empresa} showToast={showToast}
          onSaved={() => { setEditando(null); setTab("emitidos"); }}
          onCancel={() => { setEditando(null); setTab("emitidos"); }}/>
      )}
      {tab==="emitidos"  && <Tabla lista={filtrar(emitidos)} aprobada={false}/>}
      {tab==="aprobados" && <Tabla lista={filtrar(aprobados)} aprobada={true}/>}

      {aprobando && (
        <ModalAprobarPresupuesto pres={aprobando} clientes={clientes} showToast={showToast}
          onClose={()=>setAprobando(null)}
          onDone={()=>{ setAprobando(null); setTab("aprobados"); }}/>
      )}
    </div>
  );
}

// ── Editor de presupuesto (nuevo / editar) ───────────────────────────────
function PresupuestoEditor({ presupuesto, clientes, empresa, showToast, onSaved, onCancel }) {
  const editMode = !!presupuesto;
  const hoy = new Date().toISOString().split("T")[0];
  const [insumos, setInsumos]           = useState([]);
  const [items, setItems]               = useState(presupuesto?.items || []);
  const [busqProd, setBusqProd]         = useState("");
  const [tipoPrecios, setTipoPrecios]   = useState("venta");
  const [clienteSearch, setClienteSearch] = useState("");
  const [clienteDropdown, setClienteDropdown] = useState(false);
  const [clienteSelId, setClienteSelId] = useState(presupuesto?.clienteId || null);
  const [clienteNombre, setClienteNombre] = useState(presupuesto?.clienteNombre && presupuesto.clienteNombre!=="Consumidor Final" ? presupuesto.clienteNombre : "");
  const [metodoPago, setMetodoPago]     = useState(presupuesto?.metodoPago || "Efectivo");
  const [validezDias, setValidezDias]   = useState(presupuesto?.validezDias || APP_CFG.validezPresupuesto || 7);
  const [tiempoEntrega, setTiempoEntrega] = useState(presupuesto?.tiempoEntrega || "");
  const [observaciones, setObservaciones] = useState(presupuesto?.observaciones || "");
  const [itemLibreNombre, setItemLibreNombre] = useState("");
  const [itemLibrePrecio, setItemLibrePrecio] = useState("");
  const [saving, setSaving]             = useState(false);
  const fecha = presupuesto?.fecha || hoy;

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "insumos"), snap =>
      setInsumos(snap.docs.map(d => ({ ...d.data(), fireId:d.id }))));
    return () => unsub();
  }, []);

  const prodFiltrados = useMemo(() => insumos.filter(i => {
    if (!busqProd) return true;
    const texto = `${i.nombre||""} ${i.codigo||""} ${i.categoria||""}`.toLowerCase();
    return busqProd.toLowerCase().split(/\s+/).filter(Boolean).every(p => texto.includes(p));
  }).sort((a,b)=>(a.nombre||"").localeCompare(b.nombre||"")).slice(0,80), [insumos, busqProd]);

  const precioDe = ins => tipoPrecios==="gremio"
    ? (parseFloat(ins.precioGremio)||parseFloat(ins.precioVenta)||0)
    : (parseFloat(ins.precioVenta)||0);

  const agregarItem = (ins) => setItems(prev => {
    const existe = prev.find(it => it.insumoId===ins.fireId);
    if (existe) return prev.map(it => it.insumoId===ins.fireId ? { ...it, cantidad:it.cantidad+1 } : it);
    return [...prev, { insumoId:ins.fireId, codigo:ins.codigo||"", nombre:ins.nombre, precio:precioDe(ins), cantidad:1 }];
  });
  const agregarItemLibre = () => {
    if (!itemLibreNombre.trim()) { showToast("Ingresá un nombre para el ítem","error"); return; }
    setItems(prev => [...prev, { insumoId:`libre_${Date.now()}`, codigo:"CUSTOM", nombre:itemLibreNombre.trim(), precio:parseFloat(itemLibrePrecio)||0, cantidad:1, esLibre:true }]);
    setItemLibreNombre(""); setItemLibrePrecio("");
  };
  const upd = (id, campo, val) => setItems(prev => prev.map(it => it.insumoId===id ? { ...it, [campo]:val } : it));
  const total = items.reduce((s,it) => s + it.cantidad*it.precio, 0);

  const guardar = async (imprimir) => {
    if (items.length===0) { showToast("Agregá al menos un producto","error"); return; }
    setSaving(true);
    try {
      const datos = {
        fecha,
        clienteId:     clienteSelId || null,
        clienteNombre: clienteNombre.trim() || "Consumidor Final",
        metodoPago, validezDias: parseInt(validezDias)||7,
        tiempoEntrega: tiempoEntrega.trim(),
        observaciones: observaciones.trim(),
        items, total,
      };
      let final;
      if (editMode) {
        await updateDoc(doc(db, "presupuestos", presupuesto.fireId), { ...datos, editadoEn:new Date().toISOString() });
        final = { ...presupuesto, ...datos };
        showToast(`Presupuesto ${presNum(final)} actualizado ✅`);
      } else {
        const numero = await getNextNroPresupuesto();
        final = { ...datos, numero, estado:"emitido", creadoEn:new Date().toISOString() };
        await addDoc(collection(db, "presupuestos"), final);
        showToast(`Presupuesto ${presNum(final)} guardado ✅`);
      }
      if (imprimir) setTimeout(() => imprimirPresupuesto(final, empresa), 300);
      onSaved();
    } catch(e) {
      console.error(e);
      showToast("Error al guardar el presupuesto","error");
    }
    setSaving(false);
  };

  const card = { background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" };
  const inp  = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };
  const lbl  = { display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 };

  return (
    <div className="grid-nueva-venta">
      {/* ── Izquierda: productos ── */}
      <div style={{ ...card, padding:20 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
          <div style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>🔍 Productos</div>
          <div style={{ display:"flex", gap:6 }}>
            {[["venta","Precio Venta"],["gremio","Precio Gremio"]].map(([v,l]) => (
              <button key={v} onClick={()=>setTipoPrecios(v)}
                style={{ padding:"5px 12px", borderRadius:20, fontSize:12, fontWeight:600, cursor:"pointer", border:"none",
                  background:tipoPrecios===v?"#e65100":"#fff8f5", color:tipoPrecios===v?"#fff":"#a09080" }}>{l}</button>
            ))}
          </div>
        </div>
        <input placeholder="Buscar por nombre o código..." value={busqProd} onChange={e=>setBusqProd(e.target.value)} style={{ ...inp, fontSize:14, marginBottom:12 }}/>
        <div style={{ maxHeight:420, overflowY:"auto", display:"flex", flexDirection:"column", gap:6 }}>
          {prodFiltrados.length===0
            ? <div style={{ textAlign:"center", padding:"24px 0", color:"#a09080", fontSize:13 }}>Sin productos</div>
            : prodFiltrados.map(ins => {
                const enCarrito = items.find(it => it.insumoId===ins.fireId);
                return (
                  <div key={ins.fireId} onClick={()=>agregarItem(ins)}
                    style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 14px", borderRadius:9, cursor:"pointer",
                      border:`1.5px solid ${enCarrito?"#e65100":"#f0d5c0"}`, background:enCarrito?"#fff8f5":"#fff" }}>
                    <div>
                      <div style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{ins.nombre}</div>
                      <div style={{ fontSize:11, color:"#a09080", marginTop:2 }}>{ins.codigo||""} {ins.categoria?`· ${ins.categoria}`:""}</div>
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                      <span style={{ fontWeight:700, color:"#e65100", fontSize:14 }}>${precioDe(ins).toLocaleString("es-AR")}</span>
                      {enCarrito
                        ? <span style={{ background:"#e65100", color:"#fff", borderRadius:"50%", width:22, height:22, display:"inline-flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700 }}>{enCarrito.cantidad}</span>
                        : <span style={{ color:"#e65100", fontSize:18, fontWeight:300 }}>+</span>}
                    </div>
                  </div>
                );
              })}
        </div>
        <div style={{ marginTop:14, borderTop:"1.5px dashed #f0d5c0", paddingTop:14 }}>
          <div style={{ fontSize:12, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:10 }}>✏️ Ítem personalizado</div>
          <div style={{ display:"flex", gap:8 }}>
            <input value={itemLibreNombre} onChange={e=>setItemLibreNombre(e.target.value)} placeholder="Nombre del ítem..."
              onKeyDown={e=>{ if(e.key==="Enter") agregarItemLibre(); }} style={{ ...inp, flex:2 }}/>
            <input type="number" value={itemLibrePrecio} onChange={e=>setItemLibrePrecio(e.target.value)} placeholder="Precio"
              onKeyDown={e=>{ if(e.key==="Enter") agregarItemLibre(); }} style={{ ...inp, flex:1 }}/>
            <button onClick={agregarItemLibre}
              style={{ padding:"9px 16px", background:"#1a2340", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap" }}>+ Agregar</button>
          </div>
        </div>
      </div>

      {/* ── Derecha: datos + carrito ── */}
      <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
        {editMode && (
          <div style={{ background:"#1a2340", color:"#fff", borderRadius:10, padding:"10px 16px", fontSize:13, fontWeight:700 }}>
            ✏️ Editando {presNum(presupuesto)}
          </div>
        )}

        {/* Cliente */}
        <div style={card}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>👤 Cliente</div>
          {clienteSelId ? (
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", background:"#fff8f5", borderRadius:8, padding:"10px 14px", border:"1.5px solid #e65100" }}>
              <div style={{ fontWeight:600, fontSize:13 }}>{clienteNombre}</div>
              <button onClick={()=>{ setClienteSelId(null); setClienteNombre(""); setClienteSearch(""); }}
                style={{ background:"transparent", border:"none", color:"#c62828", cursor:"pointer", fontSize:16, fontWeight:700 }}>✕</button>
            </div>
          ) : (
            <div style={{ position:"relative" }}>
              <input value={clienteSearch || clienteNombre}
                onChange={e=>{ setClienteSearch(e.target.value); setClienteNombre(e.target.value); setClienteDropdown(true); }}
                onFocus={()=>setClienteDropdown(true)} placeholder="Buscar cliente o escribir un nombre" style={inp}/>
              {clienteDropdown && clienteSearch && (
                <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:"1.5px solid #f0d5c0", borderRadius:8, boxShadow:"0 8px 24px rgba(230,81,0,.1)", zIndex:100, maxHeight:180, overflowY:"auto", marginTop:4 }}>
                  {clientes.filter(c => `${c.nombre} ${c.apellido} ${c.empresa||""} ${c.telefono||""}`.toLowerCase().includes(clienteSearch.toLowerCase())).slice(0,8).map(cl => (
                    <div key={cl.fireId} onClick={()=>{ setClienteSelId(cl.fireId); setClienteNombre(`${cl.nombre} ${cl.apellido||""}`.trim()); setClienteSearch(""); setClienteDropdown(false); }}
                      style={{ padding:"9px 14px", cursor:"pointer", fontSize:13, fontWeight:600, borderBottom:"1px solid #fef0e8" }}
                      onMouseOver={e=>e.currentTarget.style.background="#fff8f5"} onMouseOut={e=>e.currentTarget.style.background="#fff"}>
                      {cl.nombre} {cl.apellido} {cl.empresa && `— ${cl.empresa}`}
                      {cl.telefono && <span style={{ marginLeft:6, fontSize:11, color:"#a09080", fontWeight:400 }}>{cl.telefono}</span>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Condiciones */}
        <div style={card}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>📄 Condiciones</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:12 }}>
            <div>
              <label style={lbl}>Fecha</label>
              <div style={{ ...inp, background:"#f8f9fa", color:"#4a5568" }}>{fmtFecha(fecha)}</div>
            </div>
            <div>
              <label style={lbl}>Validez (días)</label>
              <input type="number" min="1" value={validezDias} onChange={e=>setValidezDias(e.target.value)} style={inp}/>
            </div>
          </div>
          <div style={{ marginBottom:12 }}>
            <label style={lbl}>Tiempo de entrega aproximado</label>
            <input value={tiempoEntrega} onChange={e=>setTiempoEntrega(e.target.value)} placeholder="Ej: 5 días hábiles" style={inp}/>
          </div>
          <label style={lbl}>Forma de pago</label>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:12 }}>
            {getMetodosPago().map(x=>[x.nombre, labelMetodo(x.nombre)]).map(([m,l]) => (
              <button key={m} onClick={()=>setMetodoPago(m)}
                style={{ padding:"9px 8px", borderRadius:8, fontSize:12, fontWeight:700, cursor:"pointer", border:`2px solid ${metodoPago===m?"#e65100":"#f0d5c0"}`,
                  background:metodoPago===m?"#e65100":"#fff", color:metodoPago===m?"#fff":"#4a5568" }}>{l}</button>
            ))}
          </div>
          <label style={lbl}>Observaciones (opcional)</label>
          <input value={observaciones} onChange={e=>setObservaciones(e.target.value)} placeholder="Aparece impreso en el presupuesto" style={inp}/>
        </div>

        {/* Ítems */}
        <div style={card}>
          <div style={{ fontWeight:700, fontSize:14, color:"#1a2340", marginBottom:12 }}>🧾 Ítems ({items.length})</div>
          {items.length===0 ? (
            <div style={{ textAlign:"center", padding:"20px 0", color:"#d4bfb0", fontSize:13 }}>Hacé clic en un producto para agregarlo</div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:14 }}>
              {items.map(it => (
                <div key={it.insumoId} style={{ padding:"8px 10px", borderRadius:8, background:it.esLibre?"#f0f3f9":"#fffaf7", border:`1px solid ${it.esLibre?"#c5cce0":"#f5e8e0"}` }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:6 }}>
                    <input value={it.nombre} onChange={e=>upd(it.insumoId,"nombre",e.target.value)}
                      style={{ flex:1, fontSize:12, fontWeight:600, color:"#1a2340", border:"1px solid transparent", borderRadius:5, padding:"3px 6px", fontFamily:"'DM Sans',sans-serif", outline:"none", background:"transparent" }}
                      onFocus={e=>e.target.style.borderColor="#f0d5c0"} onBlur={e=>e.target.style.borderColor="transparent"}/>
                    <button onClick={()=>setItems(prev=>prev.filter(x=>x.insumoId!==it.insumoId))}
                      style={{ background:"transparent", border:"none", color:"#c62828", cursor:"pointer", fontSize:14, fontWeight:700 }}>✕</button>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:4 }}>
                      <button onClick={()=>upd(it.insumoId,"cantidad",Math.max(1,it.cantidad-1))} style={{ background:"#ffebee", border:"none", color:"#c62828", width:22, height:22, borderRadius:5, fontWeight:700, cursor:"pointer" }}>−</button>
                      <input type="number" value={it.cantidad} onChange={e=>upd(it.insumoId,"cantidad",Math.max(1,parseInt(e.target.value)||1))}
                        style={{ width:38, textAlign:"center", border:"1.5px solid #f0d5c0", borderRadius:5, fontSize:12, fontWeight:700, padding:"2px 3px" }}/>
                      <button onClick={()=>upd(it.insumoId,"cantidad",it.cantidad+1)} style={{ background:"#e8f5e9", border:"none", color:"#2e7d32", width:22, height:22, borderRadius:5, fontWeight:700, cursor:"pointer" }}>+</button>
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:4, flex:1 }}>
                      <span style={{ fontSize:11, color:"#a09080", whiteSpace:"nowrap" }}>$ p/u</span>
                      <input type="number" value={it.precio} onChange={e=>upd(it.insumoId,"precio",Math.max(0,parseFloat(e.target.value)||0))}
                        style={{ width:"100%", textAlign:"right", border:"1.5px solid #e65100", borderRadius:5, fontSize:12, fontWeight:700, padding:"3px 6px", color:"#e65100", background:"#fff8f5", outline:"none" }}/>
                    </div>
                    <div style={{ fontSize:13, fontWeight:800, color:"#e65100", minWidth:65, textAlign:"right" }}>${(it.cantidad*it.precio).toLocaleString("es-AR")}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
          <div style={{ borderTop:"2px solid #f5e8e0", paddingTop:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontWeight:700, fontSize:15, color:"#1a2340" }}>TOTAL</span>
            <span style={{ fontSize:26, fontWeight:700, color:"#e65100" }}>${total.toLocaleString("es-AR")}</span>
          </div>
        </div>

        {/* Botones */}
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          <button onClick={()=>guardar(true)} disabled={saving||items.length===0}
            style={{ width:"100%", padding:"15px", background:items.length===0?"#f0d5c0":"#e65100", color:"#fff", border:"none", borderRadius:10, fontSize:15, fontWeight:700, cursor:items.length===0?"not-allowed":"pointer" }}>
            {saving ? "Guardando..." : editMode ? "💾 Guardar cambios · Imprimir" : "💾 Guardar · Imprimir presupuesto"}
          </button>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={()=>guardar(false)} disabled={saving||items.length===0}
              style={{ flex:2, padding:"12px", background:"#fff", color:"#1a2340", border:"2px solid #1a2340", borderRadius:10, fontSize:13, fontWeight:700, cursor:items.length===0?"not-allowed":"pointer", opacity:items.length===0?.5:1 }}>
              Guardar sin imprimir
            </button>
            <button onClick={onCancel}
              style={{ flex:1, padding:"12px", background:"transparent", color:"#a09080", border:"1.5px solid #f0d5c0", borderRadius:10, fontSize:13, fontWeight:600, cursor:"pointer" }}>
              Cancelar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Modal: Aprobar presupuesto → crea pedido ─────────────────────────────
function ModalAprobarPresupuesto({ pres, clientes, showToast, onClose, onDone }) {
  const cliente = clientes.find(c => c.fireId===pres.clienteId);
  const nombreDefault = (pres.items||[]).length===1
    ? pres.items[0].nombre
    : `${(pres.items||[])[0]?.nombre || "Pedido"} (+${(pres.items||[]).length-1})`;
  const [nombre, setNombre]       = useState(nombreDefault);
  const [categoria, setCategoria] = useState("");
  const [fechaEntrega, setFechaEntrega] = useState("");
  const [telefono, setTelefono]   = useState(cliente?.telefono || "");
  const [seña, setSeña]           = useState("");
  const [saving, setSaving]       = useState(false);

  const confirmar = async () => {
    if (!categoria)    { showToast("Elegí una categoría","error"); return; }
    if (!fechaEntrega) { showToast("Elegí la fecha de entrega","error"); return; }
    setSaving(true);
    try {
      const nroOT = await getNextNroOT();
      const notas = (pres.items||[]).map(it => `${it.cantidad}× ${it.nombre} — $${(it.cantidad*it.precio).toLocaleString("es-AR")}`).join("\n");
      const pedido = {
        nombre:        nombre.trim() || nombreDefault,
        cliente:       pres.clienteNombre || "Consumidor Final",
        clienteId:     pres.clienteId || null,
        telefono:      telefono.trim(),
        categoria,
        estado:        "Pendiente",
        precio:        String(pres.total||0),
        seña:          seña || "",
        fechaPedido:   new Date().toISOString().split("T")[0],
        fechaEntrega,
        notas,
        itemsVenta:    pres.items || [],
        tomadoPor:     "",
        presupuestoId: pres.fireId,
        presupuestoNumero: pres.numero || null,
        ...(nroOT ? { nroOT } : {}),
      };
      const ref = await addDoc(collection(db, "pedidos"), pedido);
      await updateDoc(doc(db, "presupuestos", pres.fireId), {
        estado:"aprobado", aprobadoEn:new Date().toISOString(),
        pedidoFireId:ref.id, fechaEntrega, categoria,
      });
      showToast(`✅ ${presNum(pres)} aprobado · pedido creado`);
      onDone();
    } catch(e) {
      console.error(e);
      showToast("Error al aprobar el presupuesto","error");
    }
    setSaving(false);
  };

  const inp = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };
  const lbl = { display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:5 };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:400, padding:16 }} onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"26px 30px", width:480, maxHeight:"90vh", overflowY:"auto", boxShadow:"0 24px 80px rgba(0,0,0,.25)" }} onClick={e=>e.stopPropagation()}>
        <div style={{ fontWeight:700, fontSize:18, color:"#1a2340", marginBottom:4 }}>✅ Aprobar {presNum(pres)}</div>
        <div style={{ fontSize:13, color:"#a09080", marginBottom:20 }}>
          {pres.clienteNombre||"Consumidor Final"} · ${parseFloat(pres.total||0).toLocaleString("es-AR")} · se crea el pedido y aparece en el Calendario
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:13 }}>
          <div>
            <label style={lbl}>Nombre del pedido</label>
            <input value={nombre} onChange={e=>setNombre(e.target.value)} style={{ ...inp, fontWeight:600, borderColor:"#e65100" }}/>
          </div>
          <div>
            <label style={lbl}>Categoría *</label>
            <select value={categoria} onChange={e=>setCategoria(e.target.value)} style={{ ...inp, cursor:"pointer" }}>
              <option value="">— Elegí una categoría —</option>
              {CATEGORIAS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
            <div>
              <label style={lbl}>Fecha de entrega *</label>
              <input type="date" value={fechaEntrega} onChange={e=>setFechaEntrega(e.target.value)} style={inp}/>
            </div>
            <div>
              <label style={lbl}>Seña ($)</label>
              <input type="number" value={seña} onChange={e=>setSeña(e.target.value)} placeholder="0" style={inp}/>
            </div>
          </div>
          <div>
            <label style={lbl}>Teléfono</label>
            <input value={telefono} onChange={e=>setTelefono(e.target.value)} placeholder="Se muestra en el Calendario" style={inp}/>
          </div>
          {pres.tiempoEntrega && (
            <div style={{ fontSize:12, color:"#a09080", background:"#fff8f5", borderRadius:8, padding:"8px 12px" }}>
              ⏱ Tiempo de entrega presupuestado: <b>{pres.tiempoEntrega}</b>
            </div>
          )}
        </div>
        <div style={{ display:"flex", gap:10, marginTop:22 }}>
          <button onClick={onClose} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={confirmar} disabled={saving}
            style={{ flex:2, padding:"11px", background:"#2e7d32", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
            {saving ? "Creando pedido..." : "✅ Aprobar y crear pedido"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Modal: Agendar Venta como Pedido ─────────────────────────────────────
function ModalAgendarVenta({ items, total, clienteNombre, onConfirmar, onClose }) {
  const [fechaEntrega, setFechaEntrega] = useState("");
  const [categoria, setCategoria]       = useState("");
  const [notas, setNotas]               = useState("");
  const [saving, setSaving]             = useState(false);
  const hoy = new Date().toISOString().split("T")[0];
  const inp = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };

  const handleOk = async () => {
    if (!fechaEntrega || !categoria) return;
    setSaving(true);
    await onConfirmar(fechaEntrega, categoria, notas);
    setSaving(false);
  };

  const listo = fechaEntrega && categoria;

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:400 }} onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:460, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
        <div style={{ fontSize:32, textAlign:"center", marginBottom:10 }}>📅</div>
        <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:4, textAlign:"center" }}>Crear Pedido</div>
        <div style={{ fontSize:13, color:"#a09080", textAlign:"center", marginBottom:20 }}>
          Los items van a las notas del pedido · Cliente: <strong>{clienteNombre||"Consumidor Final"}</strong>
        </div>

        {/* Resumen de items */}
        <div style={{ background:"#f0f3f9", borderRadius:10, padding:"12px 14px", marginBottom:18, maxHeight:130, overflowY:"auto" }}>
          {items.map((it,i)=>(
            <div key={i} style={{ display:"flex", justifyContent:"space-between", fontSize:12, padding:"3px 0", borderBottom:i<items.length-1?"1px solid #e0e4f0":"none" }}>
              <span style={{ color:"#1a2340", fontWeight:500 }}>{it.cantidad}× {it.nombre}</span>
              <span style={{ color:"#3949ab", fontWeight:700 }}>${(it.cantidad*it.precio).toLocaleString("es-AR")}</span>
            </div>
          ))}
          <div style={{ display:"flex", justifyContent:"space-between", marginTop:8, paddingTop:8, borderTop:"2px solid #c5cce0" }}>
            <span style={{ fontWeight:700, fontSize:13, color:"#1a2340" }}>Total</span>
            <span style={{ fontWeight:800, fontSize:15, color:"#e65100" }}>${total.toLocaleString("es-AR")}</span>
          </div>
        </div>

        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          {/* Categoría */}
          <div>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>
              Categoría *
              {!categoria && <span style={{ color:"#ef5350", fontSize:11, marginLeft:6 }}>requerido</span>}
            </label>
            <select value={categoria} onChange={e=>setCategoria(e.target.value)}
              style={{ ...inp, cursor:"pointer",
                border:`1.5px solid ${!categoria?"#ef5350":"#f0d5c0"}`,
                background: categoria ? (CATEGORIA_COLOR[categoria]?.bg||"#fff8f5") : "#fff",
                color: categoria ? (CATEGORIA_COLOR[categoria]?.text||"#1a2340") : "#a09080",
                fontWeight: categoria ? 700 : 400 }}>
              <option value="">— Seleccioná una categoría —</option>
              {CATEGORIAS.map(cat=>(
                <option key={cat} value={cat}>{CATEGORIA_ICON[cat]} {cat}</option>
              ))}
            </select>
          </div>

          {/* Fecha */}
          <div>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>
              Fecha de entrega *
              {!fechaEntrega && <span style={{ color:"#ef5350", fontSize:11, marginLeft:6 }}>requerido</span>}
            </label>
            <input type="date" value={fechaEntrega} min={hoy} onChange={e=>setFechaEntrega(e.target.value)}
              style={{ ...inp, border:`1.5px solid ${!fechaEntrega?"#ef5350":"#f0d5c0"}` }}/>
          </div>

          {/* Notas */}
          <div>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Notas adicionales (opcional)</label>
            <textarea value={notas} onChange={e=>setNotas(e.target.value)} rows={2}
              placeholder="Aclaraciones para el pedido..."
              style={{ ...inp, resize:"none", lineHeight:1.5 }}/>
          </div>
        </div>

        <div style={{ display:"flex", gap:10, marginTop:20 }}>
          <button onClick={onClose} style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>
            Cancelar
          </button>
          <button onClick={handleOk} disabled={!listo||saving}
            style={{ flex:2, padding:"11px", background:!listo?"#c5cce0":"#3949ab", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:!listo?"not-allowed":"pointer", transition:"all .2s" }}>
            {saving ? "Creando..." : "📅 Crear Pedido"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Componente: Insumos ───────────────────────────────────────────────────
function InsumosView({ setView, showToast }) {
  const [insumos, setInsumos]         = useState([]);
  const [busq, setBusq]               = useState("");
  const [filtroCat, setFiltroCat]     = useState("Todas");
  const [importModal, setImportModal] = useState(false);
  const [importData, setImportData]   = useState([]);
  const [importing, setImporting]     = useState(false);
  const [modoImport, setModoImport]   = useState("reemplazar");
  const [loadingInsumos, setLoadingInsumos] = useState(true);
  const [editingId, setEditingId]     = useState(null);
  const [editModal, setEditModal]     = useState(null);
  const [tabActiva, setTabActiva]     = useState("productos"); // productos | materias

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "insumos"), snap => {
      setInsumos(snap.docs.map(d => ({ ...d.data(), fireId: d.id })));
      setLoadingInsumos(false);
    });
    return () => unsub();
  }, []);

  const categorias = ["Todas", ...Array.from(new Set(insumos.map(i => i.categoria).filter(Boolean))).sort()];

  const filtrados = insumos.filter(i => {
    if (busq) {
      const palabras = busq.toLowerCase().split(/\s+/).filter(Boolean);
      const texto = `${i.nombre||""} ${i.codigo||""} ${i.categoria||""}`.toLowerCase();
      if (!palabras.every(p => texto.includes(p))) return false;
    }
    return filtroCat === "Todas" || i.categoria === filtroCat;
  }).sort((a,b) => (a.categoria||"").localeCompare(b.categoria||"") || (a.nombre||"").localeCompare(b.nombre||""));

  // ── Importar Excel ──
  const handleExcel = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const XLSX = await import("https://cdn.sheetjs.com/xlsx-0.20.1/package/xlsx.mjs");
    const buf  = await file.arrayBuffer();
    const wb   = XLSX.read(buf);
    const ws   = wb.Sheets["Precios final"];
    if (!ws) { showToast('No encontré la pestaña "Precios final"', "error"); return; }
    const rows = XLSX.utils.sheet_to_json(ws, { defval: "" });
    const parsed = rows
      .filter(r => r.nombre || r.codigo)
      .map(r => ({
        codigo:        String(r.codigo      || "").trim(),
        nombre:        String(r.nombre      || "").trim(),
        precioCompra:  parseFloat(r.precio_compra  || 0) || 0,
        precioVenta:   parseFloat(r.precio_venta1  || r.precio_venta || 0) || 0,
        precioGremio:  parseFloat(r.precio_venta2  || r.precio_gremio || 0) || 0,
        categoria:     String(r.categoria   || "General").trim(),
        stock:         0,
        stockMinimo:   0,
      }));
    setImportData(parsed);
    setImportModal(true);
  };

  const handleImportar = async () => {
    setImporting(true);
    try {
      // Si es reemplazar: borrar todos los insumos existentes primero
      if (modoImport === "reemplazar") {
        const snap = await getDocs(collection(db, "insumos"));
        // Borrar en lotes para no sobrecargar Firebase
        const borrar = snap.docs.map(d => deleteDoc(doc(db, "insumos", d.id)));
        await Promise.all(borrar);
      }
      // Agregar los nuevos — respetar stock existente si es modo agregar
      const snapActual = modoImport === "agregar" ? await getDocs(collection(db, "insumos")) : null;
      const mapaActual = {};
      if (snapActual) {
        snapActual.docs.forEach(d => {
          const data = d.data();
          if (data.codigo) mapaActual[data.codigo] = { fireId: d.id, ...data };
        });
      }
      const batch = importData.slice(0, 500);
      for (const ins of batch) {
        if (modoImport === "agregar" && ins.codigo && mapaActual[ins.codigo]) {
          // Actualizar precios pero conservar stock
          await updateDoc(doc(db, "insumos", mapaActual[ins.codigo].fireId), {
            nombre:       ins.nombre,
            precioCompra: ins.precioCompra,
            precioVenta:  ins.precioVenta,
            precioGremio: ins.precioGremio,
            categoria:    ins.categoria,
          });
        } else {
          await addDoc(collection(db, "insumos"), ins);
        }
      }
      setImportModal(false);
      showToast(`✅ ${batch.length} insumos ${modoImport === "reemplazar" ? "reemplazados" : "actualizados"} correctamente`);
    } catch(e) {
      showToast("Error al importar", "error");
      console.error(e);
    }
    setImporting(false);
  };

  const handleDelete = async (ins) => {
    if (!window.confirm(`¿Eliminar "${ins.nombre}"?`)) return;
    await deleteDoc(doc(db, "insumos", ins.fireId));
    showToast("Insumo eliminado", "error");
  };

  const handleStockUpdate = async (ins, delta) => {
    const nuevoStock = (parseFloat(ins.stock)||0) + delta;
    if (nuevoStock < 0) return;
    await updateDoc(doc(db, "insumos", ins.fireId), { stock: nuevoStock });
  };

  const handleEditSave = async () => {
    if (!editModal) return;
    await updateDoc(doc(db, "insumos", editModal.fireId), {
      nombre:       editModal.nombre,
      codigo:       editModal.codigo,
      categoria:    editModal.categoria,
      precioCompra: parseFloat(editModal.precioCompra)||0,
      precioVenta:  parseFloat(editModal.precioVenta)||0,
      precioGremio: parseFloat(editModal.precioGremio)||0,
      stockMinimo:  parseFloat(editModal.stockMinimo)||0,
    });
    showToast("Insumo actualizado ✅");
    setEditModal(null);
  };

  const stockBajo = insumos.filter(i => (parseFloat(i.stock)||0) <= (parseFloat(i.stockMinimo)||0) && (parseFloat(i.stockMinimo)||0) > 0);

  return (
    <div>
      {/* Tabs */}
      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:20, flexWrap:"wrap" }}>
        <button onClick={()=>setTabActiva("productos")}
          style={{ padding:"9px 20px", borderRadius:20, fontSize:14, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
            background:tabActiva==="productos"?"#e65100":"#fff", color:tabActiva==="productos"?"#fff":"#4a5568",
            boxShadow:tabActiva==="productos"?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
          🏷️ Servicios y Productos
          <span style={{ marginLeft:6, background:tabActiva==="productos"?"rgba(255,255,255,.25)":"#f0f3f9", color:tabActiva==="productos"?"#fff":"#a09080", borderRadius:20, padding:"1px 7px", fontSize:12, fontWeight:700 }}>{insumos.length}</span>
        </button>
        <button onClick={()=>setTabActiva("materias")}
          style={{ padding:"9px 20px", borderRadius:20, fontSize:14, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
            background:tabActiva==="materias"?"#1a2340":"#fff", color:tabActiva==="materias"?"#fff":"#4a5568",
            boxShadow:tabActiva==="materias"?"0 3px 10px rgba(26,35,64,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
          🧪 Materias Primas
        </button>
      </div>

      {/* ── TAB MATERIAS PRIMAS ── */}
      {tabActiva==="materias" && <MateriasPrimasView showToast={showToast}/>}

      {tabActiva==="productos" && (
      <div>

      {/* Header productos */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <p style={{ fontSize:14, color:"#a09080" }}>{insumos.length} productos · {filtrados.length} mostrados</p>
        <div style={{ display:"flex", gap:10 }}>
          <button onClick={async () => {
            if (!window.confirm(`⚠️ ¿Seguro que querés borrar los ${insumos.length} insumos? Esta acción no se puede deshacer.`)) return;
            const snap = await getDocs(collection(db, "insumos"));
            await Promise.all(snap.docs.map(d => deleteDoc(doc(db, "insumos", d.id))));
            showToast("Todos los insumos fueron eliminados", "error");
          }} style={{ background:"transparent", border:"1.5px solid #ef5350", color:"#ef5350", padding:"9px 16px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            🗑 Borrar todos
          </button>
          <label style={{ background:"#fff", border:"1.5px solid #e65100", color:"#e65100", padding:"9px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            📥 Importar Excel
            <input type="file" accept=".xlsx,.xls" onChange={handleExcel} style={{ display:"none" }}/>
          </label>
          <button onClick={() => setView("nuevoInsumo")}
            style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            ➕ Nuevo Producto
          </button>
        </div>
      </div>

      {/* Alerta stock bajo */}
      {stockBajo.length > 0 && (
        <div style={{ background:"#fff3e0", border:"1.5px solid #ff9800", borderRadius:10, padding:"12px 18px", marginBottom:16, display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:20 }}>⚠️</span>
          <div>
            <div style={{ fontWeight:700, fontSize:13, color:"#e65100" }}>Stock bajo en {stockBajo.length} insumo{stockBajo.length!==1?"s":""}</div>
            <div style={{ fontSize:12, color:"#bf360c" }}>{stockBajo.map(i=>i.nombre).join(" · ")}</div>
          </div>
        </div>
      )}

      {/* Filtros */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18, display:"flex", gap:12, flexWrap:"wrap" }}>
        <div style={{ position:"relative", flex:"1 1 220px" }}>
          <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)" }}>🔍</span>
          <input placeholder="Buscar por nombre o código..." value={busq} onChange={e=>setBusq(e.target.value)}
            style={{ width:"100%", padding:"10px 14px 10px 32px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
        </div>
        <select value={filtroCat} onChange={e=>setFiltroCat(e.target.value)}
          style={{ padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", cursor:"pointer", minWidth:180 }}>
          {categorias.map(c => <option key={c}>{c}</option>)}
        </select>
      </div>

      {/* Tabla */}
      {loadingInsumos ? (
        <div style={{ textAlign:"center", padding:40, color:"#a09080" }}>Cargando insumos...</div>
      ) : filtrados.length === 0 ? (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px 24px", textAlign:"center" }}>
          <div style={{ fontSize:40, marginBottom:14 }}>📦</div>
          <div style={{ fontWeight:700, fontSize:18, fontFamily:"'DM Sans',sans-serif", marginBottom:6 }}>{busq||filtroCat!=="Todas"?"Sin resultados":"No hay insumos aún"}</div>
          <div style={{ color:"#a09080", fontSize:14 }}>Importá tu lista desde Excel o agregá insumos uno a uno</div>
        </div>
      ) : (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
            <thead>
              <tr style={{ background:"#fffaf7" }}>
                {["Código","Nombre","Categoría","P. Compra","P. Venta","P. Gremio","Stock",""].map(h => (
                  <th key={h} style={{ padding:"11px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0", whiteSpace:"nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtrados.map(ins => {
                const stockN = parseFloat(ins.stock)||0;
                const minN   = parseFloat(ins.stockMinimo)||0;
                const bajo   = minN > 0 && stockN <= minN;
                return (
                  <tr key={ins.fireId} style={{ borderBottom:"1px solid #fef0e8", background:bajo?"#fff8f0":"#fff" }}>
                    <td style={{ padding:"11px 14px", color:"#a09080", fontSize:12, fontFamily:"monospace" }}>{ins.codigo||"—"}</td>
                    <td style={{ padding:"11px 14px", fontWeight:600, color:"#1a2340", maxWidth:280 }}>
                      {ins.nombre}
                      {bajo && <span style={{ marginLeft:6, fontSize:10, background:"#ffebee", color:"#c62828", padding:"2px 6px", borderRadius:10, fontWeight:700 }}>STOCK BAJO</span>}
                    </td>
                    <td style={{ padding:"11px 14px" }}>
                      <span style={{ background:"#fff3e0", color:"#bf360c", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{ins.categoria||"—"}</span>
                    </td>
                    <td style={{ padding:"11px 14px", color:"#4a5568" }}>{ins.precioCompra?`$${parseFloat(ins.precioCompra).toLocaleString("es-AR")}`:"—"}</td>
                    <td style={{ padding:"11px 14px", fontWeight:600, color:"#1a2340" }}>{ins.precioVenta?`$${parseFloat(ins.precioVenta).toLocaleString("es-AR")}`:"—"}</td>
                    <td style={{ padding:"11px 14px", fontWeight:600, color:"#e65100" }}>{ins.precioGremio?`$${parseFloat(ins.precioGremio).toLocaleString("es-AR")}`:"—"}</td>
                    <td style={{ padding:"11px 14px" }}>
                      <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                        <button onClick={() => handleStockUpdate(ins,-1)} style={{ background:"#ffebee", border:"none", color:"#c62828", width:24, height:24, borderRadius:5, fontWeight:700, cursor:"pointer", fontSize:14 }}>−</button>
                        <span style={{ fontWeight:700, color:bajo?"#c62828":"#1a2340", minWidth:28, textAlign:"center" }}>{stockN}</span>
                        <button onClick={() => handleStockUpdate(ins,1)}  style={{ background:"#e8f5e9", border:"none", color:"#2e7d32", width:24, height:24, borderRadius:5, fontWeight:700, cursor:"pointer", fontSize:14 }}>+</button>
                      </div>
                    </td>
                    <td style={{ padding:"11px 14px" }}>
                      <div style={{ display:"flex", gap:5 }}>
                        <button onClick={() => setEditModal({...ins})} style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer", fontWeight:600 }}>✏️</button>
                        <button onClick={() => handleDelete(ins)} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal importar */}
      {importModal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.55)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200, padding:20 }} onClick={() => setImportModal(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"32px 36px", width:"100%", maxWidth:680, maxHeight:"80vh", overflow:"auto", boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:"#1a2340", marginBottom:6 }}>📥 Vista previa de importación</div>
            <div style={{ fontSize:13, color:"#a09080", marginBottom:16 }}>{importData.length} productos encontrados en la pestaña "Precios final"</div>

            {/* Selector modo importación */}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:20 }}>
              <div onClick={()=>setModoImport("reemplazar")}
                style={{ padding:"14px 16px", borderRadius:10, border:`2px solid ${modoImport==="reemplazar"?"#e65100":"#f0d5c0"}`, background:modoImport==="reemplazar"?"#fff8f5":"#fff", cursor:"pointer", transition:"all .15s" }}>
                <div style={{ fontWeight:700, fontSize:14, color:modoImport==="reemplazar"?"#e65100":"#1a2340", marginBottom:4 }}>🔄 Reemplazar todo</div>
                <div style={{ fontSize:12, color:"#a09080", lineHeight:1.4 }}>Borra los insumos actuales y carga los del Excel. <strong>Conserva el stock que ya tenías cargado.</strong></div>
              </div>
              <div onClick={()=>setModoImport("agregar")}
                style={{ padding:"14px 16px", borderRadius:10, border:`2px solid ${modoImport==="agregar"?"#e65100":"#f0d5c0"}`, background:modoImport==="agregar"?"#fff8f5":"#fff", cursor:"pointer", transition:"all .15s" }}>
                <div style={{ fontWeight:700, fontSize:14, color:modoImport==="agregar"?"#e65100":"#1a2340", marginBottom:4 }}>➕ Actualizar precios</div>
                <div style={{ fontSize:12, color:"#a09080", lineHeight:1.4 }}>Actualiza precios de los existentes por código. Agrega los nuevos. Conserva todo el stock.</div>
              </div>
            </div>

            {modoImport==="reemplazar" && (
              <div style={{ background:"#fff3e0", border:"1.5px solid #ffb74d", borderRadius:8, padding:"10px 14px", marginBottom:16, fontSize:12, color:"#e65100", fontWeight:600 }}>
                ⚠️ Se borrarán todos los insumos actuales y se cargarán los del Excel. El stock actual se perderá.
              </div>
            )}

            <div style={{ maxHeight:280, overflowY:"auto", borderRadius:8, border:"1px solid #f0d5c0", marginBottom:20 }}>
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
                <thead>
                  <tr style={{ background:"#fffaf7", position:"sticky", top:0 }}>
                    {["Código","Nombre","Categoría","P.Compra","P.Venta","P.Gremio"].map(h=>(
                      <th key={h} style={{ padding:"8px 12px", textAlign:"left", fontWeight:700, color:"#a09080", fontSize:10, textTransform:"uppercase", borderBottom:"1px solid #f0d5c0" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {importData.slice(0,100).map((r,i) => (
                    <tr key={i} style={{ borderBottom:"1px solid #fef0e8" }}>
                      <td style={{ padding:"7px 12px", color:"#a09080", fontFamily:"monospace" }}>{r.codigo||"—"}</td>
                      <td style={{ padding:"7px 12px", fontWeight:600, color:"#1a2340" }}>{r.nombre}</td>
                      <td style={{ padding:"7px 12px" }}><span style={{ background:"#fff3e0", color:"#bf360c", padding:"2px 7px", borderRadius:10, fontSize:10, fontWeight:600 }}>{r.categoria}</span></td>
                      <td style={{ padding:"7px 12px" }}>{r.precioCompra?`$${r.precioCompra.toLocaleString("es-AR")}`:"—"}</td>
                      <td style={{ padding:"7px 12px", fontWeight:600 }}>{r.precioVenta?`$${r.precioVenta.toLocaleString("es-AR")}`:"—"}</td>
                      <td style={{ padding:"7px 12px", color:"#e65100", fontWeight:600 }}>{r.precioGremio?`$${r.precioGremio.toLocaleString("es-AR")}`:"—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {importData.length > 100 && <div style={{ padding:"10px 12px", fontSize:12, color:"#a09080", textAlign:"center" }}>...y {importData.length-100} más</div>}
            </div>
            <div style={{ display:"flex", gap:10, justifyContent:"flex-end" }}>
              <button onClick={() => setImportModal(false)} style={{ padding:"10px 20px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleImportar} disabled={importing}
                style={{ padding:"10px 28px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer", opacity:importing?.7:1 }}>
                {importing
                  ? "Procesando..."
                  : modoImport==="reemplazar"
                    ? `🔄 Reemplazar con ${importData.length} insumos`
                    : `➕ Actualizar ${importData.length} insumos`
                }
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal editar inline */}
      {editModal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200, padding:20 }} onClick={() => setEditModal(null)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:"100%", maxWidth:500, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340", marginBottom:20 }}>✏️ Editar Insumo</div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
              {[["Nombre","nombre","1 / -1"],["Código","codigo"],["Categoría","categoria"],["Precio Compra","precioCompra"],["Precio Venta","precioVenta"],["Precio Gremio","precioGremio"],["Stock Mínimo","stockMinimo"]].map(([label,key,col]) => (
                <div key={key} style={{ gridColumn:col||"auto" }}>
                  <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:4 }}>{label}</label>
                  <input value={editModal[key]||""} onChange={e=>setEditModal(m=>({...m,[key]:e.target.value}))}
                    style={{ width:"100%", padding:"9px 12px", borderRadius:7, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
                </div>
              ))}
            </div>
            <div style={{ display:"flex", gap:10, justifyContent:"flex-end", marginTop:20 }}>
              <button onClick={() => setEditModal(null)} style={{ padding:"9px 18px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleEditSave} style={{ padding:"9px 22px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>💾 Guardar</button>
            </div>
          </div>
        </div>
      )}
      </div>
      )}
    </div>
  );
}

// ── Componente: Materias Primas ───────────────────────────────────────────
function MateriasPrimasView({ showToast }) {
  const [materias, setMaterias]         = useState([]);
  const [proveedores, setProveedores]   = useState([]);
  const [busq, setBusq]                 = useState("");
  const [modal, setModal]               = useState(null);
  const [filtroProv, setFiltroProv]     = useState("todos");
  const [importData, setImportData]     = useState([]);
  const [importModal, setImportModal]   = useState(false);
  const [importing, setImporting]       = useState(false);
  const [modoImport, setModoImport]     = useState("reemplazar");

  useEffect(() => {
    const u1 = onSnapshot(collection(db,"materiasPrimas"), snap =>
      setMaterias(snap.docs.map(d=>({...d.data(),fireId:d.id})).sort((a,b)=>(a.nombre||"").localeCompare(b.nombre||"")))
    );
    const u2 = onSnapshot(collection(db,"proveedores"), snap =>
      setProveedores(snap.docs.map(d=>({...d.data(),fireId:d.id})))
    );
    return () => { u1(); u2(); };
  }, []);

  const filtradas = materias.filter(m => {
    const palabras = busq.toLowerCase().split(/\s+/).filter(Boolean);
    const texto = `${m.nombre||""} ${m.descripcion||""} ${m.categoria||""}`.toLowerCase();
    const matchBusq = !busq || palabras.every(p=>texto.includes(p));
    const matchProv = filtroProv==="todos" || m.proveedorId===filtroProv;
    return matchBusq && matchProv;
  });

  const eliminar = async (m) => {
    if (!window.confirm(`¿Eliminar "${m.nombre}"?`)) return;
    await deleteDoc(doc(db,"materiasPrimas",m.fireId));
    showToast("Materia prima eliminada","error");
  };

  const UNIDADES = ["unidad","kg","g","m","m²","cm","rollo","litro","ml","resma","caja","paq."];

  const handleExcelMP = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const XLSX = await import("https://cdn.sheetjs.com/xlsx-0.20.1/package/xlsx.mjs");
    const buf  = await file.arrayBuffer();
    const wb   = XLSX.read(buf);
    const ws   = wb.Sheets[wb.SheetNames[0]];
    if (!ws) { showToast("No se pudo leer el Excel","error"); return; }
    const rows = XLSX.utils.sheet_to_json(ws, { defval:"" });
    const parsed = rows.filter(r=>r.nombre||r.Nombre).map(r=>({
      nombre:      String(r.nombre||r.Nombre||"").trim(),
      descripcion: String(r.descripcion||r.Descripcion||r.descripción||"").trim(),
      precioCosto: parseFloat(r.precioCosto||r.precio||r.Precio||0)||0,
      unidad:      String(r.unidad||r.Unidad||"unidad").trim(),
      categoria:   String(r.categoria||r.Categoria||r.categoría||"General").trim(),
      proveedor:   String(r.proveedor||r.Proveedor||"").trim(),
      stock:       parseFloat(r.stock||r.Stock||0)||0,
    }));
    if (!parsed.length) { showToast("No encontré datos en el Excel","error"); return; }
    setImportData(parsed);
    setImportModal(true);
    e.target.value = "";
  };

  const handleImportarMP = async () => {
    setImporting(true);
    try {
      if (modoImport==="reemplazar") {
        const snap = await getDocs(collection(db,"materiasPrimas"));
        await Promise.all(snap.docs.map(d=>deleteDoc(doc(db,"materiasPrimas",d.id))));
      }
      for (const m of importData) {
        // Buscar proveedor por nombre si viene en el Excel
        let proveedorId = "";
        if (m.proveedor) {
          const prov = proveedores.find(p=>(p.empresa||p.titular||"").toLowerCase()===m.proveedor.toLowerCase());
          if (prov) proveedorId = prov.fireId;
        }
        const data = { nombre:m.nombre, descripcion:m.descripcion, precioCosto:m.precioCosto, unidad:m.unidad, categoria:m.categoria, stock:m.stock, proveedorId };
        if (modoImport==="agregar") {
          const exist = materias.find(x=>x.nombre.toLowerCase()===m.nombre.toLowerCase());
          if (exist) { await updateDoc(doc(db,"materiasPrimas",exist.fireId),{precioCosto:m.precioCosto,unidad:m.unidad,categoria:m.categoria}); continue; }
        }
        await addDoc(collection(db,"materiasPrimas"), data);
      }
      setImportModal(false);
      showToast(`✅ ${importData.length} materias primas ${modoImport==="reemplazar"?"importadas":"actualizadas"}`);
    } catch(e) { showToast("Error al importar","error"); console.error(e); }
    setImporting(false);
  };

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16, flexWrap:"wrap", gap:10 }}>
        <p style={{ fontSize:14, color:"#a09080" }}>{materias.length} materia{materias.length!==1?"s":""} prima{materias.length!==1?"s":""}</p>
        <div style={{ display:"flex", gap:10 }}>
          <label style={{ background:"#fff", border:"1.5px solid #1a2340", color:"#1a2340", padding:"9px 16px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            📥 Importar Excel
            <input type="file" accept=".xlsx,.xls" onChange={handleExcelMP} style={{ display:"none" }}/>
          </label>
          <button onClick={()=>setModal({})}
            style={{ background:"#1a2340", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            ➕ Nueva Materia Prima
          </button>
        </div>
      </div>

      {/* Filtros */}
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18, display:"flex", gap:10, flexWrap:"wrap", alignItems:"center" }}>
        <div style={{ position:"relative", flex:"1 1 200px" }}>
          <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)" }}>🔍</span>
          <input placeholder="Buscar materia prima..." value={busq} onChange={e=>setBusq(e.target.value)}
            style={{ width:"100%", padding:"10px 14px 10px 32px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
        </div>
        <select value={filtroProv} onChange={e=>setFiltroProv(e.target.value)}
          style={{ padding:"9px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none", cursor:"pointer" }}>
          <option value="todos">Todos los proveedores</option>
          {proveedores.map(p=><option key={p.fireId} value={p.fireId}>{p.empresa||p.titular}</option>)}
        </select>
      </div>

      {filtradas.length===0 ? (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px 24px", textAlign:"center" }}>
          <div style={{ fontSize:40, marginBottom:14 }}>🧪</div>
          <div style={{ fontWeight:700, fontSize:18, marginBottom:6 }}>{materias.length===0?"Sin materias primas cargadas":"Sin resultados"}</div>
          <div style={{ color:"#a09080", fontSize:14 }}>Cargá tus materias primas para usarlas en las calculadoras</div>
        </div>
      ) : (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
            <thead><tr style={{ background:"#f0f3f9" }}>
              {["Nombre","Descripción","Unidad","Precio costo","Proveedor","Stock",""].map(h=>(
                <th key={h} style={{ padding:"11px 14px", textAlign:"left", fontSize:11, fontWeight:700, color:"#4a5568", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"2px solid #e8eaf0" }}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {filtradas.map(m=>{
                const prov = proveedores.find(p=>p.fireId===m.proveedorId);
                return (
                  <tr key={m.fireId} style={{ borderBottom:"1px solid #f0f3f9" }}
                    onMouseOver={e=>e.currentTarget.style.background="#fafbff"}
                    onMouseOut={e=>e.currentTarget.style.background="#fff"}>
                    <td style={{ padding:"12px 14px", fontWeight:700, color:"#1a2340" }}>{m.nombre}</td>
                    <td style={{ padding:"12px 14px", color:"#4a5568", maxWidth:200, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{m.descripcion||"—"}</td>
                    <td style={{ padding:"12px 14px" }}>
                      <span style={{ background:"#e8eaf6", color:"#3949ab", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{m.unidad||"unidad"}</span>
                    </td>
                    <td style={{ padding:"12px 14px", fontWeight:700, color:"#1a2340" }}>${parseFloat(m.precioCosto||0).toLocaleString("es-AR")}</td>
                    <td style={{ padding:"12px 14px" }}>
                      {prov
                        ? <span style={{ background:"#fff3e0", color:"#e65100", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{prov.empresa||prov.titular}</span>
                        : <span style={{ color:"#a09080", fontSize:12 }}>Sin asignar</span>}
                    </td>
                    <td style={{ padding:"12px 14px", fontWeight:600, color: parseFloat(m.stock||0)<=0?"#c62828":"#2e7d32" }}>
                      {parseFloat(m.stock||0)} {m.unidad||""}
                    </td>
                    <td style={{ padding:"12px 12px" }}>
                      <div style={{ display:"flex", gap:6 }}>
                        <button onClick={()=>setModal(m)}
                          style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"5px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>✏️</button>
                        <button onClick={()=>eliminar(m)}
                          style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"5px 8px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal nueva/editar materia prima */}
      {modal && (
        <ModalMateriaPrima
          materia={modal.fireId ? modal : null}
          proveedores={proveedores}
          unidades={UNIDADES}
          onClose={()=>setModal(null)}
          showToast={showToast}
        />
      )}

      {/* Modal importar Excel */}
      {importModal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.55)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200, padding:20 }} onClick={()=>setImportModal(false)}>
          <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:"100%", maxWidth:600, maxHeight:"85vh", overflowY:"auto", boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:6 }}>📥 Importar Materias Primas</div>
            <div style={{ fontSize:13, color:"#a09080", marginBottom:16 }}>{importData.length} materias primas encontradas</div>

            {/* Modo */}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:16 }}>
              {[["reemplazar","🔄 Reemplazar todo","Borra las actuales y carga las del Excel"],["agregar","➕ Actualizar precios","Actualiza existentes, agrega nuevas"]].map(([val,lbl,sub])=>(
                <div key={val} onClick={()=>setModoImport(val)}
                  style={{ padding:"12px 14px", borderRadius:10, border:`2px solid ${modoImport===val?"#1a2340":"#f0d5c0"}`, background:modoImport===val?"#f0f3f9":"#fff", cursor:"pointer" }}>
                  <div style={{ fontWeight:700, fontSize:13, color:modoImport===val?"#1a2340":"#4a5568" }}>{lbl}</div>
                  <div style={{ fontSize:11, color:"#a09080", marginTop:3 }}>{sub}</div>
                </div>
              ))}
            </div>

            {modoImport==="reemplazar" && (
              <div style={{ background:"#fff3e0", border:"1.5px solid #ffb74d", borderRadius:8, padding:"9px 14px", marginBottom:14, fontSize:12, color:"#e65100", fontWeight:600 }}>
                ⚠️ Se eliminarán todas las materias primas actuales
              </div>
            )}

            {/* Preview tabla */}
            <div style={{ maxHeight:260, overflowY:"auto", borderRadius:8, border:"1px solid #f0d5c0", marginBottom:18 }}>
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
                <thead>
                  <tr style={{ background:"#f0f3f9", position:"sticky", top:0 }}>
                    {["Nombre","Descripción","Precio Costo","Unidad","Categoría","Proveedor"].map(h=>(
                      <th key={h} style={{ padding:"8px 10px", textAlign:"left", fontWeight:700, color:"#4a5568", fontSize:10, textTransform:"uppercase", borderBottom:"1px solid #e0e4f0" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {importData.slice(0,50).map((m,i)=>(
                    <tr key={i} style={{ borderBottom:"1px solid #f0f3f9" }}>
                      <td style={{ padding:"7px 10px", fontWeight:600, color:"#1a2340" }}>{m.nombre}</td>
                      <td style={{ padding:"7px 10px", color:"#4a5568", maxWidth:120, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{m.descripcion||"—"}</td>
                      <td style={{ padding:"7px 10px", fontWeight:700, color:"#1a2340" }}>{m.precioCosto?`$${m.precioCosto.toLocaleString("es-AR")}`:"—"}</td>
                      <td style={{ padding:"7px 10px" }}><span style={{ background:"#e8eaf6", color:"#3949ab", padding:"1px 7px", borderRadius:10, fontSize:10, fontWeight:600 }}>{m.unidad}</span></td>
                      <td style={{ padding:"7px 10px", color:"#4a5568" }}>{m.categoria}</td>
                      <td style={{ padding:"7px 10px", color:"#a09080" }}>{m.proveedor||"—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {importData.length>50 && <div style={{ padding:"8px 10px", fontSize:11, color:"#a09080", textAlign:"center" }}>...y {importData.length-50} más</div>}
            </div>

            <div style={{ display:"flex", gap:10, justifyContent:"flex-end" }}>
              <button onClick={()=>setImportModal(false)} style={{ padding:"10px 18px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
              <button onClick={handleImportarMP} disabled={importing}
                style={{ padding:"10px 24px", background:"#1a2340", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer", opacity:importing?.7:1 }}>
                {importing?"Importando...":`${modoImport==="reemplazar"?"🔄 Reemplazar":"➕ Actualizar"} ${importData.length} materias primas`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ModalMateriaPrima({ materia, proveedores, unidades, onClose, showToast }) {
  const [form, setForm] = useState(materia || { nombre:"", descripcion:"", precioCosto:"", unidad:"unidad", proveedorId:"", stock:"", categoria:"", categoriaKey:"", rendimiento:"" });
  const [saving, setSaving] = useState(false);
  const inp = { width:"100%", padding:"10px 12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };

  const handleSave = async () => {
    if (!form.nombre.trim()) { showToast("El nombre es obligatorio","error"); return; }
    setSaving(true);
    const data = { ...form, precioCosto: parseFloat(form.precioCosto)||0, stock: parseFloat(form.stock)||0, rendimiento: parseFloat(form.rendimiento)||0 };
    if (materia?.fireId) {
      await updateDoc(doc(db,"materiasPrimas",materia.fireId), data);
      showToast("Materia prima actualizada ✅");
    } else {
      await addDoc(collection(db,"materiasPrimas"), data);
      showToast("Materia prima creada ✅");
    }
    setSaving(false);
    onClose();
  };

  // Categorías fijas para las calculadoras
  const CAT_OPCIONES = [
    { key:"",                    label:"— Sin vincular a calculadora —" },
    { key:"vinilo_imprimible",   label:"🖨️ Vinilo imprimible (rollo plotter)" },
    { key:"tinta_plotter",       label:"🎨 Tinta plotter" },
    { key:"lona_frontlight",     label:"🚩 Lona frontlight" },
    { key:"lona_backlight",      label:"🚩 Lona backlight" },
    { key:"vinilo_transparente", label:"🔲 Vinilo transparente" },
    { key:"vinilo_corte",        label:"✂️ Vinilo de corte (calado)" },
    { key:"cinta_posicionadora", label:"📏 Cinta posicionadora" },
    { key:"plastico_corrugado",  label:"🪟 Plástico corrugado" },
    { key:"plastico_bicapa",     label:"🪟 Plástico bicapa / PAI / PVC" },
    { key:"polifan",             label:"🟡 Polyfan / foam" },
    { key:"filamento_pla",       label:"🧵 Filamento PLA (3D)" },
  ];

  const necesitaRendimiento = ["vinilo_imprimible","tinta_plotter","lona_frontlight","lona_backlight","vinilo_transparente","vinilo_corte","cinta_posicionadora","filamento_pla"].includes(form.categoriaKey);

  const labelRendimiento = form.categoriaKey==="filamento_pla"
    ? "Rendimiento (gramos por unidad de compra)"
    : "Rendimiento (m² o metros que rinde el rollo)";

  const precioCalculado = form.categoriaKey && parseFloat(form.rendimiento)>0
    ? parseFloat(form.precioCosto||0) / parseFloat(form.rendimiento)
    : null;

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:540, boxShadow:"0 20px 60px rgba(0,0,0,.2)", maxHeight:"92vh", overflowY:"auto" }} onClick={e=>e.stopPropagation()}>
        <div style={{ fontWeight:700, fontSize:20, color:"#1a2340", marginBottom:20 }}>
          {materia?"✏️ Editar Materia Prima":"🧪 Nueva Materia Prima"}
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
          <div style={{ gridColumn:"1/-1" }}>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nombre *</label>
            <input value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))} placeholder="Ej: Vinilo Arlon base blanca" style={inp}/>
          </div>
          <div style={{ gridColumn:"1/-1" }}>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Descripción</label>
            <input value={form.descripcion||""} onChange={e=>setForm(f=>({...f,descripcion:e.target.value}))} placeholder="Ej: Rollo 1.52m × 50m" style={inp}/>
          </div>

          {/* Categoría calculadora — campo clave */}
          <div style={{ gridColumn:"1/-1" }}>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#1a2340", marginBottom:6 }}>
              🔗 Categoría para calculadoras
            </label>
            <select value={form.categoriaKey||""} onChange={e=>setForm(f=>({...f,categoriaKey:e.target.value}))}
              style={{ ...inp, cursor:"pointer", borderColor:form.categoriaKey?"#e65100":"#f0d5c0",
                background:form.categoriaKey?"#fff8f5":"#fff", fontWeight:form.categoriaKey?600:400 }}>
              {CAT_OPCIONES.map(o=><option key={o.key} value={o.key}>{o.label}</option>)}
            </select>
            {form.categoriaKey && <div style={{ fontSize:11, color:"#e65100", marginTop:4, fontWeight:600 }}>✅ Esta materia prima se usará automáticamente en las calculadoras</div>}
          </div>

          <div>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio de costo ($)</label>
            <input type="number" value={form.precioCosto} onChange={e=>setForm(f=>({...f,precioCosto:e.target.value}))} placeholder="0" style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Unidad de compra</label>
            <select value={form.unidad} onChange={e=>setForm(f=>({...f,unidad:e.target.value}))} style={{ ...inp, cursor:"pointer" }}>
              {unidades.map(u=><option key={u} value={u}>{u}</option>)}
            </select>
          </div>

          {/* Rendimiento — solo para materiales con rollo/kg */}
          {necesitaRendimiento && (
            <div style={{ gridColumn:"1/-1" }}>
              <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>
                {labelRendimiento}
              </label>
              <input type="number" step="0.01" value={form.rendimiento||""} onChange={e=>setForm(f=>({...f,rendimiento:e.target.value}))}
                placeholder={form.categoriaKey==="filamento_pla"?"1000":"50"} style={{ ...inp, borderColor:"#e65100" }}/>
              {precioCalculado!==null && precioCalculado>0 && (
                <div style={{ marginTop:6, background:"#fff8f5", borderRadius:8, padding:"8px 12px", fontSize:12, color:"#e65100", fontWeight:700 }}>
                  💡 Precio calculado: ${Math.round(precioCalculado).toLocaleString("es-AR")} por {form.categoriaKey==="filamento_pla"?"gramo":"m²"}
                </div>
              )}
            </div>
          )}

          <div>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Stock disponible</label>
            <input type="number" value={form.stock} onChange={e=>setForm(f=>({...f,stock:e.target.value}))} placeholder="0" style={inp}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Categoría (libre)</label>
            <input value={form.categoria||""} onChange={e=>setForm(f=>({...f,categoria:e.target.value}))} placeholder="Vinilo, Tinta..." style={inp}/>
          </div>
          <div style={{ gridColumn:"1/-1" }}>
            <label style={{ display:"block", fontSize:12, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Proveedor</label>
            <select value={form.proveedorId||""} onChange={e=>setForm(f=>({...f,proveedorId:e.target.value}))} style={{ ...inp, cursor:"pointer" }}>
              <option value="">Sin asignar</option>
              {proveedores.map(p=><option key={p.fireId} value={p.fireId}>{p.empresa||p.titular}</option>)}
            </select>
          </div>
        </div>
        <div style={{ display:"flex", gap:10, justifyContent:"flex-end", marginTop:22 }}>
          <button onClick={onClose} style={{ padding:"9px 18px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={handleSave} disabled={saving}
            style={{ padding:"9px 24px", background:"#1a2340", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            {saving?"Guardando...":"✅ Guardar"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Componente: Formulario Insumo (nuevo) ────────────────────────────────
function FormularioInsumo({ view, editingInsumoId, setView, showToast }) {
  const [form, setForm]   = useState({ codigo:"", nombre:"", categoria:"", precioCompra:"", precioVenta:"", precioGremio:"", stock:0, stockMinimo:0 });
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.nombre.trim()) e.nombre = "El nombre es obligatorio";
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      await addDoc(collection(db, "insumos"), {
        ...form,
        precioCompra:  parseFloat(form.precioCompra)||0,
        precioVenta:   parseFloat(form.precioVenta)||0,
        precioGremio:  parseFloat(form.precioGremio)||0,
        stock:         parseFloat(form.stock)||0,
        stockMinimo:   parseFloat(form.stockMinimo)||0,
      });
      showToast("Insumo creado ✅");
      setView("insumos");
    } catch(e) {
      showToast("Error al guardar", "error");
    }
    setSaving(false);
  };

  const inp3 = (field) => ({
    width:"100%", padding:"10px 14px", borderRadius:8,
    border:`1.5px solid ${errors[field]?"#ef5350":"#f0d5c0"}`,
    fontSize:14, fontFamily:"'DM Sans',sans-serif",
    color:"#1a2340", outline:"none", boxSizing:"border-box"
  });

  return (
    <div>
      <button onClick={() => setView("insumos")} style={{ background:"transparent", border:"none", color:"#e65100", fontWeight:600, fontSize:14, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"32px 36px" }}>
        <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:24, fontWeight:700, color:"#1a2340", marginBottom:4 }}>➕ Nuevo Insumo</h2>
        <p style={{ fontSize:14, color:"#a09080", marginBottom:24 }}>Completá los datos del insumo.</p>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
          <div style={{ gridColumn:"1 / -1" }}>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nombre *</label>
            <input value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))} placeholder="Descripción del insumo" style={inp3("nombre")}/>
            {errors.nombre && <div style={{ color:"#ef5350", fontSize:12, marginTop:4 }}>{errors.nombre}</div>}
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Código</label>
            <input value={form.codigo} onChange={e=>setForm(f=>({...f,codigo:e.target.value}))} placeholder="IT01" style={inp3()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Categoría</label>
            <input value={form.categoria} onChange={e=>setForm(f=>({...f,categoria:e.target.value}))} placeholder="TINTA, SUBLIMADO..." style={inp3()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio Compra</label>
            <input type="number" value={form.precioCompra} onChange={e=>setForm(f=>({...f,precioCompra:e.target.value}))} placeholder="0" style={inp3()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio Venta</label>
            <input type="number" value={form.precioVenta} onChange={e=>setForm(f=>({...f,precioVenta:e.target.value}))} placeholder="0" style={inp3()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio Venta Gremio</label>
            <input type="number" value={form.precioGremio} onChange={e=>setForm(f=>({...f,precioGremio:e.target.value}))} placeholder="0" style={inp3()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Stock Mínimo (alerta)</label>
            <input type="number" value={form.stockMinimo} onChange={e=>setForm(f=>({...f,stockMinimo:e.target.value}))} placeholder="0" style={inp3()}/>
          </div>
        </div>
        <div style={{ display:"flex", justifyContent:"flex-end", gap:10, marginTop:28 }}>
          <button onClick={() => setView("insumos")} style={{ padding:"10px 22px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={handleSave} disabled={saving}
            style={{ padding:"10px 28px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer", opacity:saving?.7:1 }}>
            {saving ? "Guardando..." : "✅ Crear Insumo"}
          </button>
        </div>
      </div>
    </div>
  );
}


// ── Componente: Notas del cliente ────────────────────────────────────────
function NotasCliente({ cl, showToast }) {
  const [datos,   setDatos]   = useState({
    archivos:    cl.notasArchivos    || "",
    nroCorte:    cl.notasNroCorte   || "",
    descuento:   cl.notasDescuento  || "",
    notas:       cl.notasGenerales  || "",
  });
  const [guardando, setGuardando] = useState(false);
  const [dirty,     setDirty]     = useState(false);

  const cambiar = (campo, val) => {
    setDatos(d => ({ ...d, [campo]: val }));
    setDirty(true);
  };

  const guardar = async () => {
    setGuardando(true);
    await updateDoc(doc(db, "clientes", cl.fireId), {
      notasArchivos:   datos.archivos,
      notasNroCorte:   datos.nroCorte,
      notasDescuento:  datos.descuento,
      notasGenerales:  datos.notas,
    });
    setGuardando(false);
    setDirty(false);
    showToast("Notas guardadas ✅");
  };

  const inp = { width:"100%", padding:"9px 12px", borderRadius:8, border:"1.5px solid #f0d5c0",
    fontSize:13, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };

  return (
    <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"22px 26px", marginBottom:16 }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18 }}>
        <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:16, fontWeight:700, color:"#1a2340" }}>
          📝 Notas del cliente
        </div>
        {dirty && (
          <button onClick={guardar} disabled={guardando}
            style={{ background:"#e65100", color:"#fff", border:"none", padding:"7px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            {guardando ? "Guardando..." : "💾 Guardar"}
          </button>
        )}
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
        {/* Archivos */}
        <div>
          <label style={{ display:"block", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:6 }}>
            📁 Archivos
          </label>
          <input value={datos.archivos} onChange={e=>cambiar("archivos",e.target.value)}
            placeholder="Ej: Logo-MafeldaV2.ai — Drive/Clientes"
            style={inp}/>
        </div>
        {/* Número de corte */}
        <div>
          <label style={{ display:"block", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:6 }}>
            ✂️ Número de corte
          </label>
          <input value={datos.nroCorte} onChange={e=>cambiar("nroCorte",e.target.value)}
            placeholder="Ej: C-042"
            style={inp}/>
        </div>
        {/* Descuento */}
        <div>
          <label style={{ display:"block", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:6 }}>
            🏷️ Descuento especial
          </label>
          <input value={datos.descuento} onChange={e=>cambiar("descuento",e.target.value)}
            placeholder="Ej: 10% en vinilos siempre"
            style={inp}/>
        </div>
        {/* Notas generales */}
        <div>
          <label style={{ display:"block", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:6 }}>
            💬 Notas generales
          </label>
          <input value={datos.notas} onChange={e=>cambiar("notas",e.target.value)}
            placeholder="Cualquier dato útil del cliente"
            style={inp}/>
        </div>
      </div>

      {/* Preview si hay datos cargados */}
      {!dirty && (datos.archivos||datos.nroCorte||datos.descuento||datos.notas) && (
        <div style={{ background:"#fff8f5", borderRadius:8, padding:"10px 14px", fontSize:12, color:"#4a5568", display:"flex", flexWrap:"wrap", gap:12 }}>
          {datos.archivos  && <span>📁 {datos.archivos}</span>}
          {datos.nroCorte  && <span>✂️ Corte: {datos.nroCorte}</span>}
          {datos.descuento && <span>🏷️ {datos.descuento}</span>}
          {datos.notas     && <span>💬 {datos.notas}</span>}
        </div>
      )}

      {!dirty && !(datos.archivos||datos.nroCorte||datos.descuento||datos.notas) && (
        <div style={{ fontSize:12, color:"#c0bdb9", fontStyle:"italic" }}>Sin notas cargadas — editá los campos de arriba y guardá</div>
      )}
    </div>
  );
}

function ClientesView({ clientes, pedidos, setView, setFormData, setEditingClienteId, showToast, clienteDestacado, setClienteDestacado }) {
  const [busq, setBusq]           = useState("");
  const [selected, setSelected]   = useState(clienteDestacado || null);
  const [pagoModal, setPagoModal] = useState(null);
  const [montoPago, setMontoPago] = useState("");

  // Limpiar el destacado una vez usado
  useEffect(() => {
    if (clienteDestacado && setClienteDestacado) setClienteDestacado(null);
  }, []);

  const filtrados = clientes.filter(c => {
    const q = busq.toLowerCase();
    return !busq || `${c.nombre} ${c.apellido} ${c.empresa||""} ${c.telefono||""} ${c.mail||""} ${c.notasArchivos||""} ${c.notasNroCorte||""} ${c.notasDescuento||""} ${c.notasGenerales||""}`.toLowerCase().includes(q);
  }).sort((a,b) => `${a.nombre}${a.apellido}`.localeCompare(`${b.nombre}${b.apellido}`));

  const pedidosCliente = (cl) => pedidos.filter(p =>
    p.clienteId === cl.fireId || p.cliente === `${cl.nombre} ${cl.apellido}`.trim()
  );

  const handleDelete = async (cl) => {
    if (!window.confirm(`¿Eliminar a ${cl.nombre} ${cl.apellido}?`)) return;
    await deleteDoc(doc(db, "clientes", cl.fireId));
    setSelected(null);
    showToast("Cliente eliminado", "error");
  };

  const handlePago = async () => {
    const monto = parseFloat(montoPago);
    if (!monto || monto <= 0) return;
    const cl = pagoModal.cliente;
    const nuevoSaldo = (parseFloat(cl.saldoCuenta)||0) - monto;
    await updateDoc(doc(db, "clientes", cl.fireId), { saldoCuenta: nuevoSaldo });
    // Registrar movimiento
    await addDoc(collection(db, "movimientosCuenta"), {
      clienteId: cl.fireId,
      tipo: "pago",
      monto,
      fecha: new Date().toISOString().split("T")[0],
      descripcion: "Pago en cuenta corriente"
    });
    showToast(`Pago de $${monto.toLocaleString("es-AR")} registrado ✅`);
    setPagoModal(null);
    setMontoPago("");
  };

  if (selected) {
    const cl = clientes.find(c => c.fireId === selected);
    if (!cl) { setSelected(null); return null; }
    const historial = pedidosCliente(cl).sort((a,b) => b.fechaPedido?.localeCompare(a.fechaPedido||"")||0);
    const saldo = parseFloat(cl.saldoCuenta)||0;
    return (
      <div>
        <button onClick={() => setSelected(null)} style={{ background:"transparent", border:"none", color:"#e65100", fontWeight:600, fontSize:14, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver a clientes</button>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:20 }}>
          {/* Ficha */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"24px 28px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16 }}>
              <div>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:"#1a2340" }}>{cl.nombre} {cl.apellido}</div>
                {cl.empresa && <div style={{ fontSize:13, color:"#a09080", marginTop:2 }}>🏢 {cl.empresa}</div>}
              </div>
              <button onClick={() => { setEditingClienteId(cl.fireId); setView("editarCliente"); }}
                style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"6px 14px", borderRadius:8, fontSize:12, fontWeight:600, cursor:"pointer" }}>
                ✏️ Editar
              </button>
            </div>
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {cl.telefono  && <div style={{ fontSize:13 }}>📞 <strong style={{color:"#e65100"}}>{cl.telefono}</strong></div>}
              {cl.mail      && <div style={{ fontSize:13 }}>✉️ {cl.mail}</div>}
              {cl.cuit      && <div style={{ fontSize:13 }}>🪪 CUIT: {cl.cuit}</div>}
              {cl.direccion && <div style={{ fontSize:13 }}>📍 {cl.direccion}</div>}
            </div>
          </div>
          {/* Cuenta corriente */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"24px 28px" }}>
            <div style={{ fontSize:12, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:8 }}>Cuenta Corriente</div>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:36, fontWeight:700, color:saldo>0?"#c62828":"#2e7d32", marginBottom:16 }}>
              ${Math.abs(saldo).toLocaleString("es-AR")}
            </div>
            <div style={{ fontSize:13, color:"#a09080", marginBottom:16 }}>{saldo>0?"Saldo deudor":"Sin deuda pendiente"}</div>
            {saldo > 0 && (
              <button onClick={() => setPagoModal({ cliente: cl })}
                style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer", width:"100%" }}>
                💵 Registrar Pago
              </button>
            )}
          </div>
        </div>

        {/* Notas del cliente */}
        <NotasCliente cl={cl} showToast={showToast} />

        {/* Historial pedidos */}
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <div style={{ padding:"16px 20px", borderBottom:"1px solid #f5e8e0" }}>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#1a2340" }}>
              📋 Historial de Pedidos ({historial.length})
            </div>
          </div>
          {historial.length === 0 ? (
            <div style={{ padding:"32px", textAlign:"center", color:"#a09080", fontSize:14 }}>Sin pedidos registrados</div>
          ) : (
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
              <thead>
                <tr style={{ background:"#fffaf7" }}>
                  {["Pedido","Estado","Fecha Entrega","Total","Saldo"].map(h => (
                    <th key={h} style={{ padding:"10px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {historial.map(p => {
                  const saldoP = parseFloat(p.precio||0) - parseFloat(p.seña||0);
                  const ec = ESTADO_COLOR[p.estado] || { bg:"#f5f5f5", text:"#616161" };
                  return (
                    <tr key={p.fireId||p.id} style={{ borderBottom:"1px solid #fef0e8" }}>
                      <td style={{ padding:"11px 16px", fontWeight:600, color:"#1a2340" }}>{p.nombre}</td>
                      <td style={{ padding:"11px 16px" }}>
                        <span style={{ background:ec.bg, color:ec.text, padding:"3px 10px", borderRadius:20, fontSize:11, fontWeight:600 }}>{p.estado}</span>
                      </td>
                      <td style={{ padding:"11px 16px", color:"#4a5568" }}>{fmtFecha(p.fechaEntrega)||"—"}</td>
                      <td style={{ padding:"11px 16px", fontWeight:600 }}>{p.precio?`$${parseFloat(p.precio).toLocaleString("es-AR")}`:"—"}</td>
                      <td style={{ padding:"11px 16px", fontWeight:700, color:saldoP>0?"#c62828":"#2e7d32" }}>{p.precio?`$${saldoP.toLocaleString("es-AR")}`:"—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <div style={{ marginTop:16, display:"flex", justifyContent:"flex-end" }}>
          <button onClick={() => handleDelete(cl)} style={{ background:"transparent", border:"1.5px solid #ef5350", color:"#ef5350", padding:"8px 16px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>🗑 Eliminar cliente</button>
        </div>

        {/* Modal pago */}
        {pagoModal && (
          <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200 }} onClick={() => setPagoModal(null)}>
            <div style={{ background:"#fff", borderRadius:16, padding:"32px 36px", width:360, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340", marginBottom:6 }}>💵 Registrar Pago</div>
              <div style={{ fontSize:13, color:"#a09080", marginBottom:20 }}>Saldo actual: <strong style={{color:"#c62828"}}>${(parseFloat(pagoModal.cliente.saldoCuenta)||0).toLocaleString("es-AR")}</strong></div>
              <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Monto del pago</label>
              <input type="number" value={montoPago} onChange={e=>setMontoPago(e.target.value)}
                placeholder="0" autoFocus
                style={{ width:"100%", padding:"11px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:16, fontWeight:700, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box", marginBottom:20 }}/>
              <div style={{ display:"flex", gap:10 }}>
                <button onClick={() => setPagoModal(null)} style={{ flex:1, padding:"10px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
                <button onClick={handlePago} style={{ flex:2, padding:"10px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>✅ Confirmar Pago</button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <div>
          <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:26, fontWeight:700, color:"#1a2340" }}>👥 Clientes</h2>
          <p style={{ fontSize:14, color:"#a09080", marginTop:4 }}>{clientes.length} cliente{clientes.length!==1?"s":""} registrado{clientes.length!==1?"s":""}</p>
        </div>
        <button onClick={() => setView("nuevoCliente")}
          style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 22px", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"'DM Sans',sans-serif" }}>
          ➕ Nuevo Cliente
        </button>
      </div>

      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"14px 18px", marginBottom:18 }}>
        <div style={{ position:"relative" }}>
          <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", fontSize:15 }}>🔍</span>
          <input placeholder="Buscar por nombre, empresa, teléfono..." value={busq} onChange={e=>setBusq(e.target.value)}
            style={{ width:"100%", padding:"10px 14px 10px 34px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" }}/>
        </div>
      </div>

      {filtrados.length === 0 ? (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px 24px", textAlign:"center" }}>
          <div style={{ fontSize:40, marginBottom:14 }}>👥</div>
          <div style={{ fontWeight:700, fontSize:18, fontFamily:"'DM Sans',sans-serif", marginBottom:6 }}>{busq?"Sin resultados":"No hay clientes aún"}</div>
          <div style={{ color:"#a09080", fontSize:14 }}>Agregá tu primer cliente con el botón de arriba</div>
        </div>
      ) : (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
            <thead>
              <tr style={{ background:"#fffaf7" }}>
                {["Cliente","Empresa","Teléfono","Mail","Cuenta Corriente",""].map(h => (
                  <th key={h} style={{ padding:"11px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtrados.map(cl => {
                const saldo = parseFloat(cl.saldoCuenta)||0;
                const nPedidos = pedidosCliente(cl).length;
                return (
                  <tr key={cl.fireId} style={{ borderBottom:"1px solid #fef0e8", cursor:"pointer" }}
                    onMouseOver={e=>e.currentTarget.style.background="#fffaf7"}
                    onMouseOut={e=>e.currentTarget.style.background="#fff"}
                    onClick={() => setSelected(cl.fireId)}>
                    <td style={{ padding:"13px 16px" }}>
                      <div style={{ fontWeight:700, color:"#1a2340" }}>{cl.nombre} {cl.apellido}</div>
                      <div style={{ fontSize:11, color:"#a09080", marginTop:2 }}>{nPedidos} pedido{nPedidos!==1?"s":""}</div>
                      {/* Notas rápidas */}
                      <div style={{ display:"flex", flexWrap:"wrap", gap:4, marginTop:4 }}>
                        {cl.notasNroCorte  && <span style={{ fontSize:10, background:"#e8eaf6", color:"#3949ab", padding:"1px 6px", borderRadius:4, fontWeight:600 }}>✂️ {cl.notasNroCorte}</span>}
                        {cl.notasDescuento && <span style={{ fontSize:10, background:"#e8f5e9", color:"#2e7d32", padding:"1px 6px", borderRadius:4, fontWeight:600 }}>🏷️ {cl.notasDescuento}</span>}
                        {cl.notasArchivos  && <span style={{ fontSize:10, background:"#fff8e1", color:"#e65100", padding:"1px 6px", borderRadius:4, fontWeight:600 }}>📁 {cl.notasArchivos.slice(0,20)}{cl.notasArchivos.length>20?"…":""}</span>}
                      </div>
                    </td>
                    <td style={{ padding:"13px 16px", color:"#4a5568" }}>{cl.empresa||"—"}</td>
                    <td style={{ padding:"13px 16px", fontWeight:700, color:"#e65100" }}>{cl.telefono ? `📞 ${cl.telefono}` : "—"}</td>
                    <td style={{ padding:"13px 16px", color:"#4a5568" }}>{cl.mail||"—"}</td>
                    <td style={{ padding:"13px 16px" }}>
                      {saldo > 0
                        ? <span style={{ fontWeight:700, color:"#c62828", background:"#ffebee", padding:"3px 10px", borderRadius:20, fontSize:12 }}>Debe ${saldo.toLocaleString("es-AR")}</span>
                        : <span style={{ fontWeight:600, color:"#2e7d32", background:"#e8f5e9", padding:"3px 10px", borderRadius:20, fontSize:12 }}>Al día ✓</span>
                      }
                    </td>
                    <td style={{ padding:"13px 16px" }} onClick={e=>e.stopPropagation()}>
                      <div style={{ display:"flex", gap:6 }}>
                        <button onClick={() => { setEditingClienteId(cl.fireId); setView("editarCliente"); }}
                          style={{ background:"#fff8f5", border:"1.5px solid #e65100", color:"#e65100", padding:"5px 10px", borderRadius:6, fontSize:12, fontWeight:600, cursor:"pointer" }}>✏️</button>
                        <button onClick={() => handleDelete(cl)}
                          style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"5px 10px", borderRadius:6, fontSize:12, cursor:"pointer" }}>🗑</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// ── Componente: Formulario de Cliente ────────────────────────────────────
function FormularioCliente({ view, editingClienteId, clientes, setView, setSelectedClienteId, setClienteSearch, setFormData, formData, showToast }) {
  const esEdicion = view === "editarCliente";
  const clienteExistente = esEdicion ? clientes.find(c => c.fireId === editingClienteId) : null;

  const [form, setForm] = useState(clienteExistente || { ...EMPTY_CLIENTE });
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.nombre.trim()) e.nombre = "El nombre es obligatorio";
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSave = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      if (esEdicion && editingClienteId) {
        await updateDoc(doc(db, "clientes", editingClienteId), form);
        showToast("Cliente actualizado ✅");
      } else {
        const ref = await addDoc(collection(db, "clientes"), { ...form, saldoCuenta: 0 });
        // Si venimos del formulario de pedido, seleccionar este cliente
        if (formData?._volver === "formulario") {
          setSelectedClienteId(ref.id);
          setClienteSearch(`${form.nombre} ${form.apellido}`.trim());
          setFormData(p => ({ ...p, cliente:`${form.nombre} ${form.apellido}`.trim(), telefono:form.telefono||"", _volver:undefined }));
          setView("formulario");
          return;
        }
        showToast("Cliente creado exitosamente 🎉");
      }
      setView("clientes");
    } catch(e) {
      showToast("Error al guardar", "error");
    }
    setSaving(false);
  };

  const inp2 = (field) => ({
    width:"100%", padding:"10px 14px", borderRadius:8,
    border:`1.5px solid ${errors[field]?"#ef5350":"#f0d5c0"}`,
    fontSize:14, fontFamily:"'DM Sans',sans-serif",
    color:"#1a2340", outline:"none", boxSizing:"border-box"
  });

  return (
    <div>
      <button onClick={() => setView(esEdicion?"clientes":"clientes")} style={{ background:"transparent", border:"none", color:"#e65100", fontWeight:600, fontSize:14, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"32px 36px" }}>
        <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:24, fontWeight:700, color:"#1a2340", marginBottom:4 }}>
          {esEdicion ? "✏️ Editar Cliente" : "➕ Nuevo Cliente"}
        </h2>
        <p style={{ fontSize:14, color:"#a09080", marginBottom:24 }}>Completá los datos del cliente.</p>

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Nombre *</label>
            <input value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))} placeholder="Nombre" style={inp2("nombre")}/>
            {errors.nombre && <div style={{ color:"#ef5350", fontSize:12, marginTop:4 }}>{errors.nombre}</div>}
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Apellido</label>
            <input value={form.apellido} onChange={e=>setForm(f=>({...f,apellido:e.target.value}))} placeholder="Apellido" style={inp2()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Empresa</label>
            <input value={form.empresa} onChange={e=>setForm(f=>({...f,empresa:e.target.value}))} placeholder="Nombre de la empresa" style={inp2()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>CUIT</label>
            <input value={form.cuit} onChange={e=>setForm(f=>({...f,cuit:e.target.value}))} placeholder="XX-XXXXXXXX-X" style={inp2()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Teléfono / WhatsApp</label>
            <input value={form.telefono} onChange={e=>setForm(f=>({...f,telefono:e.target.value}))} placeholder="11-xxxx-xxxx" style={inp2()}/>
          </div>
          <div>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Mail</label>
            <input value={form.mail} onChange={e=>setForm(f=>({...f,mail:e.target.value}))} placeholder="cliente@mail.com" style={inp2()}/>
          </div>
          <div style={{ gridColumn:"1 / -1" }}>
            <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Dirección</label>
            <input value={form.direccion} onChange={e=>setForm(f=>({...f,direccion:e.target.value}))} placeholder="Calle, número, ciudad" style={inp2()}/>
          </div>
        </div>

        <div style={{ display:"flex", justifyContent:"flex-end", gap:10, marginTop:28 }}>
          <button onClick={() => setView("clientes")} style={{ padding:"10px 22px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={handleSave} disabled={saving}
            style={{ padding:"10px 28px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer", opacity:saving?.7:1 }}>
            {saving ? "Guardando..." : esEdicion ? "💾 Guardar Cambios" : "✅ Crear Cliente"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Buscador Global ───────────────────────────────────────────────────────
function BuscadorGlobal({ pedidos, clientes, busqueda, setBusqueda, onClose, onSelectPedido, onSelectCliente, ESTADO_COLOR, CATEGORIA_COLOR, CATEGORIA_ICON }) {
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const palabras = busqueda.toLowerCase().split(/\s+/).filter(Boolean);

  const matchTexto = (texto) => {
    if (!palabras.length) return false;
    const t = texto.toLowerCase();
    return palabras.every(p => t.includes(p));
  };

  const pedidosFiltrados = busqueda.length >= 2 ? pedidos.filter(p =>
    p.estado !== "Entregado" &&
    matchTexto(`${p.nombre} ${p.cliente} ${p.telefono||""} ${p.categoria} ${p.estado}`)
  ).slice(0, 6) : [];

  const clientesFiltrados = busqueda.length >= 2 ? clientes.filter(c =>
    matchTexto(`${c.nombre} ${c.apellido||""} ${c.empresa||""} ${c.telefono||""} ${c.mail||""}`)
  ).slice(0, 4) : [];

  const total = pedidosFiltrados.length + clientesFiltrados.length;

  return (
    <>
      <div className="busq-global-overlay" onClick={onClose}/>
      <div className="busq-global-box">
        <div style={{ display:"flex", alignItems:"center", borderBottom:"1px solid #f0d5c0", padding:"0 16px" }}>
          <span style={{ fontSize:20, marginRight:10, color:"#e65100" }}>🔍</span>
          <input
            ref={inputRef}
            className="busq-global-input"
            placeholder="Buscar pedidos, clientes, teléfonos..."
            value={busqueda}
            onChange={e => setBusqueda(e.target.value)}
            onKeyDown={e => e.key==="Escape" && onClose()}
          />
          <button onClick={onClose} style={{ background:"transparent", border:"none", color:"#a09080", fontSize:20, cursor:"pointer", padding:"4px 8px" }}>✕</button>
        </div>

        {busqueda.length < 2 ? (
          <div style={{ padding:"24px 20px", textAlign:"center", color:"#a09080", fontSize:14 }}>
            Escribí al menos 2 caracteres para buscar
          </div>
        ) : total === 0 ? (
          <div style={{ padding:"24px 20px", textAlign:"center", color:"#a09080", fontSize:14 }}>
            Sin resultados para "<strong>{busqueda}</strong>"
          </div>
        ) : (
          <div style={{ maxHeight:420, overflowY:"auto" }}>
            {pedidosFiltrados.length > 0 && (
              <>
                <div style={{ padding:"8px 20px 4px", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", background:"#fffaf7" }}>
                  📋 Pedidos ({pedidosFiltrados.length})
                </div>
                {pedidosFiltrados.map(p => {
                  const ec = ESTADO_COLOR[p.estado] || {bg:"#f5f5f5",text:"#616161"};
                  const cc = CATEGORIA_COLOR[p.categoria] || {bg:"#f5f5f5",text:"#424242",accent:"#9e9e9e"};
                  return (
                    <div key={p.fireId||p.id} className="busq-global-result" onClick={() => onSelectPedido(p)}>
                      <span style={{ fontSize:20 }}>{CATEGORIA_ICON[p.categoria]||"📦"}</span>
                      <div style={{ flex:1 }}>
                        <div style={{ fontWeight:600, fontSize:14, color:"#1a2340" }}>{p.nombre}</div>
                        <div style={{ fontSize:12, color:"#a09080" }}>👤 {p.cliente} {p.telefono && `· 📞 ${p.telefono}`}</div>
                      </div>
                      <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:4 }}>
                        <span style={{ background:ec.bg, color:ec.text, padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{p.estado}</span>
                        {p.fechaEntrega && <span style={{ fontSize:11, color:"#a09080" }}>{fmtFecha(p.fechaEntrega)}</span>}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
            {clientesFiltrados.length > 0 && (
              <>
                <div style={{ padding:"8px 20px 4px", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", background:"#fffaf7" }}>
                  👥 Clientes ({clientesFiltrados.length})
                </div>
                {clientesFiltrados.map(c => (
                  <div key={c.fireId} className="busq-global-result" onClick={() => { onSelectCliente(c); }}>
                    <span style={{ fontSize:20 }}>👤</span>
                    <div style={{ flex:1 }}>
                      <div style={{ fontWeight:600, fontSize:14, color:"#1a2340" }}>{c.nombre} {c.apellido}</div>
                      <div style={{ fontSize:12, color:"#a09080" }}>
                        {c.empresa && `🏢 ${c.empresa} · `}
                        {c.telefono && `📞 ${c.telefono}`}
                      </div>
                    </div>
                    {parseFloat(c.saldoCuenta||0) > 0 && (
                      <span style={{ background:"#ffebee", color:"#c62828", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:700 }}>
                        Debe ${parseFloat(c.saldoCuenta).toLocaleString("es-AR")}
                      </span>
                    )}
                  </div>
                ))}
              </>
            )}
          </div>
        )}
        <div style={{ padding:"8px 20px", background:"#fffaf7", borderTop:"1px solid #f0d5c0", fontSize:11, color:"#a09080", display:"flex", justifyContent:"space-between" }}>
          <span>↵ para abrir · Esc para cerrar</span>
          {total > 0 && <span>{total} resultado{total!==1?"s":""}</span>}
        </div>
      </div>
    </>
  );
}

// ── Componente: Finanzas ─────────────────────────────────────────────────
function FinanzasView({ pedidos, clientes, desbloqueado, setDesbloqueado, showToast }) {
  const [pin, setPin]               = useState("");
  const [pinError, setPinError]     = useState(false);
  const [tabActiva, setTabActiva]   = useState("resumen");
  const [ventas, setVentas]         = useState([]);
  const [gastos, setGastos]         = useState([]);
  const [movCaja, setMovCaja]       = useState([]);
  const [empleados, setEmpleados]   = useState([]);
  const [pinConfig, setPinConfig]   = useState("1234");
  const [periodoFin, setPeriodoFin] = useState("mes");

  // Modales
  const [modalGasto, setModalGasto]       = useState(false);
  const [modalCaja, setModalCaja]         = useState(null); // "ingreso" | "egreso"
  const [modalEmpleado, setModalEmpleado] = useState(null);
  const [modalPago, setModalPago]         = useState(null);
  const [selectedEmp, setSelectedEmp]     = useState(null);

  useEffect(() => {
    if (!desbloqueado) return;
    const u1 = onSnapshot(collection(db,"ventas"), snap => setVentas(snap.docs.map(d=>({...d.data(),fireId:d.id}))));
    const u2 = onSnapshot(collection(db,"gastos"), snap => setGastos(snap.docs.map(d=>({...d.data(),fireId:d.id}))));
    const u3 = onSnapshot(collection(db,"movCaja"), snap => setMovCaja(snap.docs.map(d=>({...d.data(),fireId:d.id}))));
    const u4 = onSnapshot(collection(db,"empleados"), snap => setEmpleados(snap.docs.map(d=>({...d.data(),fireId:d.id}))));
    getDoc(doc(db,"config","finanzas")).then(snap => { if(snap.exists()) setPinConfig(snap.data().pin||"1234"); });
    return () => { u1();u2();u3();u4(); };
  }, [desbloqueado]);

  const hoy    = new Date().toISOString().split("T")[0];
  const mesAct = hoy.slice(0,7);
  const semAct = (() => { const d=new Date(); d.setDate(d.getDate()-7); return d.toISOString().split("T")[0]; })();

  const filtrarPeriodo = (arr, campo="fecha") => {
    if (periodoFin==="hoy")   return arr.filter(x=>x[campo]===hoy);
    if (periodoFin==="semana") return arr.filter(x=>x[campo]>=semAct);
    if (periodoFin==="mes")   return arr.filter(x=>x[campo]?.startsWith(mesAct));
    return arr;
  };

  const ventasFilt  = filtrarPeriodo(ventas);
  const gastosFilt  = filtrarPeriodo(gastos);

  const totalVentas    = ventasFilt.reduce((s,v)=>s+parseFloat(v.total||0),0);
  const totalGastos    = gastosFilt.reduce((s,g)=>s+parseFloat(g.monto||0),0);
  const totalEfectivo  = ventasFilt.filter(v=>v.metodoPago==="Efectivo").reduce((s,v)=>s+parseFloat(v.total||0),0);
  const totalTransfer  = ventasFilt.filter(v=>v.metodoPago==="Transferencia").reduce((s,v)=>s+parseFloat(v.total||0),0);
  const totalTarjeta   = ventasFilt.filter(v=>v.metodoPago==="Tarjeta de Crédito").reduce((s,v)=>s+parseFloat(v.total||0),0);
  const totalCtaCte    = ventasFilt.filter(v=>v.metodoPago==="Cuenta Corriente").reduce((s,v)=>s+parseFloat(v.total||0),0);
  const saldoCaja      = movCaja.reduce((s,m)=>s+(m.tipo==="ingreso"?parseFloat(m.monto||0):-parseFloat(m.monto||0)),0) + totalEfectivo;
  const ganancia       = totalVentas - totalGastos;

  // Datos para gráfico de barras (últimos 7 días)
  const ultimos7 = Array.from({length:7},(_,i)=>{
    const d=new Date(); d.setDate(d.getDate()-6+i);
    const f=d.toISOString().split("T")[0];
    const total=ventas.filter(v=>v.fecha===f).reduce((s,v)=>s+parseFloat(v.total||0),0);
    const gastoD=gastos.filter(g=>g.fecha===f).reduce((s,g)=>s+parseFloat(g.monto||0),0);
    return { fecha:f, dia:d.toLocaleDateString("es-AR",{weekday:"short",day:"numeric"}), total, gasto:gastoD };
  });
  const maxBar = Math.max(...ultimos7.map(d=>Math.max(d.total,d.gasto)),1);

  // ── PIN screen ──
  if (!desbloqueado) {
    const handlePin = async () => {
      const snap = await getDoc(doc(db,"config","finanzas")).catch(()=>null);
      const savedPin = snap?.exists() ? snap.data().pin : "1234";
      if (pin === savedPin) { setDesbloqueado(true); setPinError(false); }
      else { setPinError(true); setPin(""); }
    };
    return (
      <div style={{ minHeight:"60vh", display:"flex", alignItems:"center", justifyContent:"center" }}>
        <div style={{ background:"#fff", borderRadius:20, padding:"48px 44px", width:340, boxShadow:"0 8px 32px rgba(230,81,0,.12)", textAlign:"center" }}>
          <div style={{ fontSize:48, marginBottom:12 }}>💼</div>
          <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:"#1a2340", marginBottom:6 }}>Finanzas</div>
          <div style={{ fontSize:14, color:"#a09080", marginBottom:28 }}>Ingresá tu PIN para continuar</div>
          <div style={{ display:"flex", gap:12, justifyContent:"center", marginBottom:24 }}>
            {[0,1,2,3].map(i=>(
              <div key={i} style={{ width:48, height:56, border:`2px solid ${pinError?"#ef5350":pin.length>i?"#e65100":"#f0d5c0"}`, borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", fontSize:24, fontWeight:700, color:"#e65100", background:pin.length>i?"#fff8f5":"#fff", transition:"all .15s" }}>
                {pin.length>i?"●":""}
              </div>
            ))}
          </div>
          {pinError && <div style={{ color:"#ef5350", fontSize:13, marginBottom:14, fontWeight:600 }}>PIN incorrecto. Intentá de nuevo.</div>}
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10, marginBottom:12 }}>
            {[1,2,3,4,5,6,7,8,9,"",0,"⌫"].map((n,i)=>(
              <button key={i} onClick={()=>{
                if(n==="⌫") setPin(p=>p.slice(0,-1));
                else if(n!=="" && pin.length<4) { const np=pin+n; setPin(np); if(np.length===4) setTimeout(()=>{ /* auto check */ },100); }
              }}
              style={{ padding:"14px 0", borderRadius:10, border:"1.5px solid #f0d5c0", background:n===""?"transparent":"#fff", fontSize:18, fontWeight:700, color:"#1a2340", cursor:n===""?"default":"pointer", transition:"all .15s" }}
              onMouseOver={e=>{ if(n!=="") e.currentTarget.style.background="#fff8f5"; }}
              onMouseOut={e=>{ e.currentTarget.style.background=n===""?"transparent":"#fff"; }}>
                {n}
              </button>
            ))}
          </div>
          <button onClick={handlePin} disabled={pin.length<4}
            style={{ width:"100%", padding:"13px", background:pin.length<4?"#f0d5c0":"#e65100", color:"#fff", border:"none", borderRadius:10, fontSize:15, fontWeight:700, cursor:pin.length<4?"not-allowed":"pointer", transition:"all .2s" }}>
            Ingresar
          </button>
        </div>
      </div>
    );
  }

  const TABS = [
    {id:"resumen",   label:"📊 Resumen"},
    {id:"caja",      label:"🏦 Caja"},
    {id:"gastos",    label:"💸 Gastos"},
    {id:"ventas",    label:"🧾 Ventas"},
    {id:"empleados", label:"👷 RRHH"},
    {id:"config",    label:"⚙️ Config"},
  ];

  return (
    <div>
      {/* Header Finanzas */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20, flexWrap:"wrap", gap:12 }}>
        <div>
          <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:26, fontWeight:700, color:"#1a2340" }}>💼 Finanzas</h2>
          <p style={{ fontSize:14, color:"#a09080", marginTop:4 }}>Panel financiero privado</p>
        </div>
        <button onClick={()=>setDesbloqueado(false)}
          style={{ background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", padding:"7px 14px", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>
          🔒 Bloquear
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", gap:6, marginBottom:20, flexWrap:"wrap" }}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTabActiva(t.id)}
            style={{ padding:"8px 16px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none", fontFamily:"'DM Sans',sans-serif",
              background:tabActiva===t.id?"#e65100":"#fff", color:tabActiva===t.id?"#fff":"#4a5568",
              boxShadow:tabActiva===t.id?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
            {t.label}
          </button>
        ))}
        {/* Selector período */}
        <div style={{ marginLeft:"auto", display:"flex", gap:6 }}>
          {["hoy","semana","mes","total"].map(p=>(
            <button key={p} onClick={()=>setPeriodoFin(p)}
              style={{ padding:"7px 14px", borderRadius:20, fontSize:12, fontWeight:600, cursor:"pointer", border:"none",
                background:periodoFin===p?"#1a2340":"#fff", color:periodoFin===p?"#fff":"#4a5568" }}>
              {p==="hoy"?"Hoy":p==="semana"?"Semana":p==="mes"?"Mes":"Total"}
            </button>
          ))}
        </div>
      </div>

      {/* ── TAB: RESUMEN ── */}
      {tabActiva==="resumen" && (
        <div>
          {/* KPIs */}
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:14, marginBottom:24 }}>
            {[
              {label:"Ventas",    value:`$${totalVentas.toLocaleString("es-AR")}`,   color:"#e65100", icon:"💰"},
              {label:"Gastos",    value:`$${totalGastos.toLocaleString("es-AR")}`,   color:"#c62828", icon:"💸"},
              {label:"Ganancia",  value:`$${ganancia.toLocaleString("es-AR")}`,      color:ganancia>=0?"#2e7d32":"#c62828", icon:"📈"},
              {label:"Saldo Caja",value:`$${saldoCaja.toLocaleString("es-AR")}`,     color:"#1565c0", icon:"🏦"},
            ].map((k,i)=>(
              <div key={i} style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"18px 20px" }}>
                <div style={{ fontSize:11, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:8 }}>{k.label}</div>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:k.color }}>{k.value}</div>
                  <span style={{ fontSize:24 }}>{k.icon}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Métodos de pago */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:24 }}>
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px 24px" }}>
              <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:16 }}>💳 Ventas por método de pago</div>
              {metodosConHistorial(ventas).map(m => ({ ...m,
                  value: ventasFilt.filter(v=>v.metodoPago===m.nombre).reduce((s,v)=>s+parseFloat(v.total||0),0) }))
                .filter(m => m.value>0 || getMetodosPago().some(x=>x.nombre===m.nombre))
                .map((m,i)=>(
                <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"8px 0", borderBottom:"1px solid #fef0e8" }}>
                  <span style={{ background:m.bg, color:m.color, padding:"3px 10px", borderRadius:20, fontSize:12, fontWeight:600 }}>{m.label}</span>
                  <span style={{ fontWeight:700, color:m.color, fontSize:15 }}>${m.value.toLocaleString("es-AR")}</span>
                </div>
              ))}
            </div>

            {/* Resumen por día — últimos 7 días */}
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px 24px" }}>
              <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:4 }}>📅 Resumen por día</div>
              <div style={{ fontSize:12, color:"#a09080", marginBottom:14 }}>Últimos 7 días — se reinicia cada día automáticamente</div>
              <div style={{ display:"flex", flexDirection:"column", gap:0 }}>
                {ultimos7.slice().reverse().map((d,i)=>{
                  const esHoy = d.fecha === hoy;
                  const porMetodo = metodosConHistorial(ventas).map(m => ({ ...m,
                    value: ventas.filter(v=>v.fecha===d.fecha&&v.metodoPago===m.nombre).reduce((s,v)=>s+parseFloat(v.total||0),0) }))
                    .filter(m => m.value>0);
                  return (
                    <div key={d.fecha} style={{ borderBottom:i<6?"1px solid #fef0e8":"none", padding:"10px 0" }}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom: d.total>0?6:0 }}>
                        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                          {esHoy && <span style={{ background:"#e65100", color:"#fff", padding:"1px 7px", borderRadius:20, fontSize:10, fontWeight:700 }}>HOY</span>}
                          <span style={{ fontSize:13, fontWeight:esHoy?700:500, color:esHoy?"#1a2340":"#4a5568" }}>{d.dia}</span>
                        </div>
                        <span style={{ fontWeight:700, fontSize:14, color:d.total>0?"#e65100":"#a09080" }}>
                          {d.total>0?`$${d.total.toLocaleString("es-AR")}`:"—"}
                        </span>
                      </div>
                      {d.total>0 && (
                        <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                          {porMetodo.map(m => (
                            <span key={m.nombre} style={{ background:m.bg, color:m.color, padding:"2px 8px", borderRadius:20, fontSize:10, fontWeight:600 }}>{m.label.split(" ")[0]} ${m.value.toLocaleString("es-AR")}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Ventas recientes */}
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px 24px" }}>
            <div style={{ fontWeight:700, fontSize:15, color:"#1a2340", marginBottom:14 }}>🧾 Últimas ventas</div>
            {ventasFilt.length===0 ? <div style={{ color:"#a09080", fontSize:14, textAlign:"center", padding:"20px 0" }}>Sin ventas en este período</div> :
              ventasFilt.slice(0,8).map(v=>(
                <div key={v.fireId} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 0", borderBottom:"1px solid #fef0e8" }}>
                  <div>
                    <div style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{v.clienteNombre||"Consumidor Final"}</div>
                    <div style={{ fontSize:11, color:"#a09080" }}>{v.fecha} · {v.items?.length||0} producto{v.items?.length!==1?"s":""} · {v.metodoPago}</div>
                  </div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:16, fontWeight:700, color:"#e65100" }}>${parseFloat(v.total||0).toLocaleString("es-AR")}</div>
                </div>
              ))
            }
          </div>
        </div>
      )}

      {/* ── TAB: CAJA ── */}
      {tabActiva==="caja" && (
        <div>
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"24px 28px", marginBottom:20, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div>
              <div style={{ fontSize:12, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:6 }}>Saldo en caja</div>
              <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:36, fontWeight:700, color:saldoCaja>=0?"#2e7d32":"#c62828" }}>${saldoCaja.toLocaleString("es-AR")}</div>
              <div style={{ fontSize:12, color:"#a09080", marginTop:4 }}>Incluye ventas en efectivo + movimientos manuales</div>
            </div>
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={()=>setModalCaja("ingreso")} style={{ background:"#e8f5e9", border:"1.5px solid #2e7d32", color:"#2e7d32", padding:"10px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>+ Ingreso</button>
              <button onClick={()=>setModalCaja("egreso")}  style={{ background:"#ffebee", border:"1.5px solid #c62828", color:"#c62828", padding:"10px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>− Egreso</button>
            </div>
          </div>
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
              <thead><tr style={{ background:"#fffaf7" }}>
                {["Fecha","Tipo","Descripción","Monto"].map(h=><th key={h} style={{ padding:"11px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0" }}>{h}</th>)}
              </tr></thead>
              <tbody>
                {[...movCaja,...ventasFilt.filter(v=>v.metodoPago==="Efectivo").map(v=>({tipo:"ingreso",descripcion:`Venta - ${v.clienteNombre||"Consumidor Final"}`,monto:v.total,fecha:v.fecha,fireId:v.fireId+"_v"}))].sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0).slice(0,30).map((m,i)=>(
                  <tr key={i} style={{ borderBottom:"1px solid #fef0e8" }}>
                    <td style={{ padding:"10px 16px", color:"#a09080" }}>{m.fecha}</td>
                    <td style={{ padding:"10px 16px" }}><span style={{ background:m.tipo==="ingreso"?"#e8f5e9":"#ffebee", color:m.tipo==="ingreso"?"#2e7d32":"#c62828", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:700 }}>{m.tipo==="ingreso"?"↑ Ingreso":"↓ Egreso"}</span></td>
                    <td style={{ padding:"10px 16px", color:"#1a2340", fontWeight:500 }}>{m.descripcion||"—"}</td>
                    <td style={{ padding:"10px 16px", fontWeight:700, color:m.tipo==="ingreso"?"#2e7d32":"#c62828" }}>${parseFloat(m.monto||0).toLocaleString("es-AR")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── TAB: GASTOS ── */}
      {tabActiva==="gastos" && (
        <div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340" }}>
              💸 Gastos — <span style={{ color:"#c62828" }}>${totalGastos.toLocaleString("es-AR")}</span>
            </div>
            <button onClick={()=>setModalGasto(true)} style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>+ Cargar Gasto</button>
          </div>
          {gastosFilt.length===0 ? (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px", textAlign:"center", color:"#a09080" }}>Sin gastos en este período</div>
          ) : (
            <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
                <thead><tr style={{ background:"#fffaf7" }}>
                  {["Fecha","Categoría","Descripción","Monto",""].map(h=><th key={h} style={{ padding:"11px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0" }}>{h}</th>)}
                </tr></thead>
                <tbody>
                  {gastosFilt.sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0).map(g=>(
                    <tr key={g.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                      <td style={{ padding:"10px 16px", color:"#a09080" }}>{g.fecha}</td>
                      <td style={{ padding:"10px 16px" }}><span style={{ background:"#ffebee", color:"#c62828", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{g.categoria||"Varios"}</span></td>
                      <td style={{ padding:"10px 16px", color:"#1a2340", fontWeight:500 }}>{g.descripcion}</td>
                      <td style={{ padding:"10px 16px", fontWeight:700, color:"#c62828" }}>${parseFloat(g.monto||0).toLocaleString("es-AR")}</td>
                      <td style={{ padding:"10px 14px" }}><button onClick={async()=>{ await deleteDoc(doc(db,"gastos",g.fireId)); showToast("Gasto eliminado","error"); }} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"4px 8px", borderRadius:6, cursor:"pointer", fontSize:12 }}>🗑</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ── TAB: VENTAS DETALLE ── */}
      {tabActiva==="ventas" && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          <div style={{ padding:"16px 20px", borderBottom:"1px solid #f5e8e0", fontWeight:700, fontSize:15, color:"#1a2340" }}>
            🧾 Detalle de ventas — {ventasFilt.length} venta{ventasFilt.length!==1?"s":""} · ${totalVentas.toLocaleString("es-AR")}
          </div>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
            <thead><tr style={{ background:"#fffaf7" }}>
              {["N°","Fecha","Cliente","Items","Método","Total"].map(h=><th key={h} style={{ padding:"10px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", borderBottom:"1px solid #f5e8e0" }}>{h}</th>)}
            </tr></thead>
            <tbody>
              {ventasFilt.sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0).map(v=>(
                <tr key={v.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                  <td style={{ padding:"10px 16px", color:"#a09080", fontFamily:"monospace", fontSize:12 }}>X-{String(v.numero||1).padStart(5,"0")}</td>
                  <td style={{ padding:"10px 16px", color:"#4a5568" }}>{v.fecha}</td>
                  <td style={{ padding:"10px 16px", fontWeight:600, color:"#1a2340" }}>{v.clienteNombre||"Consumidor Final"}</td>
                  <td style={{ padding:"10px 16px", color:"#4a5568" }}>{v.items?.map(i=>`${i.cantidad}x ${i.nombre}`).join(", ").slice(0,50)||"—"}</td>
                  <td style={{ padding:"10px 16px" }}><span style={{ background:"#fff3e0", color:"#e65100", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{v.metodoPago}</span></td>
                  <td style={{ padding:"10px 16px" }}>
                    <div style={{ display:"flex", gap:6, alignItems:"center" }}>
                      <span style={{ fontFamily:"'DM Sans',sans-serif", fontWeight:700, color:"#e65100", fontSize:15 }}>${parseFloat(v.total||0).toLocaleString("es-AR")}</span>
                      {v.origen==="pedido" && <span style={{ background:"#e8eaf6", color:"#3949ab", padding:"2px 7px", borderRadius:10, fontSize:10, fontWeight:700 }}>PEDIDO</span>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── TAB: EMPLEADOS / RRHH ── */}
      {tabActiva==="empleados" && (
        <div>
          {!selectedEmp ? (
            <div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340" }}>👷 Empleados ({empleados.length})</div>
                <button onClick={()=>setModalEmpleado({})} style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 20px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>+ Nuevo Empleado</button>
              </div>
              {empleados.length===0 ? (
                <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"52px", textAlign:"center", color:"#a09080" }}>Sin empleados cargados</div>
              ) : (
                <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))", gap:16 }}>
                  {empleados.map(e=>(
                    <div key={e.fireId} onClick={()=>setSelectedEmp(e.fireId)}
                      style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"20px 22px", cursor:"pointer", borderTop:"3px solid #e65100" }}
                      onMouseOver={ev=>ev.currentTarget.style.boxShadow="0 6px 24px rgba(230,81,0,.15)"}
                      onMouseOut={ev=>ev.currentTarget.style.boxShadow="0 2px 14px rgba(230,81,0,.07)"}>
                      <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#1a2340", marginBottom:4 }}>{e.nombre}</div>
                      <div style={{ fontSize:13, color:"#a09080", marginBottom:10 }}>{e.cargo||"Sin cargo"}</div>
                      <div style={{ fontSize:13, color:"#e65100", fontWeight:700 }}>Sueldo: ${parseFloat(e.sueldo||0).toLocaleString("es-AR")}</div>
                      {e.ingreso && <div style={{ fontSize:11, color:"#a09080", marginTop:4 }}>Desde: {e.ingreso}</div>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <EmpleadoDetalle
              empId={selectedEmp}
              empleados={empleados}
              setSelectedEmp={setSelectedEmp}
              showToast={showToast}
            />
          )}
        </div>
      )}

      {/* ── TAB: CONFIG PIN ── */}
      {tabActiva==="config" && (
        <div>
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"28px 32px" }}>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#1a2340", marginBottom:6 }}>🔐 Cambiar PIN de Finanzas</div>
            <p style={{ fontSize:14, color:"#a09080", marginBottom:20 }}>El PIN actual es de 4 dígitos. Solo vos debés conocerlo.</p>
            <CambiarPin showToast={showToast} />
          </div>
        </div>
      )}

      {/* ── MODAL: GASTO ── */}
      {modalGasto && <ModalGasto onClose={()=>setModalGasto(false)} showToast={showToast}/>}

      {/* ── MODAL: MOVIMIENTO CAJA ── */}
      {modalCaja && <ModalCaja tipo={modalCaja} onClose={()=>setModalCaja(null)} showToast={showToast}/>}

      {/* ── MODAL: NUEVO EMPLEADO ── */}
      {modalEmpleado && <ModalEmpleado emp={modalEmpleado} onClose={()=>setModalEmpleado(null)} showToast={showToast}/>}
    </div>
  );
}

// ── Detalle Empleado ──────────────────────────────────────────────────────
function EmpleadoDetalle({ empId, empleados, setSelectedEmp, showToast }) {
  const emp = empleados.find(e=>e.fireId===empId);
  const [pagos, setPagos]       = useState([]);
  const [vacas, setVacas]       = useState([]);
  const [notas, setNotas]       = useState([]);
  const [tab, setTab]           = useState("pagos");
  const [modalPago, setModalPago] = useState(false);
  const [modalVaca, setModalVaca] = useState(false);
  const [nuevaNota, setNuevaNota] = useState("");

  useEffect(() => {
    if (!emp) return;
    const u1 = onSnapshot(collection(db,"pagosSueldo"), snap => setPagos(snap.docs.map(d=>({...d.data(),fireId:d.id})).filter(p=>p.empId===empId)));
    const u2 = onSnapshot(collection(db,"vacaciones"), snap => setVacas(snap.docs.map(d=>({...d.data(),fireId:d.id})).filter(v=>v.empId===empId)));
    const u3 = onSnapshot(collection(db,"notasEmp"), snap => setNotas(snap.docs.map(d=>({...d.data(),fireId:d.id})).filter(n=>n.empId===empId)));
    return () => { u1();u2();u3(); };
  }, [empId]);

  if (!emp) return null;

  const totalPagado = pagos.reduce((s,p)=>s+parseFloat(p.monto||0),0);
  const diasTomados = vacas.filter(v=>v.tipo==="tomado").reduce((s,v)=>s+parseInt(v.dias||0),0);
  const diasDisp    = (parseFloat(emp.diasVacaciones||14)) - diasTomados;

  const agregarNota = async () => {
    if (!nuevaNota.trim()) return;
    await addDoc(collection(db,"notasEmp"), { empId, texto:nuevaNota.trim(), fecha:new Date().toISOString().split("T")[0] });
    setNuevaNota("");
    showToast("Nota guardada ✅");
  };

  return (
    <div>
      <button onClick={()=>setSelectedEmp(null)} style={{ background:"transparent", border:"none", color:"#e65100", fontWeight:600, fontSize:14, cursor:"pointer", marginBottom:16 }}>← Volver</button>
      <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", padding:"22px 26px", marginBottom:20, display:"flex", justifyContent:"space-between", alignItems:"flex-start", flexWrap:"wrap", gap:16 }}>
        <div>
          <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:"#1a2340" }}>{emp.nombre}</div>
          <div style={{ fontSize:13, color:"#a09080", marginTop:2 }}>{emp.cargo||"Sin cargo"} · Desde {emp.ingreso||"—"}</div>
          {emp.telefono && <div style={{ fontSize:13, color:"#e65100", fontWeight:700, marginTop:6 }}>📞 {emp.telefono}</div>}
        </div>
        <div style={{ display:"flex", gap:12 }}>
          <div style={{ background:"#fff8f5", borderRadius:10, padding:"10px 16px", textAlign:"center" }}>
            <div style={{ fontSize:10, color:"#a09080", fontWeight:600, textTransform:"uppercase" }}>Sueldo</div>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#e65100" }}>${parseFloat(emp.sueldo||0).toLocaleString("es-AR")}</div>
          </div>
          <div style={{ background:"#f1f8e9", borderRadius:10, padding:"10px 16px", textAlign:"center" }}>
            <div style={{ fontSize:10, color:"#a09080", fontWeight:600, textTransform:"uppercase" }}>Días vac.</div>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#2e7d32" }}>{diasDisp}</div>
          </div>
          <div style={{ background:"#e3f2fd", borderRadius:10, padding:"10px 16px", textAlign:"center" }}>
            <div style={{ fontSize:10, color:"#a09080", fontWeight:600, textTransform:"uppercase" }}>Total pagado</div>
            <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:18, fontWeight:700, color:"#1565c0" }}>${totalPagado.toLocaleString("es-AR")}</div>
          </div>
        </div>
      </div>

      {/* Tabs empleado */}
      <div style={{ display:"flex", gap:8, marginBottom:16 }}>
        {[["pagos","💵 Pagos"],["vacaciones","🏖️ Vacaciones"],["notas","📝 Notas"]].map(([t,l])=>(
          <button key={t} onClick={()=>setTab(t)}
            style={{ padding:"7px 16px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", border:"none",
              background:tab===t?"#e65100":"#fff", color:tab===t?"#fff":"#4a5568",
              boxShadow:tab===t?"0 3px 10px rgba(230,81,0,.2)":"0 1px 6px rgba(230,81,0,.07)" }}>
            {l}
          </button>
        ))}
        <button onClick={()=>setModalPago(true)} style={{ marginLeft:"auto", background:"#2e7d32", color:"#fff", border:"none", padding:"7px 16px", borderRadius:20, fontSize:13, fontWeight:700, cursor:"pointer" }}>+ Registrar Pago</button>
      </div>

      {tab==="pagos" && (
        <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
          {pagos.length===0 ? <div style={{ padding:"32px", textAlign:"center", color:"#a09080" }}>Sin pagos registrados</div> :
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
              <thead><tr style={{ background:"#fffaf7" }}>
                {["Fecha","Concepto","Monto",""].map(h=><th key={h} style={{ padding:"10px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", borderBottom:"1px solid #f5e8e0" }}>{h}</th>)}
              </tr></thead>
              <tbody>
                {pagos.sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0).map(p=>(
                  <tr key={p.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                    <td style={{ padding:"10px 16px", color:"#a09080" }}>{p.fecha}</td>
                    <td style={{ padding:"10px 16px", color:"#1a2340", fontWeight:500 }}>{p.concepto||"Sueldo"}</td>
                    <td style={{ padding:"10px 16px", fontWeight:700, color:"#2e7d32" }}>${parseFloat(p.monto||0).toLocaleString("es-AR")}</td>
                    <td style={{ padding:"10px 14px" }}><button onClick={async()=>{ await deleteDoc(doc(db,"pagosSueldo",p.fireId)); showToast("Eliminado","error"); }} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"3px 7px", borderRadius:5, cursor:"pointer", fontSize:11 }}>🗑</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          }
        </div>
      )}

      {tab==="vacaciones" && (
        <div>
          <div style={{ display:"flex", justifyContent:"flex-end", marginBottom:12 }}>
            <button onClick={()=>setModalVaca(true)} style={{ background:"#e65100", color:"#fff", border:"none", padding:"8px 16px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>+ Registrar Vacaciones</button>
          </div>
          <div style={{ background:"#fff", borderRadius:14, boxShadow:"0 2px 14px rgba(230,81,0,.07)", overflow:"hidden" }}>
            {vacas.length===0 ? <div style={{ padding:"32px", textAlign:"center", color:"#a09080" }}>Sin registros de vacaciones</div> :
              <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13 }}>
                <thead><tr style={{ background:"#fffaf7" }}>
                  {["Fecha","Tipo","Días","Nota",""].map(h=><th key={h} style={{ padding:"10px 16px", textAlign:"left", fontSize:11, fontWeight:700, color:"#a09080", textTransform:"uppercase", borderBottom:"1px solid #f5e8e0" }}>{h}</th>)}
                </tr></thead>
                <tbody>
                  {vacas.sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0).map(v=>(
                    <tr key={v.fireId} style={{ borderBottom:"1px solid #fef0e8" }}>
                      <td style={{ padding:"10px 16px", color:"#a09080" }}>{v.fecha}</td>
                      <td style={{ padding:"10px 16px" }}><span style={{ background:v.tipo==="tomado"?"#fff3e0":"#e8f5e9", color:v.tipo==="tomado"?"#e65100":"#2e7d32", padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600 }}>{v.tipo==="tomado"?"Tomado":"Acreditado"}</span></td>
                      <td style={{ padding:"10px 16px", fontWeight:700 }}>{v.dias}</td>
                      <td style={{ padding:"10px 16px", color:"#4a5568" }}>{v.nota||"—"}</td>
                      <td style={{ padding:"10px 14px" }}><button onClick={async()=>{ await deleteDoc(doc(db,"vacaciones",v.fireId)); }} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"3px 7px", borderRadius:5, cursor:"pointer", fontSize:11 }}>🗑</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            }
          </div>
        </div>
      )}

      {tab==="notas" && (
        <div>
          <div style={{ display:"flex", gap:10, marginBottom:16 }}>
            <input value={nuevaNota} onChange={e=>setNuevaNota(e.target.value)} onKeyDown={e=>e.key==="Enter"&&agregarNota()}
              placeholder="Escribí una nota sobre el empleado..."
              style={{ flex:1, padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none" }}/>
            <button onClick={agregarNota} style={{ background:"#e65100", color:"#fff", border:"none", padding:"10px 18px", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>Agregar</button>
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {notas.sort((a,b)=>b.fecha?.localeCompare(a.fecha||"")||0).map(n=>(
              <div key={n.fireId} style={{ background:"#fff", borderRadius:10, padding:"14px 18px", boxShadow:"0 1px 6px rgba(230,81,0,.07)", display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                <div>
                  <div style={{ fontSize:14, color:"#1a2340", lineHeight:1.5 }}>{n.texto}</div>
                  <div style={{ fontSize:11, color:"#a09080", marginTop:4 }}>{n.fecha}</div>
                </div>
                <button onClick={async()=>{ await deleteDoc(doc(db,"notasEmp",n.fireId)); }} style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"3px 7px", borderRadius:5, cursor:"pointer", fontSize:11 }}>🗑</button>
              </div>
            ))}
          </div>
        </div>
      )}

      {modalPago && (
        <ModalSimple titulo="💵 Registrar Pago de Sueldo" onClose={()=>setModalPago(false)} onSave={async(form)=>{
          await addDoc(collection(db,"pagosSueldo"),{empId,...form,fecha:form.fecha||new Date().toISOString().split("T")[0]});
          showToast("Pago registrado ✅"); setModalPago(false);
        }} campos={[{key:"monto",label:"Monto",type:"number",placeholder:"0"},{key:"concepto",label:"Concepto",placeholder:"Sueldo quincenal..."},{key:"fecha",label:"Fecha",type:"date"}]}/>
      )}
      {modalVaca && (
        <ModalSimple titulo="🏖️ Registrar Vacaciones" onClose={()=>setModalVaca(false)} onSave={async(form)=>{
          await addDoc(collection(db,"vacaciones"),{empId,...form,fecha:form.fecha||new Date().toISOString().split("T")[0]});
          showToast("Vacaciones registradas ✅"); setModalVaca(false);
        }} campos={[{key:"dias",label:"Días",type:"number",placeholder:"0"},{key:"tipo",label:"Tipo",type:"select",options:["tomado","acreditado"]},{key:"nota",label:"Nota",placeholder:"Opcional..."},{key:"fecha",label:"Fecha",type:"date"}]}/>
      )}
    </div>
  );
}

// ── Modal Simple reutilizable ─────────────────────────────────────────────
function ModalSimple({ titulo, campos, onClose, onSave }) {
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const inp = { width:"100%", padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };
  const handleSave = async () => { setSaving(true); await onSave(form); setSaving(false); };
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:300 }} onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:420, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
        <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:"#1a2340", marginBottom:20 }}>{titulo}</div>
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          {campos.map(c=>(
            <div key={c.key}>
              <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>{c.label}</label>
              {c.type==="select"
                ? <select value={form[c.key]||""} onChange={e=>setForm(f=>({...f,[c.key]:e.target.value}))} style={{ ...inp, cursor:"pointer" }}>
                    <option value="">Seleccionar...</option>
                    {c.options.map(o=><option key={o} value={o}>{o.charAt(0).toUpperCase()+o.slice(1)}</option>)}
                  </select>
                : <input type={c.type||"text"} value={form[c.key]||""} onChange={e=>setForm(f=>({...f,[c.key]:e.target.value}))} placeholder={c.placeholder||""} style={inp}/>
              }
            </div>
          ))}
        </div>
        <div style={{ display:"flex", gap:10, justifyContent:"flex-end", marginTop:20 }}>
          <button onClick={onClose} style={{ padding:"9px 18px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:13, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={handleSave} disabled={saving} style={{ padding:"9px 22px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:13, fontWeight:700, cursor:"pointer" }}>
            {saving?"Guardando...":"✅ Guardar"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Modales Finanzas ──────────────────────────────────────────────────────
function ModalGasto({ onClose, showToast }) {
  return <ModalSimple titulo="💸 Cargar Gasto" onClose={onClose} onSave={async(form)=>{
    await addDoc(collection(db,"gastos"),{...form,fecha:form.fecha||new Date().toISOString().split("T")[0],monto:parseFloat(form.monto)||0});
    showToast("Gasto cargado ✅"); onClose();
  }} campos={[{key:"descripcion",label:"Descripción",placeholder:"Ej: Compra de insumos"},{key:"monto",label:"Monto",type:"number",placeholder:"0"},{key:"categoria",label:"Categoría",placeholder:"Insumos, Servicios, Personal..."},{key:"fecha",label:"Fecha",type:"date"}]}/>;
}

function ModalCaja({ tipo, onClose, showToast }) {
  return <ModalSimple titulo={tipo==="ingreso"?"+ Ingreso Manual a Caja":"− Egreso Manual de Caja"} onClose={onClose} onSave={async(form)=>{
    await addDoc(collection(db,"movCaja"),{...form,tipo,fecha:form.fecha||new Date().toISOString().split("T")[0],monto:parseFloat(form.monto)||0});
    showToast(`${tipo==="ingreso"?"Ingreso":"Egreso"} registrado ✅`); onClose();
  }} campos={[{key:"monto",label:"Monto",type:"number",placeholder:"0"},{key:"descripcion",label:"Descripción",placeholder:"Motivo..."},{key:"fecha",label:"Fecha",type:"date"}]}/>;
}

function ModalEmpleado({ emp, onClose, showToast }) {
  return <ModalSimple titulo={emp.fireId?"✏️ Editar Empleado":"👷 Nuevo Empleado"} onClose={onClose} onSave={async(form)=>{
    if(emp.fireId) { await updateDoc(doc(db,"empleados",emp.fireId),form); showToast("Empleado actualizado ✅"); }
    else { await addDoc(collection(db,"empleados"),form); showToast("Empleado creado ✅"); }
    onClose();
  }} campos={[{key:"nombre",label:"Nombre completo",placeholder:"Nombre y apellido"},{key:"cargo",label:"Cargo",placeholder:"Cajero, Operario..."},{key:"sueldo",label:"Sueldo base",type:"number",placeholder:"0"},{key:"ingreso",label:"Fecha de ingreso",type:"date"},{key:"telefono",label:"Teléfono",placeholder:"11-xxxx-xxxx"},{key:"diasVacaciones",label:"Días de vacaciones/año",type:"number",placeholder:"14"}]}/>;
}

function CambiarPin({ showToast }) {
  const [pinActual, setPinActual] = useState("");
  const [pinNuevo, setPinNuevo]   = useState("");
  const [pinConf, setPinConf]     = useState("");
  const [saving, setSaving]       = useState(false);
  const inp = { width:"100%", padding:"10px 14px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", boxSizing:"border-box" };
  const handleSave = async () => {
    if (pinNuevo.length!==4||!/^\d{4}$/.test(pinNuevo)) { showToast("El PIN debe ser exactamente 4 dígitos","error"); return; }
    if (pinNuevo!==pinConf) { showToast("Los PINs no coinciden","error"); return; }
    setSaving(true);
    const snap = await getDoc(doc(db,"config","finanzas")).catch(()=>null);
    const savedPin = snap?.exists() ? snap.data().pin : "1234";
    if (pinActual!==savedPin) { showToast("PIN actual incorrecto","error"); setSaving(false); return; }
    await setDoc(doc(db,"config","finanzas"),{pin:pinNuevo});
    showToast("PIN actualizado ✅"); setPinActual(""); setPinNuevo(""); setPinConf(""); setSaving(false);
  };
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
      <div><label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>PIN actual</label><input type="password" maxLength={4} value={pinActual} onChange={e=>setPinActual(e.target.value)} placeholder="••••" style={inp}/></div>
      <div><label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>PIN nuevo (4 dígitos)</label><input type="password" maxLength={4} value={pinNuevo} onChange={e=>setPinNuevo(e.target.value)} placeholder="••••" style={inp}/></div>
      <div><label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Confirmar PIN nuevo</label><input type="password" maxLength={4} value={pinConf} onChange={e=>setPinConf(e.target.value)} placeholder="••••" style={inp}/></div>
      <button onClick={handleSave} disabled={saving} style={{ padding:"11px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer", marginTop:4 }}>
        {saving?"Guardando...":"🔐 Cambiar PIN"}
      </button>
      <p style={{ fontSize:12, color:"#a09080" }}>El PIN por defecto es <strong>1234</strong>. Cambialo antes de usar.</p>
    </div>
  );
}

// ── Modal Confirmar Entrega ───────────────────────────────────────────────
function EntregaModal({ pedido, onConfirmar, onClose }) {
  const [metodoPago, setMetodoPago] = useState("Efectivo");
  const saldo = parseFloat(pedido.precio||0) - parseFloat(pedido.seña||0);

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:600 }} onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"32px 36px", width:420, boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
        <div style={{ textAlign:"center", marginBottom:20 }}>
          <div style={{ fontSize:48, marginBottom:10 }}>📦</div>
          <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:"#1a2340", marginBottom:6 }}>Confirmar Entrega</div>
          <div style={{ fontSize:14, color:"#4a5568", fontWeight:600 }}>{pedido.nombre}</div>
          <div style={{ fontSize:13, color:"#a09080", marginTop:4 }}>Cliente: {pedido.cliente}</div>
        </div>

        {/* Resumen de cobro */}
        <div style={{ background:"#fff8f5", borderRadius:10, padding:"14px 18px", marginBottom:20 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6, fontSize:13 }}>
            <span style={{ color:"#a09080" }}>Total del pedido:</span>
            <span style={{ fontWeight:700 }}>${parseFloat(pedido.precio||0).toLocaleString("es-AR")}</span>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6, fontSize:13 }}>
            <span style={{ color:"#a09080" }}>Seña cobrada:</span>
            <span style={{ fontWeight:700, color:"#2e7d32" }}>${parseFloat(pedido.seña||0).toLocaleString("es-AR")}</span>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", borderTop:"1.5px solid #f0d5c0", paddingTop:8, marginTop:4 }}>
            <span style={{ fontWeight:700, color:"#1a2340" }}>Saldo a cobrar:</span>
            <span style={{ fontFamily:"'DM Sans',sans-serif", fontSize:20, fontWeight:700, color:saldo>0?"#c62828":"#2e7d32" }}>
              ${saldo.toLocaleString("es-AR")}
            </span>
          </div>
        </div>

        {/* Método de pago */}
        <div style={{ marginBottom:22 }}>
          <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:10 }}>Método de pago del saldo:</label>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
            {getMetodosPago().map(x=>x.nombre).map(m=>(
              <button key={m} onClick={()=>setMetodoPago(m)}
                style={{ padding:"10px 8px", borderRadius:8, fontSize:12, fontWeight:700, cursor:"pointer",
                  border:`2px solid ${metodoPago===m?"#e65100":"#f0d5c0"}`,
                  background:metodoPago===m?"#e65100":"#fff",
                  color:metodoPago===m?"#fff":"#4a5568", transition:"all .15s" }}>
                {labelMetodo(m)}
              </button>
            ))}
          </div>
        </div>

        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onClose}
            style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>
            Cancelar
          </button>
          <button onClick={()=>onConfirmar(pedido, metodoPago)}
            style={{ flex:2, padding:"11px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
            ✅ Confirmar Entrega
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Modal: Entrega múltiple ──────────────────────────────────────────────
function EntregaMultipleModal({ pedidos, onConfirmar, onClose }) {
  const [metodoPago, setMetodoPago] = useState("Efectivo");
  const [saving, setSaving]         = useState(false);
  const saldoDe = p => parseFloat(p.precio||0) - parseFloat(p.seña||0);
  const total   = pedidos.reduce((s,p) => s + saldoDe(p), 0);
  const sinCliente = pedidos.filter(p => !p.clienteId).length;

  const confirmar = async () => {
    setSaving(true);
    try { await onConfirmar(pedidos, metodoPago); }
    catch(e) { console.error(e); alert("Hubo un error al registrar las entregas."); setSaving(false); }
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.5)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:600, padding:16 }} onClick={saving?undefined:onClose}>
      <div style={{ background:"#fff", borderRadius:16, padding:"28px 32px", width:480, maxHeight:"90vh", overflowY:"auto", boxShadow:"0 20px 60px rgba(0,0,0,.2)" }} onClick={e=>e.stopPropagation()}>
        <div style={{ textAlign:"center", marginBottom:18 }}>
          <div style={{ fontSize:44, marginBottom:8 }}>📦</div>
          <div style={{ fontSize:21, fontWeight:700, color:"#1a2340" }}>Entregar {pedidos.length} pedido{pedidos.length!==1?"s":""}</div>
        </div>

        <div style={{ background:"#fff8f5", borderRadius:10, padding:"10px 14px", marginBottom:16, maxHeight:220, overflowY:"auto" }}>
          {pedidos.map(p => (
            <div key={p.fireId} style={{ display:"flex", justifyContent:"space-between", gap:10, padding:"6px 0", borderBottom:"1px solid #f5e8e0", fontSize:13 }}>
              <div style={{ minWidth:0 }}>
                <div style={{ fontWeight:600, color:"#1a2340", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                  {p.nroOT ? <span style={{ fontFamily:"monospace", color:"#e65100", marginRight:6 }}>OT-{String(p.nroOT).padStart(4,"0")}</span> : null}{p.nombre}
                </div>
                <div style={{ fontSize:11, color:"#a09080" }}>{p.cliente||"Sin cliente"}</div>
              </div>
              <div style={{ fontWeight:700, color:saldoDe(p)>0?"#c62828":"#2e7d32", whiteSpace:"nowrap" }}>${saldoDe(p).toLocaleString("es-AR")}</div>
            </div>
          ))}
          <div style={{ display:"flex", justifyContent:"space-between", paddingTop:10 }}>
            <span style={{ fontWeight:700, color:"#1a2340" }}>Total a cobrar</span>
            <span style={{ fontSize:20, fontWeight:800, color:total>0?"#c62828":"#2e7d32" }}>${total.toLocaleString("es-AR")}</span>
          </div>
        </div>

        <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:10 }}>Método de pago (se aplica a todos):</label>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:metodoPago==="Cuenta Corriente"&&sinCliente?10:20 }}>
          {getMetodosPago().map(x=>[x.nombre, labelMetodo(x.nombre)]).map(([m,l])=>(
            <button key={m} onClick={()=>setMetodoPago(m)}
              style={{ padding:"10px 8px", borderRadius:8, fontSize:12, fontWeight:700, cursor:"pointer",
                border:`2px solid ${metodoPago===m?"#e65100":"#f0d5c0"}`, background:metodoPago===m?"#e65100":"#fff", color:metodoPago===m?"#fff":"#4a5568" }}>{l}</button>
          ))}
        </div>
        {metodoPago==="Cuenta Corriente" && sinCliente>0 && (
          <div style={{ fontSize:12, color:"#c62828", background:"#ffebee", padding:"8px 12px", borderRadius:7, marginBottom:16 }}>
            ⚠️ {sinCliente} pedido{sinCliente!==1?"s no tienen":" no tiene"} cliente vinculado: se marcan entregados pero no suman a ninguna cuenta corriente.
          </div>
        )}
        <div style={{ fontSize:12, color:"#a09080", marginBottom:16 }}>
          Si alguno se pagó distinto, entregalo aparte con su propio botón 📦.
        </div>

        <div style={{ display:"flex", gap:10 }}>
          <button onClick={onClose} disabled={saving}
            style={{ flex:1, padding:"11px", background:"transparent", border:"1.5px solid #f0d5c0", color:"#a09080", borderRadius:8, fontSize:14, fontWeight:600, cursor:"pointer" }}>Cancelar</button>
          <button onClick={confirmar} disabled={saving}
            style={{ flex:2, padding:"11px", background:"#e65100", color:"#fff", border:"none", borderRadius:8, fontSize:14, fontWeight:700, cursor:"pointer" }}>
            {saving ? "Registrando..." : `✅ Confirmar ${pedidos.length} entrega${pedidos.length!==1?"s":""}`}
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Componente: Modal Mensaje WhatsApp ───────────────────────────────────
function MsgModal({ pedido, copied, setCopied, onClose }) {
  const p    = pedido;
  const msg  = armarMensajeListo(p); // plantilla editable en Configuración → Mensajes

  const handleCopy = () => {
    navigator.clipboard.writeText(document.getElementById("msg-cliente-textarea")?.value || msg).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const handleWhatsApp = () => {
    const tel = telWhatsapp(p.telefono);
    const textoFinal = document.getElementById("msg-cliente-textarea")?.value || msg;
    const url = tel
      ? `https://wa.me/${tel}?text=${encodeURIComponent(textoFinal)}`
      : `https://wa.me/?text=${encodeURIComponent(textoFinal)}`;
    window.open(url, "_blank");
  };

  return (
    <div className="modal-ov" onClick={onClose}>
      <div className="msg-bx" onClick={e => e.stopPropagation()}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:18 }}>
          <div style={{ fontSize:36 }}>💬</div>
          <div>
            <h3 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:21, fontWeight:700, color:"#1a2340", lineHeight:1.1 }}>Mensaje para el cliente</h3>
            <p style={{ fontSize:13, color:"#a09080", marginTop:3 }}>Copiá el mensaje o abrí WhatsApp directo</p>
          </div>
        </div>
        <div style={{ background:"#e8f5e9", borderRadius:8, padding:"8px 14px", marginBottom:14, display:"flex", alignItems:"center", gap:8, fontSize:13 }}>
          <span>🏢</span>
          <span style={{ fontWeight:600, color:"#1b5e20" }}>{p.cliente}</span>
          {p.telefono && <span style={{ color:"#4a5568" }}>· {p.telefono}</span>}
          {p.nroOT && <span style={{ marginLeft:"auto", fontFamily:"monospace", fontWeight:700, color:"#e65100", background:"#fff8f5", padding:"2px 8px", borderRadius:5, border:"1px solid #f0d5c0" }}>OT-{String(p.nroOT).padStart(4,"0")}</span>}
        </div>
        <textarea className="msg-textarea" rows={6} defaultValue={msg} id="msg-cliente-textarea"
          onChange={e => e.target.value}
          style={{ width:"100%", padding:"12px", borderRadius:8, border:"1.5px solid #f0d5c0", fontSize:14, fontFamily:"'DM Sans',sans-serif", resize:"vertical", outline:"none", boxSizing:"border-box" }}/>
        <div style={{ display:"flex", gap:10, marginTop:16, justifyContent:"flex-end" }}>
          <button className="btn-g" style={{ padding:"10px 20px" }} onClick={onClose}>Cerrar</button>
          <button className={`btn-copy${copied?" copied":""}`} onClick={handleCopy}>
            {copied ? "✅ ¡Copiado!" : "📋 Copiar"}
          </button>
          <button onClick={handleWhatsApp}
            style={{ background:"#25d366", color:"#fff", border:"none", borderRadius:8, padding:"10px 18px", fontSize:13, fontWeight:700, cursor:"pointer", display:"flex", alignItems:"center", gap:6 }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.122.553 4.112 1.52 5.842L0 24l6.336-1.498A11.956 11.956 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.885 0-3.652-.518-5.17-1.42l-.37-.22-3.762.889.924-3.668-.242-.378A9.944 9.944 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
            WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Componente: Precio editable inline ───────────────────────────────────
function InlineEditPrecio({ value, color, onSave, size=22 }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal]         = useState(value);
  const inputRef              = useRef(null);

  useEffect(() => { setVal(value); }, [value]);
  useEffect(() => { if (editing && inputRef.current) inputRef.current.select(); }, [editing]);

  const confirmar = async () => {
    setEditing(false);
    if (val !== value) await onSave(val);
  };

  if (editing) return (
    <div style={{ display:"flex", alignItems:"center", gap:4 }}>
      <span style={{ color:"#a09080", fontWeight:600 }}>$</span>
      <input ref={inputRef} type="number" value={val}
        onChange={e=>setVal(e.target.value)}
        onBlur={confirmar}
        onKeyDown={e=>{ if(e.key==="Enter") confirmar(); if(e.key==="Escape") setEditing(false); }}
        style={{ width:90, padding:"3px 6px", borderRadius:6, border:`2px solid ${color}`, fontSize:size,
          fontWeight:700, fontFamily:"'DM Sans',sans-serif", color, textAlign:"center", outline:"none" }}/>
    </div>
  );

  const display = value ? `$${parseFloat(value).toLocaleString("es-AR")}` : "— agregar";
  const isEmpty = !value;

  return (
    <div onClick={()=>setEditing(true)} title="Clic para editar"
      style={{ cursor:"pointer", display:"inline-flex", alignItems:"center", gap:4,
        borderRadius:6, padding:"2px 6px", transition:"background .15s" }}
      onMouseEnter={e=>e.currentTarget.style.background="#fff0e8"}
      onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
      <span style={{ fontFamily:"'DM Sans',sans-serif", fontSize:size, fontWeight:700,
        color: isEmpty ? "#c0bdb9" : color,
        fontStyle: isEmpty ? "italic" : "normal" }}>
        {display}
      </span>
      <span style={{ fontSize:11, color:"#c0bdb9" }}>✏️</span>
    </div>
  );
}

// ── Helper para imprimir con config lista ────────────────────────────────
function imprimirConConfig(fn, empresa, configCargada) {
  if (!configCargada) {
    alert("Cargando datos del local, intentá en un momento...");
    return;
  }
  fn(empresa);
}

export default function App() {
  const [pedidos, setPedidos]             = useState([]);
  const [loading, setLoading]             = useState(true);
  const [user, setUser]                   = useState(null);
  const [authChecked, setAuthChecked]     = useState(false);
  const [view, setView]                   = useState("lista");
  const [selectedPedido, setSelectedPedido] = useState(null);
  const [formData, setFormData]           = useState(EMPTY_FORM);
  const [editingId, setEditingId]         = useState(null);
  const [busqueda, setBusqueda]           = useState("");
  const [filtroEstado, setFiltroEstado]   = useState("Todos");
  const [filtroCategoria, setFiltroCategoria] = useState("Todas");
  const [toast, setToast]                 = useState(null);
  const [errors, setErrors]               = useState({});
  const [expandedCats, setExpandedCats]   = useState({});
  const [printModal, setPrintModal]       = useState(null);
  const [msgModal, setMsgModal]           = useState(null);
  const [copied, setCopied]               = useState(false);
  const [empresa, setEmpresa]             = useState(EMPTY_EMPRESA);
  const [empresaSaved, setEmpresaSaved]   = useState(false);
  const [configCargada, setConfigCargada] = useState(false);
  const [vistaLista, setVistaLista]       = useState("categorias");
  const [showStats, setShowStats]         = useState(true);
  const [clientes, setClientes]           = useState([]);
  const [clienteSearch, setClienteSearch] = useState("");
  const [clienteDropdown, setClienteDropdown] = useState(false);
  const [selectedClienteId, setSelectedClienteId] = useState(null);
  const [editingClienteId, setEditingClienteId]   = useState(null);
  const [clienteDestacado, setClienteDestacado]   = useState(null); // objeto cliente a abrir directo
  const [editingInsumoId, setEditingInsumoId]     = useState(null);
  const [nuevoEventoModal, setNuevoEventoModal]   = useState(false);
  const [menuAbierto, setMenuAbierto] = useState(typeof window !== "undefined" ? window.innerWidth > 900 : true);
  const [finanzasDesbloqueado, setFinanzasDesbloqueado] = useState(false);
  const [entregaModal, setEntregaModal]               = useState(null); // { pedido }
  const [busquedaGlobal, setBusquedaGlobal]       = useState("");
  const [busqGlobalOpen, setBusqGlobalOpen]       = useState(false);
  const [planillaFlotante, setPlanillaFlotante]   = useState(false);
  const [empleados, setEmpleados]                 = useState([]);
  const [catsVersion, setCatsVersion]             = useState(0);
  const [cfgVersion, setCfgVersion]               = useState(0);

  // ── Firebase: configuración general (mensajes, documentos, pagos, menú) ──
  useEffect(() => {
    const unsub = onSnapshot(doc(db, "config", "app"), snap => {
      aplicarAppCfg(snap.exists() ? snap.data() : null);
      setCfgVersion(v => v + 1);
    });
    return () => unsub();
  }, []);

  // ── Firebase: categorías configurables ──
  useEffect(() => {
    const unsub = onSnapshot(doc(db, "config", "categorias"), snap => {
      aplicarCategorias(snap.exists() ? snap.data().lista : null);
      setCatsVersion(v => v + 1);
    });
    return () => unsub();
  }, []);

  // ── Firebase: verificar sesión ──
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthChecked(true);
    });
    return () => unsub();
  }, []);

  // ── Firebase: escuchar pedidos en tiempo real ──
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "pedidos"), (snap) => {
      const data = snap.docs.map(d => ({ ...d.data(), fireId: d.id }));
      data.sort((a,b) => (a.id||0) - (b.id||0));
      setPedidos(data);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  // ── Firebase: escuchar clientes en tiempo real ──
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "clientes"), (snap) => {
      setClientes(snap.docs.map(d => ({ ...d.data(), fireId: d.id })));
    });
    return () => unsub();
  }, []);

  // ── Firebase: escuchar empleados ──
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "empleados"), snap =>
      setEmpleados(snap.docs.map(d => ({ ...d.data(), fireId: d.id })))
    );
    return () => unsub();
  }, []);

  // ── Firebase: cargar configuración de empresa ──
  useEffect(() => {
    getDoc(doc(db, "config", "empresa")).then(snap => {
      if (snap.exists()) setEmpresa(snap.data());
      setConfigCargada(true);
    }).catch(() => setConfigCargada(true));
  }, []);

  const handleLogout = () => signOut(auth);

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  };

  const filtered = useMemo(() => pedidos.filter(p => {
    if (p.estado === "Listo") return false;     // van a Pedidos Listos
    if (p.estado === "Entregado") return false; // van al Historial
    const q = busqueda.toLowerCase();
    return (!busqueda || p.nombre.toLowerCase().includes(q) || p.cliente.toLowerCase().includes(q) || p.telefono?.includes(busqueda))
      && (filtroEstado    === "Todos"  || p.estado    === filtroEstado)
      && (filtroCategoria === "Todas"  || p.categoria === filtroCategoria);
  }), [pedidos, busqueda, filtroEstado, filtroCategoria]);

  const grouped = useMemo(() => {
    const g = {};
    // Categorías configuradas primero, y al final las que ya no existen pero tienen pedidos
    const extra = [...new Set(filtered.map(p => p.categoria || "Sin categoría"))].filter(c => !CATEGORIAS.includes(c));
    [...CATEGORIAS, ...extra].forEach(cat => {
      const items = filtered.filter(p => (p.categoria || "Sin categoría") === cat)
        .sort((a, b) => (!a.fechaEntrega ? 1 : !b.fechaEntrega ? -1 : a.fechaEntrega.localeCompare(b.fechaEntrega)));
      if (items.length) g[cat] = items;
    });
    return g;
  }, [filtered, catsVersion]);

  const stats = useMemo(() => ({
    total:     pedidos.filter(p => p.estado !== "Entregado" && p.estado !== "Listo").length,
    pendiente: pedidos.filter(p => p.estado === "Pendiente").length,
    produccion:pedidos.filter(p => p.estado === "En Producción").length,
    listo:     pedidos.filter(p => p.estado === "Listo").length,
    porCobrar: pedidos.filter(p => p.estado !== "Entregado")
                 .reduce((s, p) => s + parseFloat(p.precio||0) - parseFloat(p.seña||0), 0),
  }), [pedidos]);

  const validate = () => {
    const e = {};
    if (!formData.nombre.trim())  e.nombre       = "El nombre es obligatorio";
    // cliente opcional para pedidos del calendario
    if (!formData.fechaEntrega)   e.fechaEntrega = "La fecha de entrega es obligatoria";
    setErrors(e);
    return !Object.keys(e).length;
  };

  const triggerPrintIfNeeded = (prev, next) => {
    if (prev?.estado !== "En Producción" && next.estado === "En Producción")
      setTimeout(() => setPrintModal({ pedido: next }), 350);
  };

  const triggerMsgIfNeeded = (prev, next) => {
    if (prev?.estado !== "Listo" && next.estado === "Listo")
      setTimeout(() => setMsgModal({ pedido: next }), 350);
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    const limpiar = (obj) => Object.fromEntries(
      Object.entries(obj).filter(([k, v]) => v !== undefined && k !== "notasItems" && k !== "fireId")
    );
    const notasStr = (formData.notasItems||[""]).filter(x=>x.trim()).join("\n");
    if (editingId !== null) {
      const prev    = pedidos.find(p => p.fireId === editingId || p.id === editingId);
      const updated = limpiar({ ...formData, notas: notasStr || formData.notas, notasItems: undefined, id: prev?.id, clienteId: selectedClienteId||prev?.clienteId||null });
      await updateDoc(doc(db, "pedidos", editingId), updated);
      showToast("Pedido actualizado correctamente");
      triggerPrintIfNeeded(prev, updated);
      triggerMsgIfNeeded(prev, updated);
    } else {
      const ids = pedidos.map(p => typeof p.id === "number" ? p.id : 0);
      const newId = ids.length ? Math.max(...ids, 0) + 1 : 1;
      const nroOT = await getNextNroOT();
      const nuevo = limpiar({ ...formData, notas: notasStr || formData.notas, notasItems: undefined, id: newId, ...(nroOT ? {nroOT} : {}), clienteId: selectedClienteId||null });
      await addDoc(collection(db, "pedidos"), nuevo);
      showToast("Pedido cargado exitosamente 🎉");
      triggerPrintIfNeeded(null, nuevo);
      triggerMsgIfNeeded(null, nuevo);
    }
    setFormData(EMPTY_FORM); setEditingId(null); setErrors({}); setSelectedClienteId(null); setClienteSearch(""); setView("lista");
  };

  const handleEstadoChange = async (id, nuevoEstado) => {
    const prev = pedidos.find(p => p.fireId === id) || pedidos.find(p => p.id === id);
    if (!prev?.fireId) return;
    if (nuevoEstado === "Entregado" && prev.estado !== "Entregado") {
      setEntregaModal({ pedido: prev });
      return;
    }
    const updated = { ...prev, estado: nuevoEstado };
    let estadoCalendario = prev.estadoCalendario || 0;
    if (nuevoEstado === "En Producción") estadoCalendario = 1;
    if (nuevoEstado === "Listo")         estadoCalendario = 2;
    if (nuevoEstado === "Pendiente")     estadoCalendario = 0;
    await updateDoc(doc(db, "pedidos", prev.fireId), { estado: nuevoEstado, estadoCalendario });
    triggerPrintIfNeeded(prev, updated);
    triggerMsgIfNeeded(prev, updated);
  };

  // Barra de vistas de Pedidos: Por categoría · Kanban · Calendario · Listos
  const renderSelectorVistas = () => {
    const nListos = pedidos.filter(p => p.estado==="Listo").length;
    const activo  = view==="listos" ? "listos" : vistaLista;
    const btn = (id, label, onClick, extra) => (
      <button key={id} onClick={onClick}
        style={{ padding:"8px 18px", borderRadius:20, fontSize:13, fontWeight:600, cursor:"pointer", fontFamily:"'DM Sans',sans-serif", border:"none", transition:"all .18s",
          display:"flex", alignItems:"center", gap:7,
          background: activo===id ? "#e65100" : "#fff",
          color:      activo===id ? "#fff"    : "#4a5568",
          boxShadow:  activo===id ? "0 3px 12px rgba(230,81,0,.25)" : "0 2px 8px rgba(230,81,0,.07)" }}>
        {label}{extra}
      </button>
    );
    return (
      <div style={{ display:"flex", gap:8, marginBottom:20, alignItems:"center", flexWrap:"wrap" }}>
        {btn("categorias", "📋 Por Categoría", () => { setVistaLista("categorias"); setView("lista"); })}
        {btn("kanban",     "🗂 Kanban",        () => { setVistaLista("kanban");     setView("lista"); })}
        {btn("calendario", "📅 Calendario",    () => setView("pedidosOnline"))}
        {btn("listos",     "✅ Listos",        () => setView("listos"),
          nListos > 0 && <span style={{ background: activo==="listos"?"rgba(255,255,255,.3)":"#fff3e0", color: activo==="listos"?"#fff":"#e65100", borderRadius:20, padding:"0 8px", fontSize:12, fontWeight:700 }}>{nListos}</span>)}
      </div>
    );
  };

  const [entregaMultiple, setEntregaMultiple] = useState(null); // array de pedidos

  const confirmarEntrega = async (pedido, metodoPago) => {
    await registrarEntrega(pedido, metodoPago);
    setEntregaModal(null);
    showToast(`Pedido entregado · $${parseFloat(pedido.precio||0).toLocaleString("es-AR")} registrado en Finanzas ✅`);
  };

  const confirmarEntregaMultiple = async (lista, metodoPago) => {
    for (const p of lista) await registrarEntrega(p, metodoPago);
    const total = lista.reduce((s,p) => s + parseFloat(p.precio||0), 0);
    setEntregaMultiple(null);
    showToast(`${lista.length} pedido${lista.length!==1?"s":""} entregado${lista.length!==1?"s":""} · $${total.toLocaleString("es-AR")} registrado en Finanzas ✅`);
  };

  const registrarEntrega = async (pedido, metodoPago) => {
    // 1. Marcar pedido como entregado
    await updateDoc(doc(db, "pedidos", pedido.fireId), { estado: "Entregado" });
    // 2. Registrar en ventas de finanzas
    const ventasSnap = await getDocs(collection(db, "ventas"));
    const numero = ventasSnap.size + 1;
    await addDoc(collection(db, "ventas"), {
      numero,
      fecha:         new Date().toISOString().split("T")[0],
      clienteId:     pedido.clienteId || null,
      clienteNombre: pedido.cliente || "Sin cliente",
      metodoPago,
      origen:        "pedido",
      pedidoId:      pedido.fireId,
      items:         [{ nombre: pedido.nombre, cantidad: 1, precio: parseFloat(pedido.precio||0) }],
      total:         parseFloat(pedido.precio||0),
      creadoEn:      new Date().toISOString(),
    });
    // 3. Si es cuenta corriente, sumar al saldo del cliente
    if (metodoPago === "Cuenta Corriente" && pedido.clienteId) {
      const clSnap = await getDoc(doc(db, "clientes", pedido.clienteId));
      if (clSnap.exists()) {
        const nuevoSaldo = (parseFloat(clSnap.data().saldoCuenta)||0) + parseFloat(pedido.precio||0);
        await updateDoc(doc(db, "clientes", pedido.clienteId), { saldoCuenta: nuevoSaldo });
      }
    }
  };

  const handleEdit = (p) => {
    const notasItems = p.notas ? p.notas.split("\n").filter(x=>x.trim()) : [""];
    setFormData({...EMPTY_FORM, ...p, notasItems: notasItems.length ? notasItems : [""]});
    setEditingId(p.fireId);
    setErrors({});
    setView("formulario");
  };
  const handleDelete = async (id) => {
    if (!window.confirm("¿Eliminar este pedido?")) return;
    // id puede ser fireId (string) o id numérico
    const p = pedidos.find(x => x.fireId === id) || pedidos.find(x => x.id === id);
    if (!p?.fireId) { showToast("No se encontró el pedido","error"); return; }
    try {
      await deleteDoc(doc(db, "pedidos", p.fireId));
      if (selectedPedido?.fireId === p.fireId) { setSelectedPedido(null); setView("lista"); }
      showToast("Pedido eliminado", "error");
    } catch(e) {
      showToast("Error al eliminar","error");
      console.error(e);
    }
  };

  const toggleCat     = (cat) => setExpandedCats(p => ({ ...p, [cat]: !p[cat] }));
  const isCatExpanded = (cat) => expandedCats[cat] !== false;
  const saldo         = (p)   => parseFloat(p.precio||0) - parseFloat(p.seña||0);
  const hoy           = new Date().toISOString().split("T")[0];
  const isVencido     = (p)   => p.fechaEntrega && p.fechaEntrega < hoy && p.estado !== "Entregado";
  const isHoy         = (p)   => p.fechaEntrega === hoy && p.estado !== "Entregado";

  const inp = (field) => ({
    width:"100%", padding:"10px 14px", borderRadius:8,
    border:`1.5px solid ${errors[field]?"#ef5350":"#f0d5c0"}`,
    fontSize:14, fontFamily:"'DM Sans',sans-serif", background:"#fff",
    color:"#1a2340", outline:"none", boxSizing:"border-box", transition:"border-color 0.2s"
  });

  if (!authChecked) return (
    <div style={{ minHeight:"100vh", background:"#fff8f5", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", fontFamily:"'DM Sans',sans-serif" }}>
      <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:28, fontWeight:700, color:"#e65100", marginBottom:12 }}>Mafalda Gráfica</div>
      <div style={{ fontSize:14, color:"#a09080" }}>Iniciando...</div>
    </div>
  );

  if (!user) return <LoginScreen />;

  if (loading) return (
    <div style={{ minHeight:"100vh", background:"#fff8f5", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", fontFamily:"'DM Sans',sans-serif" }}>
      <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:28, fontWeight:700, color:"#e65100", marginBottom:12 }}>Mafalda Gráfica</div>
      <div style={{ fontSize:14, color:"#a09080" }}>Cargando pedidos...</div>
    </div>
  );

  return (
    <div style={{ fontFamily:"'DM Sans',sans-serif", color:"#1a2340", minHeight:"100vh", width:"100%" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}#root{width:100%;min-height:100vh;display:flex;flex-direction:column}
        html,body,#root{margin:0;padding:0;width:100%;min-height:100vh;overflow-x:hidden}body{background:#fff8f5}
        input:focus,select:focus,textarea:focus{border-color:#e65100!important;box-shadow:0 0 0 3px rgba(230,81,0,.1)}
        ::-webkit-scrollbar{width:5px}::-webkit-scrollbar-thumb{background:#c5cce0;border-radius:3px}
        .btn-p{background:#e65100;color:#fff;border:none;padding:10px 22px;border-radius:8px;font-size:14px;font-weight:600;font-family:'DM Sans',sans-serif;cursor:pointer;transition:all .18s}
        .btn-p:hover{background:#bf360c;transform:translateY(-1px);box-shadow:0 4px 14px rgba(230,81,0,.25)}
        .btn-g{background:transparent;color:#e65100;border:1.5px solid #e65100;padding:9px 20px;border-radius:8px;font-size:14px;font-weight:600;font-family:'DM Sans',sans-serif;cursor:pointer;transition:all .18s}
        .btn-g:hover{background:#fff3e0}
        .btn-d{background:#ef5350;color:#fff;border:none;padding:7px 12px;border-radius:7px;font-size:13px;font-weight:600;font-family:'DM Sans',sans-serif;cursor:pointer}
        .btn-d:hover{background:#c62828}
        .btn-imp{background:#e65100;color:#fff;border:none;padding:7px 13px;border-radius:7px;font-size:13px;font-weight:600;font-family:'DM Sans',sans-serif;cursor:pointer;display:inline-flex;align-items:center;gap:4px;transition:all .18s}
        .btn-imp:hover{background:#bf360c;box-shadow:0 3px 10px rgba(230,81,0,.3)}
        .card{background:#fff;border-radius:14px;box-shadow:0 2px 14px rgba(230,81,0,.07)}
        .nav-lnk{padding:8px 18px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:500;transition:all .18s;color:rgba(255,255,255,.75)}
        .nav-lnk:hover{background:rgba(255,255,255,.15);color:#fff}
        .nav-lnk.act{background:rgba(255,255,255,.2);color:#fff;font-weight:700}
        .row-h:hover{background:#f5f7fd!important;cursor:pointer}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
        .cat-tog:hover{background:#fff8f5}
        .est-sel{padding:4px 8px;border-radius:6px;font-size:12px;font-weight:600;font-family:'DM Sans',sans-serif;border:1.5px solid #f0d5c0;cursor:pointer;background:#fff}
        .modal-ov{position:fixed;inset:0;background:rgba(17,31,107,.45);z-index:600;display:flex;align-items:center;justify-content:center;animation:fIn .2s ease}
        .modal-bx{background:#fff;border-radius:16px;padding:36px 32px;max-width:430px;width:90%;box-shadow:0 20px 60px rgba(17,31,107,.25);animation:pIn .25s ease;text-align:center}
        .msg-bx{background:#fff;border-radius:16px;padding:36px 32px;max-width:500px;width:92%;box-shadow:0 20px 60px rgba(17,31,107,.25);animation:pIn .25s ease}
        .msg-textarea{width:100%;border:2px solid #dde3ef;border-radius:10px;padding:14px 16px;font-size:15px;font-family:'DM Sans',sans-serif;color:#1a2340;line-height:1.6;resize:none;outline:none;transition:border-color .2s;background:#fffaf7}
        .msg-textarea:focus{border-color:#e65100;background:#fff}
        .btn-copy{background:#25d366;color:#fff;border:none;padding:11px 24px;border-radius:9px;font-size:15px;font-weight:700;font-family:'DM Sans',sans-serif;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:all .18s}
        .btn-copy:hover{background:#1da851;box-shadow:0 3px 12px rgba(37,211,102,.35)}
        .btn-copy.copied{background:#2e7d32}
        @keyframes fIn{from{opacity:0}to{opacity:1}}
        @keyframes pIn{from{transform:scale(.9);opacity:0}to{transform:scale(1);opacity:1}}
        /* ── Responsive ── */
        /* ── Sidebar layout ── */
        .app-shell{display:flex;min-height:100vh;width:100%;position:relative}
        .sidebar{width:220px;min-height:100vh;background:linear-gradient(180deg,#bf360c 0%,#e65100 100%);display:flex;flex-direction:column;transition:width .25s cubic-bezier(.4,0,.2,1);flex-shrink:0;position:relative;z-index:100;box-shadow:4px 0 20px rgba(191,54,12,.25)}
        .sidebar.collapsed{width:64px}
        .sidebar-logo{display:flex;align-items:center;gap:10px;padding:18px 14px 14px;border-bottom:1px solid rgba(255,255,255,.15);min-height:70px;overflow:hidden}
        .sidebar-logo img{height:38px;object-fit:contain;border-radius:6px;flex-shrink:0}
        .sidebar-logo-txt{overflow:hidden;white-space:nowrap}
        .sidebar-logo-name{font-family:"DM Sans",sans-serif;font-size:16px;font-weight:800;color:#fff;line-height:1.2}
        .sidebar-logo-sub{font-size:9px;color:rgba(255,255,255,.55);letter-spacing:1px;text-transform:uppercase}
        .sidebar-toggle{display:flex;align-items:center;justify-content:center;width:32px;height:32px;background:rgba(255,255,255,.15);border:none;border-radius:8px;color:#fff;cursor:pointer;font-size:14px;flex-shrink:0;transition:background .18s;margin-left:auto}
        .sidebar-toggle:hover{background:rgba(255,255,255,.25)}
        .sidebar-nav{flex:1;padding:10px 8px;display:flex;flex-direction:column;gap:3px;overflow-y:auto;overflow-x:hidden}
        .sidebar-item{display:flex;align-items:center;gap:12px;padding:10px 10px;border-radius:10px;cursor:pointer;transition:all .18s;color:rgba(255,255,255,.75);white-space:nowrap;overflow:hidden;font-size:14px;font-weight:500;font-family:"DM Sans",sans-serif;border:none;background:transparent;width:100%;text-align:left}
        .sidebar-item:hover{background:rgba(255,255,255,.15);color:#fff}
        .sidebar-item.act{background:rgba(255,255,255,.22);color:#fff;font-weight:700}
        .sidebar-item.finanzas-item{background:rgba(255,255,255,.12);margin-top:auto}
        .sidebar-item.finanzas-item.act{background:rgba(255,255,255,.25)}
        .sidebar-icon{font-size:18px;flex-shrink:0;width:22px;text-align:center}
        .sidebar-label{overflow:hidden;transition:opacity .2s,max-width .25s;max-width:160px;opacity:1}
        .collapsed .sidebar-label{max-width:0;opacity:0}
        .sidebar-bottom{padding:10px 8px;border-top:1px solid rgba(255,255,255,.15)}
        .sidebar-badge{background:#f57f17;color:#fff;border-radius:50%;width:18px;height:18px;font-size:10px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;margin-left:auto;flex-shrink:0}
        .main-area{flex:1;display:flex;flex-direction:column;min-width:0;background:#fff8f5;overflow-x:hidden}
        .topbar{height:58px;background:#fff;border-bottom:1px solid #f0d5c0;display:flex;align-items:center;padding:0 24px;gap:12px;box-shadow:0 1px 8px rgba(230,81,0,.06);flex-shrink:0}
        .topbar-title{font-family:"DM Sans",sans-serif;font-size:18px;font-weight:700;color:#1a2340;flex:1}
        .main-content{padding:24px 28px;flex:1}
        .grid-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
        .grid-2col{display:grid;grid-template-columns:1fr 1fr;gap:18px}
        .grid-nueva-venta{display:grid;grid-template-columns:1fr 420px;gap:20px;align-items:start}
        .grid-agenda{display:grid;grid-template-columns:1fr 300px;gap:20px;align-items:start}
        .busq-global-overlay{position:fixed;inset:0;z-index:400;background:rgba(0,0,0,.4)}
        .busq-global-box{position:fixed;top:70px;left:50%;transform:translateX(-50%);width:min(600px,92vw);background:#fff;border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.2);z-index:401;overflow:hidden}
        .busq-global-input{width:100%;padding:16px 20px;font-size:16px;border:none;outline:none;font-family:"DM Sans",sans-serif;color:#1a2340}
        .busq-global-result{padding:11px 20px;cursor:pointer;border-top:1px solid #fef0e8;display:flex;align-items:center;gap:12px;transition:background .15s}
        .busq-global-result:hover{background:#fff8f5}
        .sidebar-overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:199}
        .mobile-menu-btn{display:none;background:transparent;border:1.5px solid #f0d5c0;color:#e65100;font-size:20px;cursor:pointer;padding:5px 10px;border-radius:8px;font-weight:700;line-height:1}
        .ctx-btn{background:rgba(230,81,0,.1);color:#e65100;border:1.5px solid rgba(230,81,0,.3);padding:7px 14px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;font-family:"DM Sans",sans-serif;transition:all .18s}
        .ctx-btn:hover{background:#e65100;color:#fff}
        @media(max-width:900px){
          .sidebar{position:fixed;top:0;left:0;height:100vh;z-index:200;transform:translateX(0);transition:width .25s cubic-bezier(.4,0,.2,1)}
          .sidebar.collapsed{width:0;overflow:hidden}
          .mobile-menu-btn{display:flex;align-items:center;justify-content:center}
          .sidebar-overlay{display:block}
          .sidebar-toggle{display:none}
          .main-area{margin-left:0}
          .main-content{padding:16px}
          .grid-stats{grid-template-columns:repeat(2,1fr)}
          .grid-2col{grid-template-columns:1fr}
          .grid-nueva-venta{grid-template-columns:1fr}
          .grid-agenda{grid-template-columns:1fr}
        }
        @media(max-width:480px){
          .grid-stats{grid-template-columns:1fr 1fr}
          .main-content{padding:12px}
        }
      `}</style>

      {/* ── SIDEBAR + MAIN LAYOUT ── */}
      <div className="app-shell">

        {/* ── SIDEBAR ── */}
        <aside className={`sidebar${menuAbierto?"":" collapsed"}`}>
          {/* Overlay para cerrar en mobile tocando afuera */}
          {menuAbierto && (
            <div onClick={()=>setMenuAbierto(false)}
              style={{ display:"none" }}
              className="sidebar-overlay"/>
          )}
          {/* Logo */}
          <div className="sidebar-logo">
            {empresa.logo
              ? <img src={empresa.logo} alt="Logo" style={{ height:38, maxWidth:120, objectFit:"contain", borderRadius:6, flexShrink:0 }}/>
              : <span className="sidebar-icon" style={{ fontSize:26 }}>🖨️</span>
            }
            <div className="sidebar-logo-txt">
              <div className="sidebar-logo-name">{empresa.nombre||"Mafalda"}</div>
              <div className="sidebar-logo-sub">Gestión</div>
            </div>
            <button className="sidebar-toggle" onClick={()=>setMenuAbierto(m=>!m)} title={menuAbierto?"Colapsar menú":"Expandir menú"}>
              {menuAbierto?"◀":"▶"}
            </button>
          </div>

          {/* Nav items */}
          <nav className="sidebar-nav">
            <button className={`sidebar-item ${(view==="lista"||view==="listos"||view==="formulario"||view==="detalle")?"act":""}` + ""} onClick={()=>{ setView("lista"); }}>
              <span className="sidebar-icon">📋</span>
              <span className="sidebar-label">Pedidos</span>
            </button>
            <button className={`sidebar-item ${view==="pedidosOnline"?"act":""}`}
              onClick={()=>{ setView("pedidosOnline"); }}
              onDoubleClick={e=>{ e.stopPropagation(); setPlanillaFlotante(true); }}
              title="Clic: abrir · Doble clic: ventana flotante">
              <span className="sidebar-icon">📅</span>
              <span className="sidebar-label">Calendario</span>
            </button>
            <button className={`sidebar-item ${(view==="ventas"||view==="nuevaVenta")?"act":""}` + ""} onClick={()=>{ setView("ventas"); }}>
              <span className="sidebar-icon">💰</span>
              <span className="sidebar-label">Ventas</span>
            </button>
            <button className={`sidebar-item ${view==="presupuestos"?"act":""}`} onClick={()=>{ setView("presupuestos"); }}>
              <span className="sidebar-icon">📋</span>
              <span className="sidebar-label">Presupuestos</span>
            </button>
            {(APP_CFG.accesos||[]).filter(a => a && a.url).map((a, i) => (
              <button key={"acc"+i} className="sidebar-item" onClick={()=>window.open(a.url,"_blank")} title={a.url}>
                <span className="sidebar-icon">{a.icono||"🔗"}</span>
                <span className="sidebar-label">{a.nombre||a.url}</span>
              </button>
            ))}
            <button className={`sidebar-item ${(view==="insumos"||view==="nuevoInsumo"||view==="editarInsumo")?"act":""}` + ""} onClick={()=>{ setView("insumos"); }}>
              <span className="sidebar-icon">🏷️</span>
              <span className="sidebar-label">Servicios y Productos</span>
            </button>
            <button className={`sidebar-item ${(view==="clientes"||view==="nuevoCliente"||view==="editarCliente")?"act":""}` + ""} onClick={()=>{ setView("clientes"); }}>
              <span className="sidebar-icon">👥</span>
              <span className="sidebar-label">Clientes</span>
            </button>
            <button className={`sidebar-item ${(view==="proveedores"||view==="nuevoProveedor"||view==="editarProveedor")?"act":""}` + ""} onClick={()=>{ setView("proveedores"); }}>
              <span className="sidebar-icon">🏭</span>
              <span className="sidebar-label">Proveedores</span>
            </button>
            <button className={`sidebar-item ${(view==="agenda")?"act":""}` + ""} onClick={()=>{ setView("agenda"); }}>
              <span className="sidebar-icon">📅</span>
              <span className="sidebar-label">Agenda</span>
            </button>
            <button className={`sidebar-item ${view==="produccion"?"act":""}`} onClick={()=>{ setView("produccion"); }}>
              <span className="sidebar-icon">📊</span>
              <span className="sidebar-label">Producción</span>
            </button>
            <button className={`sidebar-item ${(view==="config")?"act":""}` + ""} onClick={()=>{ setView("config"); }}>
              <span className="sidebar-icon">⚙️</span>
              <span className="sidebar-label">Configuración</span>
            </button>

          </nav>

          {/* Finanzas al fondo */}
          <div className="sidebar-bottom">
            <button className={`sidebar-item finanzas-item ${view==="finanzas"?"act":""}`} onClick={()=>setView("finanzas")}>
              <span className="sidebar-icon">💼</span>
              <span className="sidebar-label">Finanzas</span>
            </button>
            <button className="sidebar-item" onClick={handleLogout} style={{ marginTop:4 }}>
              <span className="sidebar-icon">🔒</span>
              <span className="sidebar-label">Salir</span>
            </button>
          </div>
        </aside>

        {/* ── MAIN AREA ── */}
        <div className="main-area">

          {/* Topbar */}
          <div className="topbar">
            {/* Toggle en mobile */}
            <button onClick={()=>setMenuAbierto(m=>!m)}
              className="mobile-menu-btn">
              {menuAbierto ? "✕" : "☰"}
            </button>
            <div className="topbar-title">
              {view==="lista" ? "📋 Pedidos" :
          view==="listos" ? "📋 Pedidos" :
          view==="formulario" ? "📋 Pedidos" :
          view==="detalle" ? "📋 Pedidos" :
          view==="clientes" ? "👥 Clientes" :
          view==="nuevoCliente" ? "👥 Clientes" :
          view==="editarCliente" ? "👥 Clientes" :
          view==="insumos" ? "🏷️ Servicios y Productos" :
          view==="nuevoInsumo" ? "🏷️ Servicios y Productos" :
          view==="editarInsumo" ? "🏷️ Servicios y Productos" :
          view==="ventas" ? "💰 Ventas" :
          view==="nuevaVenta" ? "💰 Ventas" :
          view==="presupuestos" ? "📋 Presupuestos" :
          view==="agenda" ? "📅 Agenda" :
          view==="proveedores" ? "🏭 Proveedores" :
          view==="nuevoProveedor" ? "🏭 Proveedores" :
          view==="editarProveedor" ? "🏭 Proveedores" :
          view==="calculadora" ? "🧮 Calculadora de Costos" :
          view==="produccion"  ? "📊 Control de Producción" :
          view==="pedidosOnline" ? "📅 Calendario" :
          view==="config" ? "⚙️ Configuración" :
          view==="finanzas" ? "💼 Finanzas" :
          "Sistema"}
            </div>

            {/* Botones contextuales en topbar */}
            {(view==="lista"||view==="formulario"||view==="detalle") && (
              <button className="ctx-btn" onClick={()=>{ setFormData({ ...EMPTY_FORM, categoria: CATEGORIAS[0]||"", fechaPedido: new Date().toLocaleDateString("sv-SE") }); setEditingId(null); setErrors({}); setSelectedClienteId(null); setClienteSearch(""); setView("formulario"); }}>
                + Nuevo Pedido
              </button>
            )}
            {(view==="clientes"||view==="nuevoCliente") && (
              <button className="ctx-btn" onClick={()=>setView("nuevoCliente")}>➕ Nuevo Cliente</button>
            )}
            {(view==="insumos"||view==="nuevoInsumo") && (
              <button className="ctx-btn" onClick={()=>setView("nuevoInsumo")}>➕ Nuevo Producto</button>
            )}
            {(view==="ventas"||view==="nuevaVenta") && (
              <button className="ctx-btn" onClick={()=>setView("nuevaVenta")}>➕ Nueva Venta</button>
            )}
            {view==="agenda" && (
              <button className="ctx-btn" onClick={()=>setNuevoEventoModal(true)}>➕ Nuevo Evento</button>
            )}
            {(view==="proveedores"||view==="nuevoProveedor") && (
              <button className="ctx-btn" onClick={()=>setView("nuevoProveedor")}>➕ Nuevo Proveedor</button>
            )}

            {/* Buscador global */}
            <button onClick={()=>setBusqGlobalOpen(true)}
              style={{ background:"rgba(230,81,0,.08)", border:"1.5px solid rgba(230,81,0,.2)", color:"#e65100", padding:"7px 14px", borderRadius:8, cursor:"pointer", fontSize:14, display:"flex", alignItems:"center", gap:6, fontFamily:"'DM Sans',sans-serif", fontWeight:600 }}>
              🔍 <span style={{ fontSize:13 }}>Buscar</span>
            </button>

            {!configCargada && (
              <span style={{ fontSize:11, color:"#a09080", display:"flex", alignItems:"center", gap:4 }}>
                <span style={{ width:7, height:7, borderRadius:"50%", background:"#ffb74d", display:"inline-block", animation:"pulse 1s infinite" }}></span>
              </span>
            )}
          </div>

          {/* Buscador Global */}
          {busqGlobalOpen && (
            <BuscadorGlobal
              pedidos={pedidos}
              clientes={clientes}
              busqueda={busquedaGlobal}
              setBusqueda={setBusquedaGlobal}
              onClose={() => { setBusqGlobalOpen(false); setBusquedaGlobal(""); }}
              onSelectPedido={(p) => { setSelectedPedido(p); setView("detalle"); setBusqGlobalOpen(false); setBusquedaGlobal(""); }}
              onSelectCliente={() => { setView("clientes"); setBusqGlobalOpen(false); setBusquedaGlobal(""); }}
              ESTADO_COLOR={ESTADO_COLOR}
              CATEGORIA_COLOR={CATEGORIA_COLOR}
              CATEGORIA_ICON={CATEGORIA_ICON}
            />
          )}

          {/* ── PLANILLA FLOTANTE ── */}
          {planillaFlotante && (
            <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,.45)", zIndex:400, display:"flex", alignItems:"center", justifyContent:"center", padding:16 }}
              onClick={()=>setPlanillaFlotante(false)}>
              <div style={{ background:"#f8f9fa", borderRadius:16, width:"100%", maxWidth:1200, maxHeight:"92vh",
                boxShadow:"0 24px 80px rgba(0,0,0,.3)", display:"flex", flexDirection:"column", overflow:"hidden" }}
                onClick={e=>e.stopPropagation()}>
                {/* Header flotante */}
                <div style={{ background:"#1a2340", padding:"14px 20px", display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0 }}>
                  <div style={{ fontWeight:700, fontSize:16, color:"#fff" }}>📅 Calendario</div>
                  <div style={{ display:"flex", gap:10, alignItems:"center" }}>
                    <button onClick={()=>{ setPlanillaFlotante(false); setView("pedidosOnline"); }}
                      style={{ background:"rgba(255,255,255,.15)", border:"none", color:"#fff", padding:"6px 14px", borderRadius:8, fontSize:12, fontWeight:600, cursor:"pointer" }}>
                      Abrir en pantalla completa ↗
                    </button>
                    <button onClick={()=>setPlanillaFlotante(false)}
                      style={{ background:"rgba(255,255,255,.2)", border:"none", color:"#fff", width:32, height:32, borderRadius:8, fontSize:18, cursor:"pointer", fontWeight:700, display:"flex", alignItems:"center", justifyContent:"center" }}>
                      ✕
                    </button>
                  </div>
                </div>
                {/* Contenido */}
                <div style={{ overflowY:"auto", padding:"20px 20px", flex:1 }}>
                  <PedidosOnlineView
                    showToast={showToast}
                    setView={setView}
                    setSelectedPedido={setSelectedPedido}
                    clientes={clientes}
                  />
                </div>
              </div>
            </div>
          )}

          <div className="main-content" onClick={()=>{ if(window.innerWidth<=900) setMenuAbierto(false); }}>


        {/* ── LISTA ── */}
        {view==="lista" && (
          <div>
            {renderSelectorVistas()}

            {/* Filtros — solo en vista categorías */}
            {vistaLista === "categorias" && (
              <div className="card" style={{ padding:"16px 20px", marginBottom:20, display:"flex", gap:12, flexWrap:"wrap", alignItems:"center" }}>
                <div style={{ position:"relative", flex:"1 1 220px" }}>
                  <span style={{ position:"absolute", left:11, top:"50%", transform:"translateY(-50%)", fontSize:15 }}>🔍</span>
                  <input placeholder="Buscar por pedido, cliente o teléfono..." value={busqueda}
                    onChange={e => setBusqueda(e.target.value)} style={{ ...inp(), paddingLeft:34, width:"100%" }}/>
                </div>
                <select value={filtroCategoria} onChange={e => setFiltroCategoria(e.target.value)} style={{ ...inp(), width:180, cursor:"pointer" }}>
                  <option value="Todas">Todas las categorías</option>
                  {CATEGORIAS.map(c => <option key={c}>{c}</option>)}
                </select>
                <select value={filtroEstado} onChange={e => setFiltroEstado(e.target.value)} style={{ ...inp(), width:160, cursor:"pointer" }}>
                  {ESTADOS.filter(e => e !== "Listo").map(e => <option key={e}>{e}</option>)}
                </select>
                {(busqueda||filtroEstado!=="Todos"||filtroCategoria!=="Todas") && (
                  <button className="btn-g" style={{ padding:"9px 14px", fontSize:13 }}
                    onClick={() => { setBusqueda(""); setFiltroEstado("Todos"); setFiltroCategoria("Todas"); }}>✕ Limpiar</button>
                )}
                <div style={{ marginLeft:"auto", fontSize:13, color:"#a09080" }}>{filtered.length} pedido{filtered.length!==1?"s":""}</div>
              </div>
            )}

            {/* Vista: Categorías */}
            {vistaLista === "categorias" && (
              !Object.keys(grouped).length ? (
                <div className="card" style={{ padding:"52px 24px", textAlign:"center" }}>
                  <div style={{ fontSize:40, marginBottom:14 }}>📭</div>
                  <div style={{ fontWeight:700, fontSize:18, fontFamily:"'DM Sans',sans-serif", marginBottom:6 }}>Sin pedidos</div>
                  <div style={{ color:"#a09080", fontSize:14 }}>Cargá un nuevo pedido con el botón de arriba</div>
                </div>
              ) : Object.entries(grouped).map(([cat, items]) => {
                const cc  = CATEGORIA_COLOR[cat];
                const exp = isCatExpanded(cat);
                return (
                  <div key={cat} className="card" style={{ marginBottom:16, overflow:"hidden" }}>
                    <div className="cat-tog" onClick={() => toggleCat(cat)}
                      style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"14px 20px", borderBottom:exp?`2px solid ${cc.accent}22`:"none", cursor:"pointer", borderLeft:`4px solid ${cc.accent}` }}>
                      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                        <span style={{ background:cc.bg, color:cc.text, padding:"5px 12px", borderRadius:20, fontSize:13, fontWeight:700, display:"inline-flex", alignItems:"center", gap:6 }}>
                          {CATEGORIA_ICON[cat]} {cat}
                        </span>
                        <span style={{ background:cc.accent, color:"#fff", borderRadius:"50%", width:22, height:22, display:"inline-flex", alignItems:"center", justifyContent:"center", fontSize:12, fontWeight:700 }}>{items.length}</span>
                      </div>
                      <div style={{ display:"flex", alignItems:"center", gap:14 }}>
                        <span style={{ fontSize:12, color:"#a09080" }}>📅 Próx. entrega: <strong style={{ color:"#1a2340" }}>{items[0]?.fechaEntrega||"—"}</strong></span>
                        <span style={{ fontSize:16, color:"#a09080", display:"inline-block", transform:exp?"rotate(0)":"rotate(-90deg)", transition:"transform .2s" }}>▾</span>
                      </div>
                    </div>
                    {exp && (
                      <div style={{ overflowX:"auto" }}>
                        <table style={{ width:"100%", borderCollapse:"collapse", fontSize:13, fontFamily:"'DM Sans',sans-serif" }}>
                          <thead>
                            <tr style={{ background:"#fffaf7" }}>
                              {["Pedido","Cliente","Estado","Fecha Entrega","Total","Saldo",""].map(h => (
                                <th key={h} style={{ padding:"10px 16px", textAlign:"left", fontWeight:600, fontSize:11, color:"#8a7060", textTransform:"uppercase", letterSpacing:".6px", whiteSpace:"nowrap", borderBottom:"1px solid #edf0f7" }}>{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {items.map(p => {
                              const ec  = ESTADO_COLOR[p.estado];
                              const ven = isVencido(p);
                              const hf  = isHoy(p);
                              return (
                                <tr key={p.id} className="row-h"
                                  style={{ borderBottom:"1px solid #f2f4f9", background:ven?"#fff8f8":hf?"#fffdf0":"#fff" }}
                                  onClick={() => { setSelectedPedido(p); setView("detalle"); }}>
                                  <td style={{ padding:"12px 16px" }}>
                                    <div style={{ fontWeight:600, color:"#1a2340" }}>{p.nombre}</div>
                                    {p.notas && <div style={{ fontSize:11, color:"#a09080", marginTop:2, maxWidth:210, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{p.notas}</div>}
                                  </td>
                                  <td style={{ padding:"12px 16px", color:"#4a5568", whiteSpace:"nowrap" }}>
                                    <div>{p.cliente}</div>
                                    {p.telefono && <div style={{ fontSize:12, fontWeight:700, color:"#e65100", marginTop:2, display:"flex", alignItems:"center", gap:3 }}>📞 {p.telefono}</div>}
                                  </td>
                                  <td style={{ padding:"12px 16px" }} onClick={e => e.stopPropagation()}>
                                    <select className="est-sel" value={p.estado}
                                      onChange={e => handleEstadoChange(p.fireId || p.id, e.target.value)}
                                      style={{ background:ec.bg, color:ec.text, borderColor:ec.bg }}>
                                      {ESTADOS.filter(s => s!=="Todos").map(s => <option key={s}>{s}</option>)}
                                    </select>
                                  </td>
                                  <td style={{ padding:"12px 16px", whiteSpace:"nowrap" }}>
                                    <span style={{ fontWeight:600, color:ven?"#c62828":hf?"#f57f17":"#1a2340" }}>
                                      {ven&&"⚠️ "}{hf&&"📍 "}{fmtFecha(p.fechaEntrega)||"—"}
                                    </span>
                                    {ven && <div style={{ fontSize:11, color:"#c62828" }}>Vencido</div>}
                                    {hf  && <div style={{ fontSize:11, color:"#f57f17" }}>Hoy</div>}
                                  </td>
                                  <td style={{ padding:"12px 16px", fontWeight:600, color:"#1a2340", whiteSpace:"nowrap" }}>
                                    {p.precio?`$${parseFloat(p.precio).toLocaleString("es-AR")}`:"—"}
                                  </td>
                                  <td style={{ padding:"12px 16px", whiteSpace:"nowrap" }}>
                                    <span style={{ fontWeight:700, color:saldo(p)>0?"#c62828":"#2e7d32" }}>
                                      {p.precio?`$${saldo(p).toLocaleString("es-AR")}`:"—"}
                                    </span>
                                  </td>
                                  <td style={{ padding:"12px 14px" }} onClick={e => e.stopPropagation()}>
                                    <div style={{ display:"flex", gap:5 }}>
                                      <button className="btn-imp" title="Imprimir orden" onClick={() => imprimirOrden(p, empresa)}>🖨️</button>
                                      <button className="btn-g" style={{ padding:"5px 10px", fontSize:12 }} onClick={() => handleEdit(p)}>✏️</button>
                                      <button className="btn-d" onClick={() => handleDelete(p.fireId || p.id)}>🗑</button>
                                    </div>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                );
              })
            )}

            {/* Vista: Kanban */}
            {vistaLista === "kanban" && (
              <KanbanView
                pedidos={pedidos}
                handleEstadoChange={handleEstadoChange}
                handleEdit={handleEdit}
                handleDelete={handleDelete}
                setSelectedPedido={setSelectedPedido}
                setView={setView}
                CATEGORIA_COLOR={CATEGORIA_COLOR}
                CATEGORIA_ICON={CATEGORIA_ICON}
                ESTADO_COLOR={ESTADO_COLOR}
                isVencido={isVencido}
                isHoy={isHoy}
              />
            )}

            {/* Vista: Calendario */}
            {vistaLista === "calendario" && (
              <CalendarioView
                pedidos={pedidos}
                setSelectedPedido={setSelectedPedido}
                setView={setView}
                CATEGORIA_COLOR={CATEGORIA_COLOR}
                CATEGORIA_ICON={CATEGORIA_ICON}
                ESTADO_COLOR={ESTADO_COLOR}
                isVencido={isVencido}
              />
            )}
          </div>
        )}

        {/* ── FORMULARIO ── */}
        {view==="formulario" && (
          <div className="card" style={{ padding:"32px 36px" }}>
            <div style={{ marginBottom:26 }}>
              <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:26, fontWeight:700, color:"#1a2340", marginBottom:4 }}>
                {editingId?"✏️ Editar Pedido":"📥 Nuevo Pedido"}
              </h2>
              <p style={{ fontSize:14, color:"#a09080" }}>{editingId?"Modificá los datos del pedido.":"Completá el formulario para registrar el pedido."}</p>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18 }}>
              {/* Categoría */}
              <div style={{ gridColumn:"1 / -1" }}>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:8 }}>
                  Categoría *
                  {errors.categoria && <span style={{ color:"#ef5350", fontSize:12, fontWeight:400, marginLeft:8 }}>{errors.categoria}</span>}
                </label>
                <select value={formData.categoria||""} onChange={e=>setFormData(p=>({...p,categoria:e.target.value}))}
                  style={{ width:"100%", padding:"11px 14px", borderRadius:8, border:`1.5px solid ${errors.categoria?"#ef5350":formData.categoria?"#e65100":"#dde3ef"}`,
                    fontSize:14, fontFamily:"'DM Sans',sans-serif", outline:"none", cursor:"pointer",
                    background: formData.categoria ? (CATEGORIA_COLOR[formData.categoria]?.bg||"#fff8f5") : "#fff",
                    color: formData.categoria ? (CATEGORIA_COLOR[formData.categoria]?.text||"#1a2340") : "#a09080",
                    fontWeight: formData.categoria ? 700 : 400 }}>
                  <option value="">— Seleccioná una categoría —</option>
                  {formData.categoria && !CATEGORIAS.includes(formData.categoria) && (
                    <option value={formData.categoria}>{formData.categoria} (ya no existe)</option>
                  )}
                  {CATEGORIAS.map(cat=>(
                    <option key={cat} value={cat}>{CATEGORIA_ICON[cat]} {cat}</option>
                  ))}
                </select>
              </div>

              <div style={{ gridColumn:"1 / -1" }}>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Descripción del pedido *</label>
                <input value={formData.nombre} onChange={e=>setFormData(p=>({...p,nombre:e.target.value}))}
                  placeholder="Ej: Remeras con logo, Banner 2x1m..." style={inp("nombre")}/>
                {errors.nombre && <div style={{ color:"#ef5350", fontSize:12, marginTop:4 }}>{errors.nombre}</div>}
              </div>

              <div style={{ position:"relative", gridColumn:"1 / -1" }}>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Cliente *</label>
                {selectedClienteId ? (
                  (() => {
                    const cl = clientes.find(c => c.fireId === selectedClienteId);
                    return cl ? (
                      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 14px", borderRadius:8, border:"1.5px solid #e65100", background:"#fff8f5" }}>
                        <div>
                          <div style={{ fontWeight:700, color:"#1a2340", fontSize:14 }}>{cl.nombre} {cl.apellido} {cl.empresa && `— ${cl.empresa}`}</div>
                          <div style={{ fontSize:12, color:"#e65100", fontWeight:600, marginTop:2 }}>📞 {cl.telefono || "Sin teléfono"}</div>
                        </div>
                        <button onClick={() => { setSelectedClienteId(null); setFormData(p=>({...p,cliente:"",telefono:""})); setClienteSearch(""); }}
                          style={{ background:"#ffebee", border:"none", color:"#c62828", padding:"5px 10px", borderRadius:6, fontSize:12, cursor:"pointer", fontWeight:600 }}>
                          ✕ Cambiar
                        </button>
                      </div>
                    ) : null;
                  })()
                ) : (
                  <div style={{ position:"relative" }}>
                    <input
                      value={clienteSearch}
                      onChange={e => { setClienteSearch(e.target.value); setFormData(p=>({...p,cliente:e.target.value})); setClienteDropdown(true); }}
                      onFocus={() => setClienteDropdown(true)}
                      placeholder="Buscar cliente o escribir nuevo..."
                      style={{ ...inp("cliente"), paddingRight:40 }}
                      autoComplete="off"
                    />
                    <span style={{ position:"absolute", right:12, top:"50%", transform:"translateY(-50%)", fontSize:16 }}>🔍</span>
                    {clienteDropdown && (clienteSearch.length > 0) && (
                      <div style={{ position:"absolute", top:"100%", left:0, right:0, background:"#fff", border:"1.5px solid #f0d5c0", borderRadius:8, boxShadow:"0 8px 24px rgba(230,81,0,.12)", zIndex:100, maxHeight:220, overflowY:"auto", marginTop:4 }}>
                        {clientes.filter(c => {
                          const q = clienteSearch.toLowerCase();
                          return `${c.nombre} ${c.apellido} ${c.empresa||""} ${c.telefono||""}`.toLowerCase().includes(q);
                        }).map(cl => (
                          <div key={cl.fireId}
                            onClick={() => {
                              setSelectedClienteId(cl.fireId);
                              setFormData(p=>({...p, cliente:`${cl.nombre} ${cl.apellido}`.trim(), telefono: cl.telefono||""}));
                              setClienteDropdown(false);
                              setClienteSearch(`${cl.nombre} ${cl.apellido}`.trim());
                            }}
                            style={{ padding:"10px 14px", cursor:"pointer", borderBottom:"1px solid #fef0e8", display:"flex", alignItems:"center", justifyContent:"space-between" }}
                            onMouseOver={e=>e.currentTarget.style.background="#fff8f5"}
                            onMouseOut={e=>e.currentTarget.style.background="#fff"}>
                            <div>
                              <div style={{ fontWeight:600, fontSize:13, color:"#1a2340" }}>{cl.nombre} {cl.apellido} {cl.empresa&&<span style={{color:"#a09080",fontWeight:400}}>— {cl.empresa}</span>}</div>
                              {cl.telefono && <div style={{ fontSize:11, color:"#e65100", fontWeight:600 }}>📞 {cl.telefono}</div>}
                            </div>
                            <span style={{ fontSize:11, color:"#a09080" }}>Seleccionar →</span>
                          </div>
                        ))}
                        <div
                          onClick={() => { setView("nuevoCliente"); setFormData(p=>({...p,_volver:"formulario"})); }}
                          style={{ padding:"10px 14px", cursor:"pointer", background:"#fff8f5", color:"#e65100", fontWeight:700, fontSize:13, borderTop:"1.5px solid #f0d5c0", display:"flex", alignItems:"center", gap:6 }}>
                          ➕ Crear cliente "{clienteSearch}"
                        </div>
                      </div>
                    )}
                  </div>
                )}
                {errors.cliente && <div style={{ color:"#ef5350", fontSize:12, marginTop:4 }}>{errors.cliente}</div>}
              </div>

              <div>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Teléfono</label>
                <input value={formData.telefono} onChange={e=>setFormData(p=>({...p,telefono:e.target.value}))} placeholder="11-xxxx-xxxx" style={inp()}/>
              </div>

              <div>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Estado</label>
                <select value={formData.estado} onChange={e=>setFormData(p=>({...p,estado:e.target.value}))} style={{ ...inp(), cursor:"pointer" }}>
                  {ESTADOS.filter(e=>e!=="Todos").map(e=><option key={e}>{e}</option>)}
                </select>
                {formData.estado==="En Producción" && (
                  <div style={{ marginTop:6, fontSize:12, color:"#bf360c", background:"#fff3e0", borderRadius:6, padding:"5px 10px" }}>
                    🖨️ Se generará la orden de trabajo al guardar
                  </div>
                )}
              </div>

              <div>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Fecha del Pedido</label>
                <input type="date" value={formData.fechaPedido} onChange={e=>setFormData(p=>({...p,fechaPedido:e.target.value}))} style={inp()}/>
              </div>

              <div>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Fecha de Entrega *</label>
                <input type="date" value={formData.fechaEntrega} onChange={e=>setFormData(p=>({...p,fechaEntrega:e.target.value}))} style={inp("fechaEntrega")}/>
                {errors.fechaEntrega && <div style={{ color:"#ef5350", fontSize:12, marginTop:4 }}>{errors.fechaEntrega}</div>}
              </div>

              <div>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Precio Total ($)</label>
                <input type="number" value={formData.precio} onChange={e=>setFormData(p=>({...p,precio:e.target.value}))} placeholder="0.00" style={inp()}/>
              </div>

              <div>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Seña / Adelanto ($)</label>
                <input type="number" value={formData.seña} onChange={e=>setFormData(p=>({...p,seña:e.target.value}))} placeholder="0.00" style={inp()}/>
              </div>

              {(formData.precio||formData.seña) && (
                <div style={{ gridColumn:"1 / -1", background:"#fff8f5", borderRadius:10, padding:"12px 18px", display:"flex", gap:24 }}>
                  <div><span style={{ fontSize:12, color:"#a09080" }}>Total: </span><strong>${parseFloat(formData.precio||0).toLocaleString("es-AR")}</strong></div>
                  <div><span style={{ fontSize:12, color:"#a09080" }}>Seña: </span><strong style={{ color:"#2e7d32" }}>${parseFloat(formData.seña||0).toLocaleString("es-AR")}</strong></div>
                  <div><span style={{ fontSize:12, color:"#a09080" }}>Saldo: </span><strong style={{ color:saldo(formData)>0?"#c62828":"#2e7d32" }}>${saldo(formData).toLocaleString("es-AR")}</strong></div>
                </div>
              )}

              <div style={{ gridColumn:"1 / -1" }}>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>👤 Tomado por</label>
                <select value={formData.tomadoPor||""} onChange={e=>setFormData(p=>({...p,tomadoPor:e.target.value}))}
                  style={{ ...inp(), cursor:"pointer",
                    borderColor: formData.tomadoPor?"#e65100":"",
                    background: formData.tomadoPor?"#fff8f5":"#fff",
                    fontWeight: formData.tomadoPor?600:400,
                    color: formData.tomadoPor?"#1a2340":"#a09080" }}>
                  <option value="">— Sin asignar —</option>
                  {empleados.map(e=>(
                    <option key={e.fireId} value={`${e.nombre||""} ${e.apellido||""}`.trim()}>
                      {`${e.nombre||""} ${e.apellido||""}`.trim()}
                    </option>
                  ))}
                </select>
              </div>

              <div style={{ gridColumn:"1 / -1" }}>
                <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#4a5568", marginBottom:6 }}>Notas / Detalles</label>
                <div style={{ display:"flex", flexDirection:"column", gap:6 }}>
                  {(formData.notasItems||[""]).map((item, idx) => (
                    <div key={idx} style={{ display:"flex", gap:6, alignItems:"center" }}>
                      <span style={{ fontSize:12, color:"#a09080", minWidth:18, textAlign:"right" }}>{idx+1}.</span>
                      <input
                        value={item}
                        onChange={e => {
                          const arr = [...(formData.notasItems||[""])];
                          arr[idx] = e.target.value;
                          setFormData(p=>({...p, notasItems:arr}));
                        }}
                        onKeyDown={e => {
                          if (e.key==="Enter") {
                            e.preventDefault();
                            const arr = [...(formData.notasItems||[""])];
                            arr.splice(idx+1, 0, "");
                            setFormData(p=>({...p, notasItems:arr}));
                          }
                          if (e.key==="Backspace" && !item && (formData.notasItems||[""]).length > 1) {
                            e.preventDefault();
                            const arr = [...(formData.notasItems||[""])];
                            arr.splice(idx, 1);
                            setFormData(p=>({...p, notasItems:arr}));
                          }
                        }}
                        placeholder={idx===0 ? "Medidas, color, cantidad..." : ""}
                        style={{ ...inp(), flex:1 }}
                      />
                      {(formData.notasItems||[""]).length > 1 && (
                        <button onClick={() => {
                          const arr = [...(formData.notasItems||[""])];
                          arr.splice(idx, 1);
                          setFormData(p=>({...p, notasItems:arr}));
                        }} style={{ background:"transparent", border:"none", color:"#ccc", cursor:"pointer", fontSize:16, padding:"0 4px" }}>✕</button>
                      )}
                    </div>
                  ))}
                  <button onClick={() => setFormData(p=>({...p, notasItems:[...(p.notasItems||[""]), ""]}))}
                    style={{ alignSelf:"flex-start", background:"transparent", border:"1px dashed #f0d5c0", color:"#e65100", borderRadius:6, padding:"4px 12px", fontSize:12, cursor:"pointer", marginTop:2 }}>
                    + Agregar ítem
                  </button>
                </div>
              </div>
            </div>

            <div style={{ display:"flex", gap:12, marginTop:28, justifyContent:"flex-end" }}>
              <button className="btn-g" onClick={() => { setFormData(EMPTY_FORM); setEditingId(null); setErrors({}); setSelectedClienteId(null); setClienteSearch(""); setView("lista"); }}>Cancelar</button>
              <button className="btn-p" onClick={handleSubmit}>{editingId?"💾 Guardar Cambios":"✅ Guardar Pedido"}</button>
            </div>
          </div>
        )}

        {/* ── DETALLE ── */}
        {view==="detalle" && selectedPedido && (() => {
          const p  = pedidos.find(x => x.fireId===selectedPedido.fireId) || pedidos.find(x => x.id===selectedPedido.id) || selectedPedido;
          const ec = ESTADO_COLOR[p.estado];
          const cc = CATEGORIA_COLOR[p.categoria];
          return (
            <div className="card" style={{ padding:"32px 36px", maxWidth:720, margin:"0 auto" }}>
              <button className="btn-g" style={{ marginBottom:22, fontSize:13 }} onClick={() => setView("lista")}>← Volver</button>
              <div style={{ display:"flex", justifyContent:"space-between", flexWrap:"wrap", gap:12, marginBottom:22 }}>
                <div>
                  <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8 }}>
                    <h2 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:26, fontWeight:700, color:"#1a2340" }}>{p.nombre}</h2>
                    {p.nroOT && <span style={{ fontSize:13, fontWeight:800, color:"#e65100", fontFamily:"monospace", background:"#fff8f5", padding:"4px 10px", borderRadius:6, border:"1.5px solid #f0d5c0", whiteSpace:"nowrap" }}>OT-{String(p.nroOT).padStart(4,"0")}</span>}
                  </div>
                  <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                    <span style={{ background:cc.bg, color:cc.text, padding:"5px 12px", borderRadius:20, fontSize:13, fontWeight:700 }}>{CATEGORIA_ICON[p.categoria]} {p.categoria}</span>
                    <span style={{ background:ec.bg, color:ec.text, padding:"5px 12px", borderRadius:20, fontSize:13, fontWeight:600 }}>{p.estado}</span>
                    {isVencido(p) && <span style={{ background:"#ffebee", color:"#c62828", padding:"5px 12px", borderRadius:20, fontSize:13, fontWeight:600 }}>⚠️ Vencido</span>}
                    {isHoy(p)    && <span style={{ background:"#fff8e1", color:"#f57f17", padding:"5px 12px", borderRadius:20, fontSize:13, fontWeight:600 }}>📍 Entrega hoy</span>}
                  </div>
                </div>
                <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                  <button className="btn-imp" style={{ padding:"9px 16px", fontSize:14 }} onClick={() => imprimirOrden(p, empresa)}>🖨️ Imprimir Orden</button>
                  <button className="btn-g" onClick={() => handleEdit(p)}>✏️ Editar</button>
                  <button className="btn-d" onClick={() => handleDelete(p.fireId || p.id)}>🗑</button>
                </div>
              </div>

              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:20 }}>
                {[
                  { label:"Cliente", value:p.cliente, icon:"🏢", clickable: !!p.clienteId },
                  { label:"Teléfono", value:p.telefono||"—", icon:"📞" },
                  { label:"Fecha de Pedido", value:p.fechaPedido||"—", icon:"📅" },
                  { label:"Fecha de Entrega", value:fmtFecha(p.fechaEntrega)||"—", icon:"🏁" },
                  ...(p.tomadoPor ? [{ label:"Tomado por", value:p.tomadoPor, icon:"👤" }] : []),
                ].map(item => (
                  <div key={item.label} style={{ background:"#fffaf7", borderRadius:10, padding:"13px 16px",
                    cursor: item.clickable ? "pointer" : "default",
                    border: item.clickable ? "1.5px solid transparent" : "none",
                    transition:"all .15s" }}
                    onClick={() => { if(item.clickable) { const cl = clientes.find(c=>c.fireId===p.clienteId); if(cl) setClienteDestacado(cl); setView("clientes"); } }}
                    onMouseOver={e=>{ if(item.clickable) { e.currentTarget.style.borderColor="#e65100"; e.currentTarget.style.background="#fff8f5"; }}}
                    onMouseOut={e=>{ if(item.clickable) { e.currentTarget.style.borderColor="transparent"; e.currentTarget.style.background="#fffaf7"; }}}>
                    <div style={{ fontSize:11, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:4 }}>{item.icon} {item.label}</div>
                    <div style={{ fontWeight:600, color: item.clickable ? "#e65100" : "#1a2340", display:"flex", alignItems:"center", gap:6 }}>
                      {item.value}
                      {item.clickable && <span style={{ fontSize:10, color:"#e65100", fontWeight:700 }}>→ Ver ficha</span>}
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ background:"#fff8f5", borderRadius:12, padding:"18px 20px", marginBottom:16, display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
                {/* Precio — editable inline */}
                {[
                  { label:"Precio Total", field:"precio", color:"#1a2340" },
                  { label:"Seña / Adelanto", field:"seña", color:"#2e7d32" },
                ].map(f => (
                  <div key={f.field} style={{ textAlign:"center" }}>
                    <div style={{ fontSize:11, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:5 }}>{f.label}</div>
                    <InlineEditPrecio
                      value={p[f.field]||""}
                      color={f.color}
                      onSave={async (val) => {
                        await updateDoc(doc(db,"pedidos",p.fireId), { [f.field]: val });
                        showToast(`${f.label} actualizado ✅`);
                      }}
                    />
                  </div>
                ))}
                <div style={{ textAlign:"center" }}>
                  <div style={{ fontSize:11, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".6px", marginBottom:5 }}>Saldo Pendiente</div>
                  <div style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:saldo(p)>0?"#c62828":"#2e7d32" }}>
                    ${saldo(p).toLocaleString("es-AR")}
                  </div>
                </div>
              </div>

              {p.notas && (
                <div style={{ background:"#fffaf7", borderRadius:10, padding:"16px 18px" }}>
                  <div style={{ fontSize:11, fontWeight:600, color:"#a09080", textTransform:"uppercase", letterSpacing:".7px", marginBottom:7 }}>📝 Notas</div>
                  <p style={{ color:"#4a5568", lineHeight:1.6, fontSize:14 }}>{p.notas}</p>
                </div>
              )}
            </div>
          );
        })()}

        {/* ── VISTA PEDIDOS LISTOS ── */}
        {view==="listos" && renderSelectorVistas()}
        {view==="listos" && (
          <PedidosListos
            showToast={showToast}
            onEntregarVarios={lista => setEntregaMultiple(lista)}
            pedidos={pedidos}
            saldo={saldo}
            isHoy={isHoy}
            handleEstadoChange={handleEstadoChange}
            handleDelete={handleDelete}
            setMsgModal={setMsgModal}
            CATEGORIA_COLOR={CATEGORIA_COLOR}
            CATEGORIA_ICON={CATEGORIA_ICON}
            inp={inp}
            empresa={empresa}
            setView={setView}
            clientes={clientes}
            setClienteDestacado={setClienteDestacado}
          />
        )}

        {/* ── CLIENTES ── */}
        {view==="clientes" && (
          <ClientesView
            key={clienteDestacado?.fireId || "lista"}
            clientes={clientes}
            pedidos={pedidos}
            setView={setView}
            setFormData={setFormData}
            setEditingClienteId={setEditingClienteId}
            showToast={showToast}
            clienteDestacado={clienteDestacado}
            setClienteDestacado={setClienteDestacado}
          />
        )}

        {/* ── NUEVO / EDITAR CLIENTE ── */}
        {(view==="nuevoCliente" || view==="editarCliente") && (
          <FormularioCliente
            view={view}
            editingClienteId={editingClienteId}
            clientes={clientes}
            pedidos={pedidos}
            setView={setView}
            setSelectedClienteId={setSelectedClienteId}
            setClienteSearch={setClienteSearch}
            setFormData={setFormData}
            formData={formData}
            showToast={showToast}
          />
        )}

        {/* ── INSUMOS ── */}
        {view==="insumos" && (
          <InsumosView
            setView={setView}
            showToast={showToast}
          />
        )}
        {(view==="nuevoInsumo"||view==="editarInsumo") && (
          <FormularioInsumo
            view={view}
            editingInsumoId={editingInsumoId}
            setView={setView}
            showToast={showToast}
          />
        )}

        {/* ── VENTAS ── */}
        {view==="ventas" && (
          <VentasView setView={setView} showToast={showToast} clientes={clientes} empresa={empresa} configCargada={configCargada} />
        )}
        {view==="nuevaVenta" && (
          <NuevaVentaView setView={setView} showToast={showToast} clientes={clientes} empresa={empresa} configCargada={configCargada} />
        )}

        {/* ── PRESUPUESTOS ── */}
        {view==="presupuestos" && (
          <PresupuestosView showToast={showToast} clientes={clientes} empresa={empresa} setView={setView} setSelectedPedido={setSelectedPedido} />
        )}

        {/* ── AGENDA ── */}
        {view==="agenda" && (
          <AgendaView
            nuevoEventoModal={nuevoEventoModal}
            setNuevoEventoModal={setNuevoEventoModal}
            showToast={showToast}
          />
        )}

        {/* ── PROVEEDORES ── */}
        {(view==="proveedores"||view==="nuevoProveedor"||view==="editarProveedor") && (
          <ProveedoresView
            view={view}
            setView={setView}
            showToast={showToast}
          />
        )}

        {/* ── FINANZAS ── */}
        {view==="calculadora" && <CalculadoraCostos/>}
        {view==="produccion"   && <ProduccionView showToast={showToast}/>}
        {view==="pedidosOnline" && <PedidosOnlineView showToast={showToast} setView={setView} setSelectedPedido={setSelectedPedido} clientes={clientes}/>}

        {view==="finanzas" && (
          <FinanzasView
            pedidos={pedidos}
            clientes={clientes}
            desbloqueado={finanzasDesbloqueado}
            setDesbloqueado={setFinanzasDesbloqueado}
            showToast={showToast}
          />
        )}

        {/* ── CONFIGURACIÓN ── */}
        {view==="config" && (
          <ConfiguracionView
            empresa={empresa}
            setEmpresa={setEmpresa}
            empresaSaved={empresaSaved}
            setEmpresaSaved={setEmpresaSaved}
            pedidos={pedidos}
            showToast={showToast}
            catsVersion={catsVersion}
            cfgVersion={cfgVersion}
          />
        )}
      </div>

      {msgModal && (
        <MsgModal
          pedido={msgModal.pedido}
          copied={copied}
          setCopied={setCopied}
          onClose={() => setMsgModal(null)}
        />
      )}

      {entregaMultiple && (
        <EntregaMultipleModal
          pedidos={entregaMultiple}
          onConfirmar={confirmarEntregaMultiple}
          onClose={() => setEntregaMultiple(null)}
        />
      )}
      {entregaModal && (
        <EntregaModal
          pedido={entregaModal.pedido}
          onConfirmar={confirmarEntrega}
          onClose={() => setEntregaModal(null)}
        />
      )}

      {/* ── MODAL IMPRESIÓN AUTOMÁTICA ── */}
      {printModal && (
        <div className="modal-ov" onClick={() => setPrintModal(null)}>
          <div className="modal-bx" onClick={e => e.stopPropagation()}>
            <div style={{ fontSize:52, marginBottom:14 }}>🖨️</div>
            <h3 style={{ fontFamily:"'DM Sans',sans-serif", fontSize:22, fontWeight:700, color:"#1a2340", marginBottom:8 }}>
              ¡Pedido en Producción!
            </h3>
            <p style={{ fontSize:15, color:"#1a2340", fontWeight:600, marginBottom:4 }}>{printModal.pedido.nombre}</p>
            <p style={{ fontSize:14, color:"#a09080", marginBottom:28 }}>¿Querés imprimir la orden de trabajo ahora?</p>
            <div style={{ display:"flex", gap:12, justifyContent:"center" }}>
              <button className="btn-g" style={{ padding:"10px 24px" }} onClick={() => setPrintModal(null)}>Ahora no</button>
              <button className="btn-imp" style={{ padding:"11px 24px", fontSize:15, borderRadius:9 }}
                onClick={() => { if(!configCargada){alert("Cargando datos del local...");return;} imprimirOrden(printModal.pedido, empresa); setPrintModal(null); }}>
                🖨️ Imprimir orden
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div style={{ position:"fixed", bottom:26, right:26, padding:"13px 20px",
          background:toast.type==="error"?"#ef5350":"#1b5e20",
          color:"#fff", borderRadius:10, fontSize:14, fontWeight:600,
          boxShadow:"0 8px 24px rgba(0,0,0,.2)", zIndex:1000 }}>
          {toast.type==="error"?"🗑 ":"✅ "}{toast.msg}
        </div>
      )}
      </div>
      </div>
    </div>
  );
}
